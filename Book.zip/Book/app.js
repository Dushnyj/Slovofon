"use strict";

let SOURCES = [];
let parsers = {};
const SOURCE_ADAPTERS = {};

const state = {
  view: "home",
  theme: localStorage.getItem("auralib-theme") || (window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light"),
  mode: "live",
  query: "полураспад",
  searchKind: "title",
  selectedSources: new Set(),
  sort: "relevance",
  type: "all",
  rawResults: [],
  results: [],
  selectedId: null,
  currentDetails: null,
  currentTracks: [],
  trackIndex: 0,
  playing: false,
  position: 0,
  timer: null,
  loadTimer: null,
  speed: 1,
  liveHealth: {},
  loading: false,
  bookLoading: false,
  searchRunId: 0
};

const CACHE_TTL_MS = 5 * 60 * 1000;
const DETAIL_BATCH_TIMEOUT_MS = 25000;
const SEARCH_KINDS = new Set(["title", "author", "reader", "series"]);
const SEARCH_KIND_LABELS = {
  title: "названию",
  author: "автору",
  reader: "чтецу",
  series: "циклу"
};
const cycleCache = new Map();
const archiveCache = new Map();
const PLAYER_STORAGE_KEY = "auralib-player-state-v2";
const CORE_PLAYABLE_TRACK_SOURCES = [
  "direct-media-url",
  "literal-media-url",
  "inline-player-url",
  "archive.org-metadata"
];
const PLAYABLE_TRACK_SOURCES = new Set(CORE_PLAYABLE_TRACK_SOURCES);

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

function parseHtml(html) {
  return new DOMParser().parseFromString(html, "text/html");
}

function normalizeText(value) {
  return (value || "").replace(/\s+/g, " ").trim();
}

function normalizeSearchText(value) {
  return normalizeText(value)
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^0-9a-zа-яе]+/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function searchTokens(query) {
  const comparable = normalizeSearchText(query);
  return comparable ? comparable.split(" ").filter(Boolean) : [];
}

function searchKindLabel(kind = state.searchKind) {
  return SEARCH_KIND_LABELS[kind] || SEARCH_KIND_LABELS.title;
}

function itemSearchText(item, kind = state.searchKind) {
  const fields = kind === "author"
    ? [item.author]
    : kind === "reader"
      ? [item.reader, item.readers]
      : kind === "series"
        ? [item.series, item.cycle]
        : [item.title, item.originalTitle, item.sourceUrlName];
  return normalizeSearchText(fields.map(metadataValue).filter(Boolean).join(" "));
}

function matchesSearchKind(item, query = state.query, kind = state.searchKind) {
  const tokens = searchTokens(query);
  if (!tokens.length) return true;
  const haystack = itemSearchText(item, kind);
  if (!haystack) return false;
  const haystackTokens = new Set(searchTokens(haystack));
  return tokens.every((token) => haystackTokens.has(token));
}

function text(root, selector) {
  const el = selector ? $(selector, root) : root;
  return normalizeText(el?.textContent || "");
}

function attr(root, selector, name) {
  const el = selector ? $(selector, root) : root;
  return normalizeText(el?.getAttribute(name) || "");
}

function cleanedText(root, selector, removeSelectors = []) {
  const el = selector ? $(selector, root) : root;
  if (!el) return "";
  const clone = el.cloneNode(true);
  for (const removeSelector of removeSelectors) {
    $$(removeSelector, clone).forEach((child) => child.remove());
  }
  return normalizeText(clone.textContent || "");
}

function absUrl(url, source) {
  if (!url) return "";
  if (/^(https?:|blob:)/i.test(url)) return url;
  const host = source?.host || "https://example.local";
  return new URL(url, host).toString();
}

function absHref(root, selector, source) {
  return absUrl(attr(root, selector, "href"), source);
}

function sourceById(id) {
  return SOURCES.find((source) => source.id === id);
}

function durationToSeconds(value) {
  if (typeof value === "number") return value;
  const raw = String(value || "").trim();
  if (!raw) return 0;
  if (/\d+\s*:\s*\d+[\s\S]*\/[\s\S]*\d+\s*:\s*\d+/.test(raw)) {
    return durationToSeconds(raw.split("/").pop());
  }
  if (/^\d+(?:[.,]\d+)?$/.test(raw)) return Math.floor(Number(raw.replace(",", ".")));
  const hMatch = raw.match(/(\d+)\s*(?:ч|час|часа|часов|h\b|hour)/i);
  const mMatch = raw.match(/(\d+)\s*(?:м|мин|минут|minute)/i);
  const sMatch = raw.match(/(\d+)\s*(?:с|сек|секунд|second)/i);
  if (hMatch || mMatch || sMatch) {
    return Number(hMatch?.[1] || 0) * 3600 + Number(mMatch?.[1] || 0) * 60 + Number(sMatch?.[1] || 0);
  }
  if (raw.includes(":")) {
    const nums = raw.match(/\d+/g)?.map(Number) || [];
    if (nums.length >= 3) return nums[0] * 3600 + nums[1] * 60 + nums[2];
    if (nums.length === 2) return nums[0] * 60 + nums[1];
    return nums[0] || 0;
  }
  const parts = raw.match(/\d+/g);
  if (!parts) return 0;
  const nums = parts.map(Number);
  return nums[0];
}

function formatTime(seconds) {
  const value = Math.max(0, Math.floor(seconds || 0));
  const h = Math.floor(value / 3600);
  const m = Math.floor((value % 3600) / 60);
  const s = value % 60;
  if (h) return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function formatDuration(seconds) {
  return seconds > 0 ? formatTime(seconds) : "--:--";
}

function coverSvg(title, source) {
  const safeTitle = String(title || source.name).slice(0, 34).replace(/[<>&"]/g, "");
  const safeSource = source.name.replace(/[<>&"]/g, "");
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="240" height="360" viewBox="0 0 240 360">
      <rect width="240" height="360" fill="${source.color}"/>
      <rect x="18" y="18" width="204" height="324" rx="8" fill="rgba(255,255,255,.14)" stroke="rgba(255,255,255,.45)"/>
      <text x="24" y="54" fill="#fff" font-family="Segoe UI, Arial" font-size="17" font-weight="700">${safeSource}</text>
      <foreignObject x="24" y="116" width="192" height="140">
        <div xmlns="http://www.w3.org/1999/xhtml" style="font:700 30px/1.15 Segoe UI,Arial;color:white;word-wrap:break-word;">${safeTitle}</div>
      </foreignObject>
      <rect x="24" y="292" width="102" height="8" fill="rgba(255,255,255,.7)"/>
      <rect x="24" y="312" width="150" height="8" fill="rgba(255,255,255,.45)"/>
    </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function parseLabelValue(root, labels) {
  const textValue = normalizeText(root.textContent);
  for (const label of labels) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = textValue.match(new RegExp(`${escaped}\\s*[:：]?\\s*([^•\\n]+?)(?=(Автор|Читает|Озвучивает|Длительность|Цикл|Жанр|Время|$))`, "i"));
    if (match?.[1]) return normalizeText(match[1]);
  }
  return "";
}

function extractPlayerArray(textValue) {
  const arrayMatch = textValue.match(/\[([\s\S]*?)\]/);
  if (!arrayMatch) return [];
  let body = `[${arrayMatch[1]}]`;
  body = jsonLikeToJson(body);
  try {
    return JSON.parse(body);
  } catch {
    return [];
  }
}

function jsonLikeToJson(value) {
  return String(value || "")
    .replace(/([{,]\s*)([a-zA-Z_$][\w$-]*)(\s*:)/g, '$1"$2"$3')
    .replace(/'/g, '"');
}

function parseJsonLike(value) {
  try {
    return JSON.parse(value);
  } catch {
    try {
      return JSON.parse(jsonLikeToJson(value));
    } catch {
      return null;
    }
  }
}

function extractBalanced(textValue, startIndex, openChar, closeChar) {
  const textValueString = String(textValue || "");
  let depth = 0;
  let inString = "";
  let escaped = false;
  for (let i = startIndex; i < textValueString.length; i += 1) {
    const char = textValueString[i];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === inString) {
        inString = "";
      }
      continue;
    }
    if (char === '"' || char === "'") {
      inString = char;
      continue;
    }
    if (char === openChar) depth += 1;
    if (char === closeChar) {
      depth -= 1;
      if (depth === 0) return textValueString.slice(startIndex, i + 1);
    }
  }
  return "";
}

function parseTracksFromScript(document, pattern, mapper) {
  const script = $$("script", document).map((el) => el.textContent || "").find((value) => value.includes(pattern));
  if (!script) return [];
  return mapper(script);
}

const SOURCE_ADAPTER_VERSION = "20260525-full-search-1";

function createAdapterContext() {
  return {
    $,
    $$,
    text,
    attr,
    cleanedText,
    absUrl,
    absHref,
    normalizeText,
    parseLabelValue,
    parseTracksFromScript,
    extractPlayerArray,
    extractBalanced,
    parseJsonLike,
    resolvePlayerAudioUrl,
    durationToSeconds
  };
}

function emptySourceAdapter(sourceInfo) {
  return {
    source: {
      id: sourceInfo.id,
      name: sourceInfo.name || sourceInfo.id,
      host: sourceInfo.host || "https://example.local",
      color: sourceInfo.color || "#64748b",
      parser: "empty",
      searchUrl: sourceInfo.searchUrl || "",
      selectors: []
    },
    playableTrackSources: [],
    parser: {
      list() {
        return [];
      },
      details(_document, _source, urlBook) {
        return { urlBook };
      },
      audio() {
        return [];
      }
    }
  };
}

function normalizeParser(parser = {}) {
  return {
    list: typeof parser.list === "function" ? parser.list : () => [],
    details: typeof parser.details === "function" ? parser.details : (_document, _source, urlBook) => ({ urlBook }),
    audio: typeof parser.audio === "function" ? parser.audio : () => [],
    enhancedAudio: typeof parser.enhancedAudio === "function" ? parser.enhancedAudio : null,
    visibleChapters: typeof parser.visibleChapters === "function" ? parser.visibleChapters : null,
    enrichListItem: typeof parser.enrichListItem === "function" ? parser.enrichListItem : null,
    cycleItems: typeof parser.cycleItems === "function" ? parser.cycleItems : null,
    apiList: typeof parser.apiList === "function" ? parser.apiList : null,
    apiDetails: typeof parser.apiDetails === "function" ? parser.apiDetails : null,
    apiAudio: typeof parser.apiAudio === "function" ? parser.apiAudio : null,
    apiCycleItems: typeof parser.apiCycleItems === "function" ? parser.apiCycleItems : null,
    extraSearchQueries: typeof parser.extraSearchQueries === "function" ? parser.extraSearchQueries : () => []
  };
}

function loadSourceScript(id) {
  return new Promise((resolve, reject) => {
    if (!/^[a-z0-9_]+$/i.test(id)) {
      reject(new Error(`invalid source id: ${id}`));
      return;
    }
    if (window.AudioSourceAdapters?.[id]) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = `./sources/client/${id}.js?v=${SOURCE_ADAPTER_VERSION}`;
    script.async = false;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`adapter script not found: ${id}`));
    document.head.appendChild(script);
  });
}

async function loadSourceAdapters() {
  const response = await fetch("/api/sources", { headers: { Accept: "application/json" } });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || !payload.ok) throw new Error(payload.error || `HTTP ${response.status}`);

  const sourceInfos = payload.sources || [];
  await Promise.all(sourceInfos.map((sourceInfo) =>
    loadSourceScript(sourceInfo.clientAdapter || sourceInfo.id).catch((error) => {
      console.warn(error.message);
    })
  ));

  const context = createAdapterContext();
  const loadedSources = [];
  parsers = {};
  for (const sourceInfo of sourceInfos) {
    const adapterId = sourceInfo.clientAdapter || sourceInfo.id;
    const factory = window.AudioSourceAdapters?.[adapterId];
    let adapter = null;
    try {
      adapter = typeof factory === "function" ? factory(context) : emptySourceAdapter(sourceInfo);
    } catch (error) {
      console.warn(`adapter init failed: ${sourceInfo.id}`, error);
      adapter = emptySourceAdapter(sourceInfo);
    }

    const source = {
      id: sourceInfo.id,
      name: adapter.source?.name || sourceInfo.name || sourceInfo.id,
      host: adapter.source?.host || sourceInfo.host || "https://example.local",
      color: adapter.source?.color || sourceInfo.color || "#64748b",
      parser: adapter.source?.parser || sourceInfo.parser || "empty",
      searchUrl: adapter.source?.searchUrl || sourceInfo.searchUrl || "",
      selectors: adapter.source?.selectors || []
    };

    SOURCE_ADAPTERS[source.id] = adapter;
    parsers[source.id] = normalizeParser(adapter.parser);
    for (const rawSource of adapter.playableTrackSources || []) {
      PLAYABLE_TRACK_SOURCES.add(rawSource);
    }
    loadedSources.push(source);
  }

  SOURCES = loadedSources;
}

function sourceAdapterById(id) {
  return SOURCE_ADAPTERS[id] || {};
}

function renderSourceFilters() {
  $("#sourceFilters").innerHTML = SOURCES.map(
    (source) => `
      <label class="source-toggle">
        <input type="checkbox" value="${source.id}" ${state.selectedSources.has(source.id) ? "checked" : ""} />
        <span style="color:${source.color};font-weight:700">${source.name}</span>
      </label>`
  ).join("");
}

function setView(view) {
  state.view = view === "book" && !state.currentDetails ? "home" : view;
  $$(".view-page").forEach((page) => {
    page.classList.toggle("active", page.id === `${state.view}View`);
  });
  $$(".nav-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === state.view);
  });
  if (state.view === "diagnostics") renderLiveNotice();
}

function readInitialParams() {
  const params = new URLSearchParams(window.location.search);
  if (params.has("q")) state.query = params.get("q").trim();
  const searchKind = params.get("kind") || params.get("searchKind");
  if (SEARCH_KINDS.has(searchKind)) state.searchKind = searchKind;
  state.mode = "live";
  if (["home", "book", "diagnostics"].includes(params.get("view"))) state.view = params.get("view");
  if (params.has("sources")) {
    const ids = params.get("sources").split(",").map((value) => value.trim()).filter((id) => sourceById(id));
    if (ids.length) state.selectedSources = new Set(ids);
  }
}

function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
  const toggle = $("#themeToggle");
  if (toggle) toggle.textContent = state.theme === "dark" ? "☀" : "☾";
}

function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  localStorage.setItem("auralib-theme", state.theme);
  applyTheme();
}

function persistPlayerState() {
  const track = currentTrack();
  if (!track || !state.currentDetails) return;
  const source = sourceById(state.currentDetails.source || state.currentDetails.sourceId) || sourceById(state.results.find((item) => item.id === state.selectedId)?.source);
  const payload = {
    savedAt: Date.now(),
    selectedId: state.selectedId,
    trackIndex: state.trackIndex,
    position: state.position,
    speed: state.speed,
    playing: false,
    source: source ? { id: source.id, name: source.name, color: source.color, host: source.host } : null,
    details: state.currentDetails,
    tracks: state.currentTracks
  };
  try { localStorage.setItem(PLAYER_STORAGE_KEY, JSON.stringify(payload)); } catch { /* ignore storage quota */ }
}

function restorePlayerState() {
  try {
    const payload = JSON.parse(localStorage.getItem(PLAYER_STORAGE_KEY) || "null");
    if (!payload?.details || !Array.isArray(payload.tracks) || !payload.tracks.length) return;
    if (Date.now() - Number(payload.savedAt || 0) > 1000 * 60 * 60 * 24 * 14) return;
    state.currentDetails = payload.details;
    state.currentTracks = payload.tracks;
    state.selectedId = payload.selectedId || null;
    state.trackIndex = Math.max(0, Math.min(Number(payload.trackIndex || 0), state.currentTracks.length - 1));
    state.position = Math.max(0, Number(payload.position || 0));
    state.speed = Number(payload.speed || 1);
    const audio = $("#audioElement");
    const track = currentTrack();
    if (audio && isDirectHttpAudio(track)) {
      audio.src = audioUrlsForTrack(track)[0] || track.urlAudio;
      audio.playbackRate = state.speed;
      audio.load();
    }
    setPlayerStatus("Готово к продолжению.", "ok");
    updatePlayer();
  } catch {
    localStorage.removeItem(PLAYER_STORAGE_KEY);
  }
}

function syncControls() {
  applyTheme();
  $("#searchInput").value = state.query;
  $("#sortSelect").value = state.sort;
  $("#typeSelect").value = state.type;
  $$("input[name='searchKind']").forEach((input) => {
    input.checked = input.value === state.searchKind;
  });
  $$("#sourceFilters input").forEach((input) => {
    input.checked = state.selectedSources.has(input.value);
  });
  setView(state.view);
}

function buildSearchUrl(source, query, page = 1) {
  return source.searchUrl.replaceAll("<qery>", encodeURIComponent(query)).replaceAll("<page>", String(page));
}

function apiUrl(path, params) {
  const url = new URL(path, window.location.origin);
  for (const [key, value] of Object.entries(params || {})) {
    if (value !== undefined && value !== null) url.searchParams.set(key, value);
  }
  return url.toString();
}

async function apiJson(path, params, timeoutMs = 8000) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(apiUrl(path, params), {
      headers: { Accept: "application/json" },
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `HTTP ${response.status}`);
    }
    return payload;
  } catch (error) {
    if (error.name === "AbortError") throw new Error(`timeout ${Math.round(timeoutMs / 1000)}s`);
    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
}

async function apiPostJson(path, body, timeoutMs = 12000) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(apiUrl(path, {}), {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body || {}),
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.ok) {
      throw new Error(payload.error || `HTTP ${response.status}`);
    }
    return payload;
  } catch (error) {
    if (error.name === "AbortError") throw new Error(`timeout ${Math.round(timeoutMs / 1000)}s`);
    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
}

function parseListPayload(parser, payload, document, source, context) {
  if (payload.api && parser.apiList) {
    return parser.apiList(payload, source, context) || [];
  }
  return parser.list(document, source, context);
}

function parseDetailsPayload(parser, payload, document, source, urlBook) {
  if (payload.api && parser.apiDetails) {
    return parser.apiDetails(payload, source, urlBook) || {};
  }
  return parser.details(document, source, urlBook);
}

function parseAudioPayload(parser, payload, context) {
  if (payload.api && parser.apiAudio) {
    return parser.apiAudio(payload, context) || [];
  }
  return [];
}

function parseCyclePayload(parser, payload, document, context) {
  if (payload.api && parser.apiCycleItems) {
    return parser.apiCycleItems(payload, context) || [];
  }
  if (parser.cycleItems) {
    return parser.cycleItems(document, context);
  }
  return [];
}

function payloadModeLabel(payload) {
  return payload?.mode === "api-first" ? " • api-first" : "";
}

function cacheGet(cache, key) {
  const item = cache.get(key);
  if (!item) return null;
  if (Date.now() - item.time > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  return item.value;
}

function cacheSet(cache, key, value) {
  cache.set(key, { time: Date.now(), value });
}

function cacheKey(...parts) {
  return parts.map((part) => normalizeText(String(part ?? "")).toLowerCase()).join("|");
}

function cloneTracks(tracks) {
  return (tracks || []).map((track) => ({ ...track }));
}

function playbackAccessFromTracks(source, tracks) {
  const rawSources = new Set((tracks || []).map((track) => track.rawSource).filter(Boolean));
  if (source?.id === "akniga" && rawSources.has("akniga-ajax-bid")) {
    return { playbackAccess: "full", playbackAccessText: "полная через Akniga mp3" };
  }
  if (source?.id === "akniga" && rawSources.has("akniga-external-player")) {
    return { playbackAccess: "fragment", playbackAccessText: "фрагмент через плеер Akniga" };
  }
  if (source?.id === "knigavuhe" && rawSources.has("knigavuhe-bookplayer")) {
    return { playbackAccess: "full", playbackAccessText: "полная через Книга в ухе mp3" };
  }
  if (source?.id === "knigavuhe" && rawSources.has("knigavuhe-litres-trial")) {
    return { playbackAccess: "fragment", playbackAccessText: "фрагмент LitRes" };
  }
  if (source?.id === "izib" && (rawSources.has("izib-api-mp3") || rawSources.has("izib-mp3"))) {
    return { playbackAccess: "full", playbackAccessText: rawSources.has("izib-api-mp3") ? "полная через Izib API mp3" : "полная через Izib mp3" };
  }
  if (source?.id === "izib" && rawSources.has("izib-litres-trial")) {
    return { playbackAccess: "fragment", playbackAccessText: "фрагмент LitRes" };
  }
  if (source?.id === "knigoblud" && rawSources.has("knigoblud-api-mp3")) {
    return { playbackAccess: "full", playbackAccessText: "полная через Книгоблуд mp3" };
  }
  if (source?.id === "knigoblud" && rawSources.has("knigoblud-litres-trial")) {
    return { playbackAccess: "fragment", playbackAccessText: "фрагмент LitRes" };
  }
  if (source?.id === "baza_knig" && (rawSources.has("baza-strDecode") || rawSources.has("baza-playerjs"))) {
    return { playbackAccess: "full", playbackAccessText: "полная через База книг mp3" };
  }
  if (source?.id === "yakniga" && rawSources.has("yakniga-api-mp3")) {
    return { playbackAccess: "full", playbackAccessText: "полная через Yakniga mp3" };
  }
  return {};
}

function applyPlaybackAccess(details, tracks, source) {
  const trackAccess = playbackAccessFromTracks(source, tracks);
  return trackAccess.playbackAccess ? { ...details, ...trackAccess } : details;
}

function mergeDetailsIntoResult(id, details) {
  const patch = {
    title: details.title,
    coverUrl: details.coverUrl,
    author: details.author,
    reader: details.reader,
    genre: details.genre,
    series: details.series,
    seriesUrl: details.seriesUrl,
    seriesNumber: details.seriesNumber,
    cycleItems: details.cycleItems,
    alternateReadings: details.alternateReadings,
    durationText: details.durationText,
    publishedYear: details.publishedYear,
    audioYear: details.audioYear,
    isFragment: details.isFragment,
    siteAccess: details.siteAccess,
    siteAccessText: details.siteAccessText,
    playbackAccess: details.playbackAccess,
    playbackAccessText: details.playbackAccessText,
    isAccessibleForFree: details.isAccessibleForFree,
    accessText: details.accessText,
    rating: details.rating,
    schemaRating: details.schemaRating,
    schemaBestRating: details.schemaBestRating,
    ratingCount: details.ratingCount,
    likes: details.likes,
    dislikes: details.dislikes,
    comments: details.comments,
    views: details.views,
    plays: details.plays,
    posterCount: details.posterCount,
    apiFileCount: details.apiFileCount,
    sourceUrlName: details.sourceUrlName,
    bookId: details.bookId,
    accessRestricted: details.accessRestricted,
    accessRestrictionText: details.accessRestrictionText,
    isAccessibleForFree: details.isAccessibleForFree,
    isPaid: details.isPaid,
    accessText: details.accessText
  };
  const cleanPatch = Object.fromEntries(
    Object.entries(patch).filter(([, value]) => value !== undefined && value !== null && value !== "")
  );
  const merge = (item) => (item.id === id ? { ...item, ...cleanPatch } : item);
  state.rawResults = state.rawResults.map(merge);
  state.results = state.results.map(merge);
}

function canMergeDetailsIntoResult(id) {
  const item = state.rawResults.find((result) => result.id === id);
  return !item?.searchComplete;
}

function dedupeSearchItems(items) {
  const seen = new Set();
  return (items || []).filter((item) => {
    const key = normalizeText(item.urlBook || item.title || "").toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function readSearchControls() {
  state.query = $("#searchInput").value.trim();
  const selectedSearchKind = $("input[name='searchKind']:checked")?.value;
  state.searchKind = SEARCH_KINDS.has(selectedSearchKind) ? selectedSearchKind : "title";
  state.sort = $("#sortSelect").value;
  state.type = $("#typeSelect").value;
  state.selectedSources = new Set($$("#sourceFilters input:checked").map((input) => input.value));
}

async function runSearch() {
  readSearchControls();
  const shouldRefreshBook = state.view === "book" && Boolean(state.selectedId);
  const runId = ++state.searchRunId;
  state.loading = true;
  render();
  try {
    await runLiveSearch(runId);
  } finally {
    if (runId !== state.searchRunId) return;
    state.loading = false;
  }
  render();
  if (shouldRefreshBook && state.selectedId) await selectBook(state.selectedId);
}

function applyResultView() {
  state.results = state.rawResults
    .filter((item) => filterByQuery(item, state.query, state.searchKind))
    .filter((item) => filterByType(item, state.type))
    .sort(sortResults(state.sort));
  if (!state.results.some((item) => item.id === state.selectedId)) {
    state.selectedId = state.results[0]?.id || null;
  }
}

async function runLiveSearch(runId) {
  const sources = SOURCES.filter((source) => state.selectedSources.has(source.id));
  state.liveHealth = {};
  state.rawResults = [];
  state.results = [];
  state.selectedId = null;
  state.bookLoading = false;
  render();

  const sourceResults = await Promise.all(sources.map((source) => loadFullSourceSearch(source, runId)));
  if (runId !== state.searchRunId) return;
  state.liveHealth = Object.fromEntries(sourceResults.map((result) => [result.source.id, result.health]));
  state.rawResults = sourceResults
    .flatMap((result) => result.items)
    .sort(sortResults(state.sort));
  applyResultView();
}

async function loadFullSourceSearch(source, runId) {
  const startedAt = performance.now();
  const query = state.query || "полураспад";
  const searchUrl = buildSearchUrl(source, query);
  const parser = parsers[source.id] || normalizeParser();
  try {
    const searchQueries = [query]
      .concat(parser.extraSearchQueries(query) || [])
      .map((value) => normalizeText(value))
      .filter((value, index, all) => value && all.indexOf(value) === index);
    const searchSettled = await Promise.allSettled(searchQueries.map(async (searchQuery) => {
      const payload = await apiJson("/api/search", { source: source.id, q: searchQuery, page: 1 }, 6500);
      return { searchQuery, payload };
    }));
    const fulfilled = searchSettled
      .filter((result) => result.status === "fulfilled")
      .map((result) => result.value);
    if (!fulfilled.length) {
      const firstError = searchSettled.find((result) => result.status === "rejected")?.reason;
      throw firstError || new Error("источник не отдал поиск");
    }

    const parsedItems = [];
    for (const { searchQuery, payload } of fulfilled) {
      const document = parseHtml(payload.html || "");
      parsedItems.push(...parseListPayload(parser, payload, document, source, {
        query: searchQuery,
        primaryQuery: query,
        fallback: searchQuery !== query,
        payload
      }));
    }

    const payloads = fulfilled.map((item) => item.payload);
    const primaryPayload = payloads[0] || {};
    const uniqueParsedItems = dedupeSearchItems(parsedItems);
    const baseItems = uniqueParsedItems.map((item, index) => ({
      ...item,
      id: `live-${source.id}-${index}`,
      sourceName: source.name,
      sourceColor: source.color,
      mode: primaryPayload.mode || "live",
      searchUrl: item.searchUrl || primaryPayload.url || searchUrl,
      relevance: scoreItem(item, state.query, state.searchKind)
    })).filter((item) => item.title || item.urlBook);
    const enrichedItems = parser.enrichListItem
      ? await enrichSearchItems(source, parser, baseItems, runId)
      : baseItems;
    const items = enrichedItems.map((item) => ({
      ...item,
      searchComplete: true,
      relevance: scoreItem(item, state.query, state.searchKind)
    }));
    const elapsedMs = Math.round(performance.now() - startedAt);
    return {
      source,
      items,
      health: {
        status: items.length ? "ok" : "warn",
        url: primaryPayload.url || searchUrl,
        message: `HTTP ${primaryPayload.status || "?"}${payloadModeLabel(primaryPayload)} • ${uniqueParsedItems.length} карточек • ${items.length} готово • ${elapsedMs} ms${searchQueries.length > 1 ? " • fallback" : ""}${payloads.some((payload) => payload.truncated) ? " • HTML обрезан" : ""}`
      }
    };
  } catch (error) {
    return {
      source,
      items: [],
      health: {
        status: "warn",
        url: searchUrl,
        message: error.message
      }
    };
  }
}

async function enrichSearchItems(source, parser, items, runId) {
  if (!parser.enrichListItem) return items;
  const requests = items
    .map((item, itemIndex) => ({ itemIndex, source: source.id, url: item.urlBook }))
    .filter((request) => request.url);
  if (!requests.length) return items;
  const enrichedItems = items.slice();
  try {
    const batch = await apiPostJson(
      "/api/books",
      { books: requests.map((request) => ({ source: request.source, url: request.url })) },
      DETAIL_BATCH_TIMEOUT_MS
    );
    await Promise.all((batch.items || []).map(async (entry, batchIndex) => {
      if (runId !== state.searchRunId) return;
      const request = requests[Number.isInteger(entry.index) ? entry.index : batchIndex];
      const item = request ? items[request.itemIndex] : null;
      const payload = entry.payload || {};
      if (!request || !item || !payload.ok) return;
      const document = parseHtml(payload.html || "");
      const details = {
        ...item,
        ...parseDetailsPayload(parser, payload, document, source, payload.url || item.urlBook),
        mode: payload.mode || "live",
        liveUrl: payload.url || item.urlBook
      };
      enrichedItems[request.itemIndex] = await parser.enrichListItem(document, {
        item,
        details,
        source,
        urlBook: payload.url || item.urlBook,
        payload
      }) || item;
    }));
    return enrichedItems;
  } catch {
    return items;
  }
}

function scoreItem(item, query, kind = state.searchKind) {
  const tokens = searchTokens(query);
  if (!tokens.length) return 1;
  const selectedText = itemSearchText(item, kind);
  if (!selectedText) return 0;
  const exactPhrase = normalizeSearchText(query);
  const selectedTokens = new Set(searchTokens(selectedText));
  let score = tokens.every((token) => selectedTokens.has(token)) ? 100 : 0;
  if (exactPhrase && selectedText.includes(exactPhrase)) score += 40;
  if (kind !== "title" && itemSearchText(item, "title").includes(exactPhrase)) score += 5;
  return score;
}

function filterByQuery(item, query, kind = state.searchKind) {
  return matchesSearchKind(item, query, kind);
}

function filterByType(item, type) {
  if (type === "fragment") return completenessStatus(item).status === "fragment";
  if (type === "full") return completenessStatus(item).status === "full";
  return true;
}

function completenessSortRank(item) {
  const status = completenessStatus(item).status;
  if (status === "full") return 3;
  if (status === "fragment") return 2;
  if (status === "restricted") return 1;
  return 0;
}

function completenessStatus(item) {
  if (item.accessRestricted || item.playbackAccess === "restricted") {
    return { status: "restricted", text: "Ограничено", className: "is-restricted" };
  }
  if (item.playbackAccess === "full") {
    return { status: "full", text: "Полная", className: "is-full" };
  }
  if (item.playbackAccess === "fragment") {
    return { status: "fragment", text: "Фрагмент", className: "is-fragment" };
  }
  if (item.isFragment) {
    return { status: "fragment", text: "Фрагмент", className: "is-fragment" };
  }
  return { status: "full", text: "Полная", className: "is-full" };
}

function sortResults(sort) {
  return (a, b) => {
    if (sort === "title") return a.title.localeCompare(b.title, "ru");
    if (sort === "source") return a.sourceName.localeCompare(b.sourceName, "ru") || a.title.localeCompare(b.title, "ru");
    if (sort === "duration") return durationToSeconds(b.durationText) - durationToSeconds(a.durationText);
    if (sort === "rating") return ratingScoreValue(displayRatingValue(b), "5") - ratingScoreValue(displayRatingValue(a), "5");
    if (sort === "comments") return Number(b.comments || 0) - Number(a.comments || 0);
    return b.relevance - a.relevance || completenessSortRank(b) - completenessSortRank(a) || a.title.localeCompare(b.title, "ru");
  };
}


function syncGlobalUiState() {
  document.body.classList.toggle("has-book", Boolean(state.currentDetails));
  document.body.classList.toggle("has-track", Boolean(currentTrack()));
  document.body.classList.toggle("is-playing", Boolean(state.playing));
  document.body.classList.toggle("is-loading", Boolean(state.loading || state.bookLoading));
}

function render() {
  syncGlobalUiState();
  setView(state.view);
  renderResults();
  renderHealth();
  renderLiveNotice();
  $("#resultCount").textContent = String(state.results.length);
  if (state.loading) {
    $("#searchSummary").textContent = `Ищу по ${searchKindLabel()}: все слова должны совпасть в выбранном поле.`;
  } else if (state.results.length) {
    $("#searchSummary").textContent = `Найдено: ${state.results.length} по ${searchKindLabel()}. Выберите карточку, чтобы открыть описание и главы.`;
  } else {
    $("#searchSummary").textContent = "Начните поиск по названию, автору, чтецу или циклу.";
  }
}

function renderMetadataSearchButton(kind, value, label = value, className = "metadata-link") {
  const cleanValue = metadataValue(value);
  if (!cleanValue) return "";
  return `<button class="${className}" type="button" data-card-action="search" data-search-kind="${escapeHtml(kind)}" data-search-value="${escapeHtml(cleanValue)}" title="Искать: ${escapeHtml(cleanValue)}">${escapeHtml(label || cleanValue)}</button>`;
}

function metadataList(value) {
  if (Array.isArray(value)) return value.map(metadataValue).filter(Boolean);
  const cleanValue = metadataValue(value);
  if (!cleanValue) return [];
  return cleanValue.split(/\s*,\s*/).map(metadataValue).filter(Boolean);
}

function renderMetadataSearchButtons(kind, value, className = "metadata-link") {
  const values = metadataList(value);
  if (!values.length) return "";
  return values.map((item) => renderMetadataSearchButton(kind, item, item, className)).join('<span class="metadata-separator">, </span>');
}

function renderCompactMetadataSearchButtons(kind, value, className = "metadata-link") {
  const values = metadataList(value);
  if (!values.length) return "";
  const visibleValues = values.slice(0, 2);
  const buttons = visibleValues
    .map((item) => renderMetadataSearchButton(kind, item, item, className))
    .join('<span class="metadata-separator">, </span>');
  return `${buttons}${values.length > 2 ? '<span class="metadata-more"> и др.</span>' : ""}`;
}

function renderCycleCatalogButton(item, source, label, className = "metadata-link") {
  const cleanLabel = metadataValue(label);
  const seriesName = metadataValue(item.series || item.cycle);
  const seriesUrl = metadataValue(item.seriesUrl || item.cycleUrl);
  const sourceId = metadataValue(source?.id || item.source || item.sourceId);
  if (!cleanLabel) return "";
  if (!seriesUrl || !sourceId) return renderMetadataSearchButton("series", seriesName || cleanLabel, cleanLabel, className);
  return `<button class="${className}" type="button" data-card-action="show-cycle" data-source="${escapeHtml(sourceId)}" data-series-url="${escapeHtml(seriesUrl)}" data-series-name="${escapeHtml(seriesName || cleanLabel)}" title="Открыть цикл: ${escapeHtml(seriesName || cleanLabel)}">${escapeHtml(cleanLabel)}</button>`;
}

function renderResults() {
  $("#resultsGrid").innerHTML = state.results.map((item) => {
    const source = sourceById(item.source);
    const cover = item.coverUrl || coverSvg(item.title, source);
    const writtenYear = formatCardYear(item.writtenYear || item.yearWritten || item.writingYear);
    const publishedYear = formatCardYear(item.publishedYear || item.publicationYear);
    const audioYear = formatCardYear(item.audioYear);
    const author = metadataValue(item.author);
    const reader = metadataValue(item.reader || item.readers);
    const cycle = formatCycleLabel(item.series || item.cycle, item.seriesNumber || item.cycleNumber);
    const rating = ratingStars(displayRatingValue(item), "5");
    const completeness = completenessStatus(item);
    const facts = [
      ["Рейтинг", rating, "card-rating-fact", "./assets/icons/rating.svg", "rating"],
      ["Время", formatCardDuration(item.durationText), "card-duration", "./assets/icons/clock.svg"],
      ["Год написания", writtenYear, "card-written-year", "./assets/icons/calendar.svg"],
      ["Год издания", publishedYear, "card-published-year", "./assets/icons/published.svg"],
      ["Год озвучки", audioYear, "card-audio-year", "./assets/icons/audio-year.svg"],
      ["Цикл", cycle, "card-cycle", "./assets/icons/series.svg", "search", "series"],
      ["Автор", author, "card-author", "./assets/icons/author.svg", "search", "author"],
      ["Чтец", reader, "card-reader", "./assets/icons/mic.svg", "search", "reader"]
    ].filter(([, value]) => value);

    return `
      <article class="book-card ${item.id === state.selectedId ? "active" : ""}" data-id="${item.id}">
        <span class="card-glow" style="background:${source.color}"></span>
        <img class="cover" src="${escapeHtml(cover)}" alt="" loading="lazy" />
        <div class="card-content">
          <div class="card-topline">
            <span class="source-chip" style="background:${source.color}">${source.name}</span>
            <span class="card-completeness ${completeness.className}">${escapeHtml(completeness.text)}</span>
          </div>
          <h3><button class="card-title-button" type="button" data-card-action="open" data-id="${escapeHtml(item.id)}">${escapeHtml(item.title || "Без названия")}</button></h3>
          <dl class="card-facts">
            ${facts.map(([label, value, className, icon, type, actionKind]) => `
              <div class="card-fact ${className}">
                <dt title="${escapeHtml(label)}">
                  <img class="card-fact-icon" src="${icon}" alt="${escapeHtml(label)}" loading="lazy" />
                </dt>
                ${type === "rating" ? `
                  <dd class="card-rating-value" title="${escapeHtml(value.label)}">
                    <span class="rating-stars" aria-hidden="true">
                      ${renderRatingSegments(value)}
                    </span>
                    <span class="card-rating-label">${escapeHtml(value.label)}</span>
                  </dd>` : `
                  <dd title="${escapeHtml(value)}">${type === "search" ? (actionKind === "series" ? renderCycleCatalogButton(item, source, value, "metadata-link card-meta-link") : renderCompactMetadataSearchButtons(actionKind, value, "metadata-link card-meta-link")) : escapeHtml(value)}</dd>`}
              </div>`).join("")}
          </dl>
        </div>
      </article>`;
  }).join("");

  $$("#resultsGrid .book-card").forEach((card) => {
    card.addEventListener("click", (event) => {
      if (event.target.closest("[data-card-action]")) return;
      selectBook(card.dataset.id);
    });
  });
}

function metadataValue(value) {
  if (Array.isArray(value)) return value.map(metadataValue).filter(Boolean).join(", ");
  return normalizeText(String(value || ""));
}

function formatCardYear(value) {
  const year = metadataValue(value);
  if (!year || /(?:^|\s)гг?\./i.test(year)) return year;
  if (/^\d{4}$/.test(year)) return `${year} г.`;
  if (/^\d{4}\s*[-–—]\s*\d{4}$/.test(year)) return `${year} гг.`;
  return year;
}

function hourWord(value) {
  const abs = Math.abs(Number(value) || 0);
  const mod10 = abs % 10;
  const mod100 = abs % 100;
  if (mod10 === 1 && mod100 !== 11) return "час";
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return "часа";
  return "часов";
}

function formatReadableDuration(value, mode) {
  const original = metadataValue(value);
  if (!original) return "";
  const total = durationToSeconds(original);
  if (!Number.isFinite(total) || total <= 0) return original;
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (!hours && !minutes) return original;
  if (mode === "card") {
    return hours ? `${hours} ч. ${minutes} мин.` : `${minutes} мин.`;
  }
  return hours ? `${hours} ${hourWord(hours)} ${minutes} мин.` : `${minutes} мин.`;
}

function formatCardDuration(value) {
  return formatReadableDuration(value, "card");
}

function formatDetailDuration(value) {
  return formatReadableDuration(value, "detail");
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function cycleIndexValue(value) {
  const raw = metadataValue(value);
  return raw.match(/\d+(?:[.,]\d+)*/)?.[0]?.replace(",", ".") || "";
}

function formatCycleLabel(value, number) {
  const cycle = metadataValue(value);
  const index = cycleIndexValue(number);
  if (!cycle) return "";
  if (!index || new RegExp(`\\(${escapeRegExp(index)}\\)\\s*$`).test(cycle)) return cycle;
  return `${cycle} (${index})`;
}

function renderRatingSegments(rating) {
  return rating.segments.map((fill) => `<span class="rating-segment" style="--fill:${fill}%"></span>`).join("");
}

function numericVoteValue(value) {
  const raw = metadataValue(value).replace(/\s+/g, "");
  const match = raw.match(/(\d+(?:[.,]\d+)?)([kкmм])?/i);
  if (!match) return 0;
  let count = Number(match[1].replace(",", "."));
  if (!Number.isFinite(count)) return 0;
  if (/^[kк]$/i.test(match[2] || "")) count *= 1000;
  if (/^[mм]$/i.test(match[2] || "")) count *= 1000000;
  return Math.round(count);
}

function voteRatingValue(likes, dislikes) {
  const likesCount = numericVoteValue(likes);
  const total = likesCount + numericVoteValue(dislikes);
  if (total <= 0) return "";
  return `${formatRatingScore(Math.max(0, Math.min(5, likesCount / total * 5)))} из 5`;
}

function displayRatingValue(entity) {
  entity = entity || {};
  const fromVotes = voteRatingValue(entity.likes, entity.dislikes);
  if (entity.source === "akniga") return fromVotes;
  return fromVotes || entity.rating || entity.schemaRating || "";
}

function ratingParts(value, maxHint) {
  const label = metadataValue(value);
  if (!label) return null;
  const parts = label.match(/\d+(?:[.,]\d+)?/g);
  if (!parts?.length) return null;
  const score = Number(parts[0].replace(",", "."));
  const hintedMax = Number(metadataValue(maxHint).replace(",", "."));
  const max = parts[1]
    ? Number(parts[1].replace(",", "."))
    : Number.isFinite(hintedMax) && hintedMax > 0
      ? hintedMax
      : score <= 5 ? 5 : 10;
  if (!Number.isFinite(score) || !Number.isFinite(max) || max <= 0) return null;
  const normalizedScore = Math.max(0, Math.min(5, score / max * 5));
  const percent = Math.round(Math.max(0, Math.min(100, (normalizedScore / 5) * 100)));
  return {
    label: `${formatRatingScore(normalizedScore)} из 5`,
    percent,
    score: normalizedScore,
    max: 5,
    segments: ratingSegments(normalizedScore, 5)
  };
}

function ratingSegments(score, max) {
  const starScore = (score / max) * 5;
  return Array.from({ length: 5 }, (_item, index) =>
    Math.round(Math.max(0, Math.min(1, starScore - index)) * 100)
  );
}

function formatRatingScore(value) {
  const rounded = Math.round(Number(value || 0) * 10) / 10;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}

function ratingStars(value, maxHint) {
  return ratingParts(value, maxHint);
}

function ratingDisplayValue(value, maxHint) {
  return ratingParts(value, maxHint)?.label || metadataValue(value);
}

function ratingScoreValue(value, maxHint) {
  const rating = ratingParts(value, maxHint);
  return rating ? rating.score / rating.max : 0;
}

function renderHealth() {
  $("#sourceHealth").innerHTML = SOURCES
    .filter((source) => state.selectedSources.has(source.id))
    .map((source) => {
      const health = state.liveHealth[source.id];
      const status = health?.status || (state.loading ? "warn" : "warn");
      const message = health?.message || (state.loading ? "загрузка..." : "запрос еще не выполнялся");
      return `
        <div class="health-item">
          <strong>${source.name}<span class="dot ${status}"></span></strong>
          <p>${escapeHtml(message)} • ${source.parser}</p>
        </div>`;
    }).join("");
}

function renderLiveNotice() {
  const notice = $("#liveNotice");
  notice.classList.remove("hidden");
  $("#liveUrls").textContent = SOURCES
    .filter((source) => state.selectedSources.has(source.id))
    .map((source) => {
      const health = state.liveHealth[source.id];
      const url = health?.url || buildSearchUrl(source, state.query || "полураспад");
      return `${source.name}: ${url}${health?.message ? `\n  ${health.message}` : ""}`;
    })
    .join("\n");
}

async function selectBook(id) {
  state.selectedId = id;
  const item = state.results.find((result) => result.id === id);
  if (!item) return;
  const source = sourceById(item.source);
  const parser = parsers[source.id] || normalizeParser();
  let bookDocument;
  let bookHtml;
  let details;
  let tracks;
  let detailsUrl = item.urlBook;

  state.currentDetails = {
    ...item,
    description: item.descriptionShort || "Загружаю страницу книги и список глав."
  };
  state.currentTracks = [];
  state.trackIndex = 0;
  state.position = 0;
  state.playing = false;
  resetAudioElement();
  state.bookLoading = true;
  state.view = "book";
  stopSpeech();
  renderResults();
  setView("book");
  renderDetails(state.currentDetails, [], source, parseHtml(""), "");
  setPlayerStatus("Загружаю главы со страницы источника.");

  try {
    const payload = await apiJson("/api/book", { source: source.id, url: item.urlBook }, 10000);
    if (state.selectedId !== id) return;
    bookHtml = payload.html || "";
    bookDocument = parseHtml(bookHtml);
    detailsUrl = payload.url || item.urlBook;
    details = {
      ...item,
      ...parseDetailsPayload(parser, payload, bookDocument, source, detailsUrl),
      mode: payload.mode || "live",
      liveUrl: detailsUrl
    };
    if (canMergeDetailsIntoResult(id)) {
      mergeDetailsIntoResult(id, details);
      renderResults();
    }
    state.currentDetails = details;
    state.currentTracks = [];
    setView("book");
    renderDetails(details, [], source, bookDocument, bookHtml);
    setPlayerStatus("Загружаю главы со страницы источника.");

    const adapterContext = {
      html: bookHtml,
      urlBook: detailsUrl,
      source,
      details,
      payload
    };
    const cyclePromise = fetchCycleItems(source, parser, details, detailsUrl);
    tracks = parseAudioPayload(parser, payload, adapterContext);
    if (!tracks.length) tracks = parseDirectAudio(bookDocument, payload.url || item.urlBook);
    if (!tracks.length && parser.enhancedAudio) {
      tracks = await parser.enhancedAudio(bookDocument, adapterContext);
    }
    if (!tracks.length) tracks = parseInlinePlayerHttpTracks(bookHtml, payload.url || item.urlBook);
    if (!tracks.length) tracks = await parser.audio(bookDocument, adapterContext);
    if (!tracks.length) tracks = await parseArchiveTracks(bookHtml);
    if (!tracks.length) tracks = parseLiteralMediaUrls(bookHtml, payload.url || item.urlBook);
    if (!tracks.length && parser.visibleChapters) {
      tracks = parser.visibleChapters(bookDocument, adapterContext);
    }
    if (!tracks.length) tracks = parseVisibleChapters(bookDocument);
    const cyclePatch = await cyclePromise;
    if (cyclePatch) details = { ...details, ...cyclePatch };
    details = applyPlaybackAccess(details, tracks, source);
  } catch (error) {
    if (state.selectedId !== id) return;
    bookHtml = "";
    bookDocument = parseHtml("");
    details = {
      ...item,
      mode: "live",
      description: `Не удалось загрузить страницу книги: ${error.message}`
    };
    tracks = [];
  }

  if (state.selectedId !== id) return;
  state.bookLoading = false;
  if (canMergeDetailsIntoResult(id)) mergeDetailsIntoResult(id, details);
  state.currentDetails = details;
  state.currentTracks = tracks;
  state.trackIndex = 0;
  state.position = 0;
  state.playing = false;
  state.view = "book";
  renderResults();
  setView("book");
  renderDetails(details, tracks, source, bookDocument, bookHtml);
  loadTrack(0, false);
}

async function fetchCycleItems(source, parser, details, urlBook) {
  if ((!parser.cycleItems && !parser.apiCycleItems) || !details.seriesUrl) return null;

  const key = cacheKey("cycle", source.id, details.seriesUrl);
  const cached = cacheGet(cycleCache, key);
  if (cached) return { cycleItems: cached };

  try {
    const payload = await apiJson("/api/book", { source: source.id, url: details.seriesUrl }, 7000);
    const document = parseHtml(payload.html || "");
    const cycleItems = parseCyclePayload(parser, payload, document, {
      source,
      details,
      urlBook,
      seriesUrl: payload.url || details.seriesUrl,
      payload
    });
    if (!Array.isArray(cycleItems) || !cycleItems.length) return null;
    cacheSet(cycleCache, key, cycleItems);
    return { cycleItems };
  } catch {
    return null;
  }
}

function resultIdForUrl(sourceId, urlBook) {
  let hash = 0;
  for (const char of String(urlBook || "")) {
    hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
  }
  return `open-${sourceId}-${Math.abs(hash)}`;
}

async function openSourceBook(sourceId, urlBook, seed = {}) {
  const source = sourceById(sourceId);
  if (!source || !urlBook) return;
  const existing = state.rawResults.find((item) => item.source === sourceId && sameBookUrl(item.urlBook, urlBook));
  if (existing) {
    await selectBook(existing.id);
    return;
  }

  const item = {
    id: resultIdForUrl(sourceId, urlBook),
    source: sourceId,
    sourceName: source.name,
    sourceColor: source.color,
    title: seed.title || "Загружаю книгу",
    urlBook,
    coverUrl: seed.coverUrl || "",
    author: seed.author || "",
    reader: seed.reader || "",
    series: seed.series || state.currentDetails?.series || "",
    seriesNumber: seed.index || seed.seriesNumber || "",
    durationText: seed.durationText || "",
    mode: "live",
    relevance: 1000
  };
  state.rawResults = [item].concat(state.rawResults.filter((result) => result.id !== item.id));
  state.results = [item].concat(state.results.filter((result) => result.id !== item.id));
  render();
  await selectBook(item.id);
}

function selectedCycleSourceIds(fallbackSourceId) {
  const selectedIds = SOURCES
    .filter((source) => state.selectedSources.has(source.id))
    .map((source) => source.id);
  if (selectedIds.length) return selectedIds;
  return fallbackSourceId ? [fallbackSourceId] : [];
}

function normalizedCycleName(value) {
  return metadataValue(value)
    .replace(/\(\d+\)\s*$/g, "")
    .replace(/ё/g, "е")
    .toLowerCase()
    .replace(/[«»"']/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function sameCycleName(left, right) {
  const leftName = normalizedCycleName(left);
  const rightName = normalizedCycleName(right);
  return Boolean(leftName && rightName && leftName === rightName);
}

function cycleResultFromItem(source, item, index, seriesName, seriesUrl, total) {
  return {
    id: item.url ? resultIdForUrl(source.id, item.url) : `cycle-${source.id}-${index}`,
    source: source.id,
    sourceName: source.name,
    sourceColor: source.color,
    title: metadataValue(item.title) || `Книга ${index + 1}`,
    urlBook: item.url || item.urlBook || "",
    coverUrl: item.coverUrl || "",
    author: item.author || "",
    authorUrl: item.authorUrl || "",
    reader: item.reader || "",
    readerUrl: item.readerUrl || "",
    durationText: item.durationText || "",
    publishedYear: item.publishedYear || item.publicationYear || "",
    audioYear: item.audioYear || "",
    rating: item.rating || item.schemaRating || "",
    schemaBestRating: item.schemaBestRating || "",
    isFragment: item.isFragment,
    accessRestricted: item.accessRestricted,
    series: seriesName,
    seriesUrl,
    seriesNumber: item.index || item.number || item.seriesNumber || "",
    mode: "live",
    relevance: Math.max(1, (total - index) * 10)
  };
}

async function loadExactCycleCatalog(source, parser, seriesUrl, seriesName) {
  const key = cacheKey("cycle", source.id, seriesUrl);
  let cycleItems = cacheGet(cycleCache, key);
  let resolvedUrl = seriesUrl;
  if (!cycleItems) {
    const payload = await apiJson("/api/book", { source: source.id, url: seriesUrl }, 7000);
    resolvedUrl = payload.url || seriesUrl;
    const document = parseHtml(payload.html || "");
    cycleItems = parseCyclePayload(parser, payload, document, {
      source,
      details: { series: seriesName, seriesUrl: resolvedUrl },
      urlBook: "",
      seriesUrl: resolvedUrl,
      payload
    });
    if (Array.isArray(cycleItems) && cycleItems.length) cacheSet(cycleCache, key, cycleItems);
  }
  const list = Array.isArray(cycleItems) ? cycleItems : [];
  return {
    items: list.map((item, index) => cycleResultFromItem(source, item, index, seriesName, resolvedUrl, list.length)).filter((item) => item.title || item.urlBook),
    health: {
      status: list.length ? "ok" : "warn",
      url: resolvedUrl,
      message: `цикл • ${list.length} книг`
    }
  };
}

async function loadCycleSearchCatalog(source, parser, seriesName, runId) {
  const searchUrl = buildSearchUrl(source, seriesName);
  const payload = await apiJson("/api/search", { source: source.id, q: seriesName, page: 1 }, 6500);
  const document = parseHtml(payload.html || "");
  const parsedItems = dedupeSearchItems(parseListPayload(parser, payload, document, source, {
    query: seriesName,
    primaryQuery: seriesName,
    cycleSearch: true,
    payload
  }));
  const baseItems = parsedItems.map((item, index) => ({
    ...item,
    id: `cycle-search-${source.id}-${index}`,
    sourceName: source.name,
    sourceColor: source.color,
    mode: payload.mode || "live",
    searchUrl: item.searchUrl || payload.url || searchUrl,
    relevance: scoreItem(item, seriesName, "series")
  })).filter((item) => item.title || item.urlBook);
  const enrichedItems = parser.enrichListItem
    ? await enrichSearchItems(source, parser, baseItems, runId)
    : baseItems;
  const matchedItems = enrichedItems.filter((item) => sameCycleName(item.series || item.cycle, seriesName));
  return {
    items: matchedItems,
    health: {
      status: matchedItems.length ? "ok" : "warn",
      url: payload.url || searchUrl,
      message: `поиск цикла • ${matchedItems.length} книг`
    }
  };
}

function searchInCatalog(value, kind = state.searchKind) {
  const cleanValue = metadataValue(value);
  if (!cleanValue) return;
  state.query = cleanValue;
  if (SEARCH_KINDS.has(kind)) state.searchKind = kind;
  $("#searchInput").value = cleanValue;
  state.view = "home";
  syncControls();
  setView("home");
  runSearch();
}

async function showCycleCatalog(sourceId, seriesUrl, seriesName) {
  const clickedSource = sourceById(sourceId);
  const cleanUrl = metadataValue(seriesUrl);
  const cleanName = metadataValue(seriesName);
  const clickedParser = parsers[sourceId] || normalizeParser();
  if (!clickedSource || !cleanUrl || (!clickedParser.cycleItems && !clickedParser.apiCycleItems)) {
    searchInCatalog(cleanName, "series");
    return;
  }

  const runId = ++state.searchRunId;
  const sourceIds = selectedCycleSourceIds(sourceId);
  state.query = cleanName;
  state.searchKind = "series";
  state.sort = "relevance";
  state.type = "all";
  state.rawResults = [];
  state.results = [];
  state.selectedId = null;
  state.bookLoading = false;
  state.loading = true;
  state.liveHealth = Object.fromEntries(sourceIds.map((id) => [id, {
      status: "warn",
      url: id === sourceId ? cleanUrl : buildSearchUrl(sourceById(id), cleanName),
      message: "загружаю цикл"
    }]));
  syncControls();
  setView("home");
  render();

  try {
    const results = await Promise.all(sourceIds.map(async (id) => {
      const source = sourceById(id);
      const parser = parsers[id] || normalizeParser();
      if (!source) return { id, items: [], health: { status: "warn", url: "", message: "источник не найден" } };
      if (id === sourceId && (parser.cycleItems || parser.apiCycleItems)) {
        return { id, ...(await loadExactCycleCatalog(source, parser, cleanUrl, cleanName)) };
      }
      return { id, ...(await loadCycleSearchCatalog(source, parser, cleanName, runId)) };
    }));
    if (runId !== state.searchRunId) return;
    state.loading = false;
    state.liveHealth = Object.fromEntries(results.map((result) => [result.id, result.health]));
    state.rawResults = results.flatMap((result) => result.items);
    applyResultView();
    setView("home");
    syncControls();
    render();
  } catch (error) {
    if (runId !== state.searchRunId) return;
    state.loading = false;
    state.liveHealth = {
      [clickedSource.id]: {
        status: "warn",
        url: cleanUrl,
        message: error.message
      }
    };
    render();
    searchInCatalog(cleanName, "series");
  }
}

function handleMetadataSearch(event, action) {
  event.preventDefault();
  event.stopPropagation();
  searchInCatalog(action.dataset.searchValue, action.dataset.searchKind);
}

function handleGlobalActionClick(event) {
  const action = event.target.closest("[data-card-action]");
  if (!action) return;
  const actionType = action.dataset.cardAction;
  if (actionType === "search") {
    handleMetadataSearch(event, action);
    return;
  }
  if (actionType === "show-cycle") {
    event.preventDefault();
    event.stopPropagation();
    showCycleCatalog(action.dataset.source, action.dataset.seriesUrl, action.dataset.seriesName);
    return;
  }
  if (actionType === "open") {
    event.preventDefault();
    event.stopPropagation();
    selectBook(action.dataset.id);
    return;
  }
  if (actionType === "cycle-open") {
    event.preventDefault();
    event.stopPropagation();
    openSourceBook(action.dataset.source, action.dataset.url, {
      title: action.dataset.title,
      index: action.dataset.index,
      author: action.dataset.author,
      reader: action.dataset.reader,
      coverUrl: action.dataset.cover
    });
  }
}

function parseDirectAudio(bookDocument, baseUrl) {
  return $$("audio[src], audio source[src], source[src][type^='audio']", bookDocument)
    .map((element, index) => {
      const src = element.getAttribute("src") || "";
      if (!src) return null;
      const container = element.closest("li, .chapter, .track, .audio, div") || element;
      const title = element.getAttribute("title") || text(container, ".title, .chapter-title, strong") || `Прямой audio URL ${index + 1}`;
      return {
        title,
        urlAudio: new URL(src, baseUrl).toString(),
        duration: durationToSeconds(element.getAttribute("data-duration") || element.getAttribute("duration") || 0),
        rawSource: "direct-media-url"
      };
    })
    .filter(Boolean);
}

function parseLiteralMediaUrls(html, baseUrl) {
  const urls = new Map();
  const mediaPattern = /(?:"|')([^"']+\.(?:mp3|m4a|ogg|aac)(?:\?[^"']*)?)(?:"|')/gi;
  let match;
  while ((match = mediaPattern.exec(html || ""))) {
    const rawUrl = match[1].replace(/\\\//g, "/");
    if (!/^(https?:)?\/\//i.test(rawUrl) && !rawUrl.startsWith("/")) continue;
    try {
      const url = new URL(rawUrl, baseUrl).toString();
      urls.set(url, {
        title: `Аудиодорожка ${urls.size + 1}`,
        urlAudio: url,
        duration: 0,
        rawSource: "literal-media-url"
      });
    } catch {
      // Ignore malformed URLs from scripts and ad snippets.
    }
  }
  return Array.from(urls.values());
}

function parseInlinePlayerHttpTracks(html, baseUrl = "") {
  const tracks = [];
  const normalized = String(html || "").replace(/\\\//g, "/");
  const playerScripts = Array.from(normalized.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi))
    .map((match) => match[1])
    .filter((script) => /(XSPlayer|Playerjs|BookPlayer|KB\.playerInit)/.test(script));

  function addTrack(track) {
    if (!track.urlAudio || tracks.some((item) => item.urlAudio === track.urlAudio)) return;
    tracks.push(track);
  }

  for (const script of playerScripts) {
    const bookPlayerIndex = script.indexOf("new BookPlayer");
    if (bookPlayerIndex >= 0) {
      const arrayStart = script.indexOf("[", bookPlayerIndex);
      const arrayText = arrayStart >= 0 ? extractBalanced(script, arrayStart, "[", "]") : "";
      const bookItems = parseJsonLike(arrayText);
      if (Array.isArray(bookItems)) {
        for (const item of bookItems) {
          const audioUrl = resolvePlayerAudioUrl(item.url || item.file || item.src, "", baseUrl);
          if (!audioUrl) continue;
          addTrack({
            title: normalizeText(item.title || item.player_data?.title) || `Глава ${tracks.length + 1}`,
            urlAudio: audioUrl,
            duration: durationToSeconds(item.duration || item.time || 0),
            rawSource: "BookPlayer"
          });
        }
      }
    }

    for (const match of script.matchAll(/KB\.playerInit\s*\(/g)) {
      const objectStart = script.indexOf("{", match.index);
      const objectText = objectStart >= 0 ? extractBalanced(script, objectStart, "{", "}") : "";
      const playerConfig = parseJsonLike(objectText);
      if (Array.isArray(playerConfig?.playlist)) {
        for (const item of playerConfig.playlist) {
          const audioUrl = resolvePlayerAudioUrl(item.src || item.file || item.url, "", baseUrl);
          if (!audioUrl) continue;
          addTrack({
            title: normalizeText(item.title) || `Глава ${tracks.length + 1}`,
            urlAudio: audioUrl,
            duration: durationToSeconds(item.duration || 0),
            rawSource: "KB.playerInit"
          });
        }
      }
    }

    for (const match of script.matchAll(/new\s+Playerjs\s*\(/g)) {
      const objectStart = script.indexOf("{", match.index);
      const objectText = objectStart >= 0 ? extractBalanced(script, objectStart, "{", "}") : "";
      const playerConfig = parseJsonLike(objectText);
      const fileValue = playerConfig?.file || playerConfig?.sources;
      const fileItems = Array.isArray(fileValue) ? fileValue : (typeof fileValue === "string" ? [{ file: fileValue }] : []);
      for (const item of fileItems) {
        const audioUrl = resolvePlayerAudioUrl(item.file || item.src || item.url, "", baseUrl);
        if (!audioUrl) continue;
        addTrack({
          title: normalizeText(item.title) || `Глава ${tracks.length + 1}`,
          urlAudio: audioUrl,
          duration: durationToSeconds(item.duration || 0),
          rawSource: "Playerjs"
        });
      }
    }

    const prefixMatch = script.match(/["']?mp3_url_prefix["']?\s*:\s*["']([^"']+)["']/i);
    const prefix = prefixMatch ? prefixMatch[1] : "";
    const xsTracks = Array.from(script.matchAll(/\[\s*\d+\s*,\s*"([^"]+)"\s*,\s*([\d.]+)\s*,\s*\d+\s*,\s*"([^"]+)"/gi));
    for (const match of xsTracks) {
      const audioUrl = resolvePlayerAudioUrl(match[3], prefix, baseUrl);
      if (!audioUrl) continue;
      addTrack({
        title: normalizeText(match[1]) || `Глава ${tracks.length + 1}`,
        urlAudio: audioUrl,
        duration: durationToSeconds(match[2]),
        rawSource: "XSPlayer"
      });
    }

    const genericUrls = Array.from(script.matchAll(/https?:\/\/[^"'\s<>]+/gi))
      .map((match) => match[0])
      .filter((url) => !/\.(?:js|css|png|jpe?g|webp|svg|gif|ico)(?:\?|$)/i.test(url))
      .filter((url) => /\.(?:mp3|m4a|ogg|aac)(?:\?|$)/i.test(url) || /litres\.ru\/audiotrial/i.test(url))
      .filter((url) => !/(google|yandex|metrika|liveinternet|adfinity|counter)/i.test(url));
    for (const url of genericUrls) {
      addTrack({
        title: `Поток ${tracks.length + 1}`,
        urlAudio: url,
        duration: 0,
        rawSource: "inline-player-url"
      });
    }
  }
  return tracks;
}

function resolvePlayerAudioUrl(rawUrl, rawPrefix = "", baseUrl = "") {
  const url = normalizeText(rawUrl).replace(/\\\//g, "/");
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  if (/^\/\//.test(url)) return `https:${url}`;
  const prefix = normalizeText(rawPrefix).replace(/\\\//g, "/");
  if (prefix && /\.(mp3|m4a|ogg|aac)(?:\?|$)/i.test(url)) {
    const absolutePrefix = /^https?:\/\//i.test(prefix)
      ? prefix
      : `https://${prefix.replace(/^\/+/, "")}`;
    return `${absolutePrefix.replace(/\/+$/, "")}/${url.replace(/^\/+/, "")}`;
  }
  if (baseUrl && (/^\//.test(url) || /\.(mp3|m4a|ogg|aac)(?:\?|$)/i.test(url))) {
    try {
      return new URL(url, baseUrl).toString();
    } catch {
      return "";
    }
  }
  return "";
}

function parseArchiveIdentifiers(html) {
  return Array.from(String(html || "").matchAll(/archive\.org\/embed\/([\w.-]+)/gi))
    .map((match) => match[1])
    .filter((identifier, index, all) => all.indexOf(identifier) === index);
}

async function parseArchiveTracks(html) {
  const identifiers = parseArchiveIdentifiers(html);
  const tracks = [];
  for (const identifier of identifiers) {
    const cached = cacheGet(archiveCache, identifier);
    if (cached) {
      tracks.push(...cloneTracks(cached));
      continue;
    }
    try {
      const payload = await apiJson("/api/archive", { identifier }, 12000);
      const files = payload.metadata?.files || [];
      const identifierTracks = [];
      for (const file of files) {
        const name = file.name || "";
        const format = file.format || "";
        if (!/\.(mp3|ogg|m4a|aac)$/i.test(name) && !/(MP3|Ogg|AAC|M4A)/i.test(format)) continue;
        const encodedName = name.split("/").map(encodeURIComponent).join("/");
        identifierTracks.push({
          title: normalizeText(file.title || name.replace(/\.(mp3|ogg|m4a|aac)$/i, "")) || `Archive track ${tracks.length + identifierTracks.length + 1}`,
          urlAudio: `https://archive.org/download/${identifier}/${encodedName}`,
          duration: durationToSeconds(file.length || file.duration || 0),
          rawSource: "archive.org-metadata"
        });
      }
      cacheSet(archiveCache, identifier, cloneTracks(identifierTracks));
      tracks.push(...identifierTracks);
    } catch {
      // Archive metadata is an optional public fallback for legacy embeds.
    }
  }
  return tracks;
}

function parseVisibleChapters(bookDocument) {
  const selectors = [
    "#player_playlist_inner > div",
    "[id^='playlist_item']",
    ".book_playlist_item",
    ".player--chapters .chapter__default",
    ".global__popup--content .chapter__default",
    ".PlayerPlaylistItem",
    ".PlaylistItem",
    ".chapters-list li",
    ".playlist li"
  ];
  const seen = new Set();
  const tracks = [];
  for (const selector of selectors) {
    for (const element of $$(selector, bookDocument)) {
      if (seen.has(element)) continue;
      seen.add(element);
      const title = text(element, "._5d2031, .chapter__default--title, .book_playlist_item_name, .PlayerPlaylistItemTitle, .playlist-item-title, .chapter-title, .title, strong, [class*='title'], [class*='name']") || text(element);
      const timeValue = text(element, "._b397de, .chapter__default--time, .book_playlist_item_time, .PlayerPlaylistItemDuration, .playlist-item-duration, .time, .duration, [class*='time'], [class*='duration']");
      const cleanTitle = normalizeText(title.replace(timeValue, ""));
      if (!cleanTitle || cleanTitle === "--:--") continue;
      tracks.push({
        title: cleanTitle,
        urlAudio: "",
        duration: durationToSeconds(timeValue),
        rawSource: "visible-chapter-list"
      });
    }
  }
  return tracks;
}

function trackSourceLabel(track, fallback = "видимые главы") {
  if (!track) return fallback;
  const adapterLabel = sourceAdapterById(track.source || state.currentDetails?.source)?.trackSourceLabel?.(track, fallback);
  if (adapterLabel) return adapterLabel;
  if (isExternalPlaybackTrack(track)) return "внешний плеер";
  return PLAYABLE_TRACK_SOURCES.has(track.rawSource) ? "media URL" : fallback;
}

function isExternalPlaybackTrack(track) {
  return Boolean(track?.externalUrl && !track?.urlAudio);
}

function renderDetails(details, tracks, source, bookDocument, bookHtml) {
  details.source = details.source || source.id;
  details.sourceName = details.sourceName || source.name;
  details.sourceColor = details.sourceColor || source.color;
  $("#emptyDetails").classList.add("hidden");
  $("#bookDetails").classList.remove("hidden");
  $("#detailCover").src = details.coverUrl || coverSvg(details.title, source);
  $("#detailSource").textContent = source.name;
  $("#detailSource").style.background = source.color;
  $("#detailTitle").textContent = details.title || "Без названия";
  document.title = details.title ? `${details.title} — Аудиокниги` : "Аудиокниги";
  $("#detailMeta").textContent = [details.author, details.reader, details.genre, formatDetailDuration(details.durationText)].filter(Boolean).join(" • ");
  $("#detailDescription").textContent = details.description || details.descriptionShort || "Описание не найдено.";

  const fields = detailFieldRows(details, source);

  $("#detailFields").innerHTML = fields.map(([key, value]) => `<dt>${escapeHtml(key)}</dt><dd>${renderDetailFieldValue(key, value, details)}</dd>`).join("");
  const cycleList = $("#cycleList");
  if (cycleList) {
    cycleList.innerHTML = renderCycleList(details, source);
    cycleList.classList.toggle("hidden", !cycleList.innerHTML);
  }
  const alternateReadings = $("#alternateReadings");
  if (alternateReadings) {
    alternateReadings.innerHTML = renderAlternateReadings(details, source);
    alternateReadings.classList.toggle("hidden", !alternateReadings.innerHTML);
  }

  const liveTrackSource = trackSourceLabel(tracks[0]);
  $("#audioContractBadge").textContent = state.bookLoading
    ? "загрузка глав..."
    : tracks.length
      ? `${tracks.length} глав • ${liveTrackSource}`
      : missingTracksBadge(bookDocument, bookHtml);
  $("#audioContractBadge").style.background = source.color;
  $("#chaptersList").innerHTML = tracks.length
    ? tracks.map((track, index) => `
      <div class="chapter-row ${isExternalPlaybackTrack(track) ? "external" : ""}">
        <button type="button" data-track="${index}" title="${isExternalPlaybackTrack(track) ? "Открыть на источнике" : "Воспроизвести"}">${index + 1}</button>
        <strong>${escapeHtml(track.title || `Глава ${index + 1}`)}</strong>
        <span>${formatDuration(track.duration)}</span>
      </div>`).join("")
    : `<div class="empty-state compact"><p>${state.bookLoading ? "Загружаю список глав и проверяю media URL." : escapeHtml(missingTracksMessage(source, bookDocument, bookHtml))}</p></div>`;
  $$("#chaptersList button").forEach((button) => {
    button.addEventListener("click", () => {
      loadTrack(Number(button.dataset.track), true);
    });
  });

  const selectorHealth = $("#selectorHealth");
  if (selectorHealth) {
    selectorHealth.innerHTML = source.selectors.map((selector) => {
      const ok = selectorHealthOk(selector, bookDocument, bookHtml);
      return `<div class="selector-row"><span class="dot ${ok ? "ok" : "warn"}"></span><code>${escapeHtml(selector)}</code></div>`;
    }).join("");
  }
}

function detailParserLabel(details, source) {
  if (details.mode === "api-first") return details.playbackMode || "api-first";
  if (details.mode === "live") return "HTML media / visible chapters";
  return details.mode || source.parser;
}

function detailFieldRows(details, source) {
  return [
    ["URL", details.urlBook],
    ["Автор", details.author],
    ["Чтец", details.reader],
    ["Жанр", details.genre],
    ["Категории", details.categories],
    ["Цикл", formatCycleLabel(details.series || details.cycle, details.seriesNumber || details.cycleNumber)],
    ["Номер в цикле", details.seriesNumber || details.cycleNumber],
    ["Время", formatDetailDuration(details.durationText)],
    ["Язык", details.language],
    ["Переводчик", details.translator],
    ["Оригинальное название", details.originalTitle],
    ["Год издания", details.publishedYear || details.publicationYear],
    ["Год озвучки", details.audioYear],
    ["Издательство", details.publisher],
    ["ISBN", details.isbn],
    ["Возраст", details.ageRestriction],
    ["Правообладатель", details.copyrightHolder],
    ["Студия озвучки", details.recordingStudio],
    ["Рейтинг", ratingDisplayValue(displayRatingValue(details), "5")],
    ["Количество оценок", details.ratingCount],
    ["Прослушивания", details.plays],
    ["Просмотры", details.views],
    ["Комментарии", details.comments],
    ["Лайки", details.likes],
    ["Дизлайки", details.dislikes],
    ["В избранном", details.favoriteCount],
    ["Постеры API", details.posterCount],
    ["Файлов API", details.apiFileCount],
    ["Дата добавления", details.addedAt],
    ["Дата обновления", details.updatedAt],
    ["Ограничение доступа", details.accessRestrictionText],
    ["На сайте", details.siteAccessText],
    ["В приложении", details.playbackAccessText],
    ["Фрагмент на сайте", details.isFragment ? "да" : "нет"],
    ["Бесплатный доступ", details.accessText],
    ["Характеристики", details.characteristics],
    ["Место действия", details.settingPlace],
    ["Время действия", details.settingTime],
    ["Сюжет", details.plotType],
    ["Book ID", details.bookId],
    ["API URL name", details.sourceUrlName],
    ["Источник", details.sourceName || source.name],
    ["Playback", details.playbackMode],
    ["Parser", detailParserLabel(details, source)]
  ].filter(([, value]) => value !== undefined && value !== null && value !== false && value !== "");
}

function detailFieldValue(value) {
  if (Array.isArray(value)) return value.map(detailFieldValue).filter(Boolean).join(", ");
  return String(value);
}

function renderDetailFieldValue(key, value, details) {
  const textValue = detailFieldValue(value);
  if (key === "Автор") return renderMetadataSearchButtons("author", textValue, "metadata-link detail-meta-link");
  if (key === "Чтец") return renderMetadataSearchButtons("reader", textValue, "metadata-link detail-meta-link");
  if (key === "Цикл") return renderCycleCatalogButton(details, sourceById(details.source || details.sourceId), textValue, "metadata-link detail-meta-link");
  return escapeHtml(textValue);
}

function sameBookUrl(left, right) {
  try {
    const leftUrl = new URL(left, window.location.origin);
    const rightUrl = new URL(right, window.location.origin);
    return leftUrl.hostname === rightUrl.hostname &&
      leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
  } catch {
    return false;
  }
}

function cycleItemCurrent(item, details) {
  const index = metadataValue(item.index || item.number);
  const currentNumber = metadataValue(details.seriesNumber || details.cycleNumber);
  const currentUrl = details.liveUrl || details.urlBook;
  if (item.url && currentUrl) return sameBookUrl(item.url, currentUrl);
  if (item.url) return false;
  return (index && currentNumber && index === currentNumber) || Boolean(item.current);
}

function renderCycleList(details, source) {
  const items = Array.isArray(details.cycleItems) ? details.cycleItems : [];
  const visibleItems = items.filter((item) => item && (item.title || item.url));
  if (!visibleItems.length) return "";

  return `
    <div class="cycle-list-head">
      <strong>Книги цикла</strong>
      <span>${visibleItems.length}</span>
    </div>
    <ol class="cycle-items">
      ${visibleItems.map((item) => {
        const index = metadataValue(item.index || item.number);
        const current = cycleItemCurrent(item, details);
        const title = metadataValue(item.title) || "Без названия";
        const content = `
          <span class="cycle-index">${escapeHtml(index || "—")}</span>
          <span class="cycle-title">${escapeHtml(title)}</span>`;
        if (item.url && !current) {
          return `<li><button class="cycle-item" type="button" data-card-action="cycle-open" data-source="${escapeHtml(source.id)}" data-url="${escapeHtml(item.url)}" data-title="${escapeHtml(title)}" data-index="${escapeHtml(index)}" data-author="${escapeHtml(item.author || "")}" data-reader="${escapeHtml(item.reader || "")}" data-cover="${escapeHtml(item.coverUrl || "")}">${content}</button></li>`;
        }
        return `<li><span class="cycle-item ${current ? "current" : ""}">${content}</span></li>`;
      }).join("")}
    </ol>`;
}

function alternateReadingsForDetails(details) {
  const explicit = Array.isArray(details.alternateReadings) ? details.alternateReadings : [];
  const currentNumber = metadataValue(details.seriesNumber || details.cycleNumber);
  const fromCycle = (Array.isArray(details.cycleItems) ? details.cycleItems : [])
    .filter((item) => item && !cycleItemCurrent(item, details) && metadataValue(item.index || item.number) === currentNumber);
  const seen = new Set();
  return explicit.concat(fromCycle).filter((item) => {
    const key = item.url || item.externalUrl || `${item.title}|${item.reader}`;
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function renderAlternateReadings(details, source) {
  const items = alternateReadingsForDetails(details);
  if (!items.length) return "";
  return `
    <div class="alternate-readings-head">
      <strong>Другие озвучки / варианты</strong>
      <span>${items.length}</span>
    </div>
    <div class="alternate-items">
      ${items.map((item) => {
        const title = metadataValue(item.title) || metadataValue(item.reader) || "Вариант озвучки";
        const reader = metadataValue(item.reader);
        const body = `
          <span class="alternate-title">${escapeHtml(title)}</span>
          ${reader && reader !== title ? `<span class="alternate-reader">${escapeHtml(reader)}</span>` : ""}`;
        if (item.url) {
          return `<button class="alternate-item" type="button" data-card-action="cycle-open" data-source="${escapeHtml(source.id)}" data-url="${escapeHtml(item.url)}" data-title="${escapeHtml(title)}" data-index="${escapeHtml(item.index || "")}" data-author="${escapeHtml(item.author || "")}" data-reader="${escapeHtml(reader)}" data-cover="${escapeHtml(item.coverUrl || "")}">${body}</button>`;
        }
        return `<span class="alternate-item muted">${body}</span>`;
      }).join("")}
    </div>`;
}

function missingTracksMessage(source, document, html) {
  const sourceHtml = String(html || "");
  const pageText = normalizeText(document?.body?.textContent || "");
  if (/book_blocked|blocked['"]?\s*:\s*true|Доступ к аудиокниге ограничен/i.test(sourceHtml + pageText)) {
    return "Источник пометил книгу как ограниченную и не отдал список глав в HTML.";
  }
  if (/strDecode\s*\(/i.test(sourceHtml)) {
    return "На странице найден strDecode-плейлист: сайт строит главы после выполнения своего JS-плеера, готового списка глав в сыром HTML нет.";
  }
  if (/LIVESTREET_SECURITY_KEY|ajax\/b/i.test(sourceHtml)) {
    return "Источник использует внутреннюю загрузку аудио; в HTML нет готового списка глав для этой карточки.";
  }
  if (/Слушать полностью|Купить аудиокнигу|partner|litres/i.test(sourceHtml + pageText)) {
    return "Источник отдал только промо/покупку без списка глав для HTML5-плеера.";
  }
  return "Источник не отдал список глав или воспроизводимый audio URL для этой карточки.";
}

function missingTracksBadge(document, html) {
  const sourceHtml = String(html || "");
  const pageText = normalizeText(document?.body?.textContent || "");
  if (/book_blocked|blocked['"]?\s*:\s*true|Доступ к аудиокниге ограничен/i.test(sourceHtml + pageText)) {
    return "доступ ограничен";
  }
  if (/strDecode\s*\(/i.test(sourceHtml)) return "strDecode / JS-плеер";
  if (/LIVESTREET_SECURITY_KEY|ajax\/b/i.test(sourceHtml)) return "внутренний AJAX";
  if (/Слушать полностью|Купить аудиокнигу|partner|litres/i.test(sourceHtml + pageText)) return "нет глав в HTML";
  return "главы не найдены";
}

function selectorHealthOk(selector, document, html) {
  if (html.includes(selector)) return true;
  if (selector.startsWith("http") || selector.includes("ajax") || selector.includes("?") || selector.includes("=")) return false;
  try {
    return Boolean($(selector, document));
  } catch {
    return false;
  }
}

function currentTrack() {
  return state.currentTracks[state.trackIndex];
}

function isDirectHttpAudio(track) {
  return PLAYABLE_TRACK_SOURCES.has(track?.rawSource) && /^https?:\/\//i.test(track.urlAudio || "");
}

function unavailableAudioMessage(track) {
  if (track?.rawSource === "visible-chapter-list") {
    return "Источник отдал только видимый список глав; прямой audio URL загружается его внутренним плеером и в HTML отсутствует.";
  }
  if (track?.rawSource === "strDecode") {
    return "Источник отдал strDecode-плейлист, но не готовый прямой audio URL для HTML5-плеера.";
  }
  return "Для этой главы источник не отдал воспроизводимый audio URL.";
}

function setPlayerStatus(message, status = "") {
  const el = $("#playerStatus");
  if (!el) return;
  el.textContent = message;
  el.className = `player-status ${status}`.trim();
}

function resetAudioElement() {
  clearInterval(state.timer);
  clearTimeout(state.loadTimer);
  const audio = $("#audioElement");
  if (!audio) return;
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
}

function currentAudioDuration() {
  const audio = $("#audioElement");
  const audioDuration = Number.isFinite(audio.duration) ? audio.duration : 0;
  return Math.floor(currentTrack()?.duration || audioDuration || 0);
}

function audioUrlsForTrack(track) {
  const urls = [];
  const primaryUrl = preferredAudioUrl(track?.urlAudio || "");
  if (primaryUrl) urls.push(primaryUrl);
  if (track?.urlAudio && track.urlAudio !== primaryUrl) urls.push(track.urlAudio);
  for (const url of audioMirrorUrls(primaryUrl || track?.urlAudio || "")) urls.push(url);
  return urls.filter((url, index, all) => url && all.indexOf(url) === index);
}

function preferredAudioUrl(url) {
  return String(url || "").replace(/^https:\/\/d(\d+)\.audioknigi\.xyz\//i, "https://r$1.audioknigi.xyz/");
}

function audioMirrorUrls(url) {
  const match = String(url || "").match(/^https:\/\/([dr])(\d+)\.audioknigi\.xyz(\/.+)$/i);
  if (!match) return [];
  const [, prefix, number, path] = match;
  const nextPrefix = prefix.toLowerCase() === "d" ? "r" : "d";
  return [`https://${nextPrefix}${number}.audioknigi.xyz${path}`];
}

function scheduleAudioFallback() {
  clearTimeout(state.loadTimer);
  state.loadTimer = window.setTimeout(() => {
    const audio = $("#audioElement");
    if (state.playing && audio.readyState === 0 && !audio.currentTime) {
      if (!tryAudioFallback("audio host не отдал metadata")) {
        state.playing = false;
        setPlayerStatus("Источник отдал ссылку, но браузер не смог загрузить поток.", "bad");
        updatePlayer();
      }
    }
  }, 2500);
}

function tryAudioFallback(reason) {
  const track = currentTrack();
  const audio = $("#audioElement");
  const urls = audioUrlsForTrack(track);
  const current = audio.currentSrc || audio.src || track?.urlAudio || "";
  const currentIndex = urls.indexOf(current);
  const nextUrl = urls[currentIndex + 1] || (currentIndex < 0 ? urls.find((url) => url !== current) : "");
  if (!track || !nextUrl) return false;
  audio.src = nextUrl;
  audio.playbackRate = state.speed;
  audio.load();
  setPlayerStatus(`Пробую зеркало: ${reason}.`, "warn");
  if (state.playing) {
    audio.play().catch((error) => {
      state.playing = false;
      setPlayerStatus(`Не удалось запустить аудио: ${error.message}`, "bad");
      updatePlayer();
    });
    scheduleAudioFallback();
  }
  return true;
}

function loadTrack(index, autoplay = false) {
  const nextIndex = Math.max(0, Math.min(index, state.currentTracks.length - 1));
  state.trackIndex = nextIndex;
  state.position = 0;
  resetAudioElement();
  const audio = $("#audioElement");
  state.playing = false;
  updatePlayer();
  const track = currentTrack();
  if (!track) {
    setPlayerStatus("Выберите главу для воспроизведения.");
    return;
  }
  if (!isDirectHttpAudio(track)) {
    setPlayerStatus(unavailableAudioMessage(track), "warn");
    return;
  }
  audio.src = audioUrlsForTrack(track)[0] || track.urlAudio;
  audio.playbackRate = state.speed;
  audio.load();
  setPlayerStatus("Глава готова к воспроизведению.", "ok");
  persistPlayerState();
  if (autoplay) startPlayback();
}

function updatePlayer() {
  syncGlobalUiState();
  const track = currentTrack();
  const details = state.currentDetails || {};
  const source = sourceById(details.source) || { color: details.sourceColor || "#7c3aed", name: details.sourceName || "Источник" };
  $("#nowTrackIndex").textContent = track ? `Глава ${state.trackIndex + 1}` : "-";
  $("#nowTrackTitle").textContent = track?.title || "Глава не выбрана";
  const miniTitle = $("#miniBookTitle");
  if (miniTitle) miniTitle.textContent = details.title ? `${details.title}${source.name ? ` • ${source.name}` : ""}` : "Выберите книгу для прослушивания";
  const miniCover = $("#miniCover");
  if (miniCover) {
    const cover = details.coverUrl || (details.title ? coverSvg(details.title, source) : "");
    miniCover.style.backgroundImage = cover ? `url("${cover.replaceAll('"', '%22')}")` : "";
  }
  const duration = currentAudioDuration();
  $("#timeCurrent").textContent = formatTime(state.position);
  $("#timeEnd").textContent = formatDuration(duration);
  $("#seekSlider").max = String(duration || Math.max(100, Math.ceil(state.position), 1));
  $("#seekSlider").value = String(Math.min(state.position, duration || Math.max(100, Math.ceil(state.position), 1)));
  $("#playPause").textContent = state.playing ? "⏸" : "▶";
  refreshChapterRows();
}

function refreshChapterRows() {
  $$("#chaptersList .chapter-row").forEach((row, index) => {
    row.classList.toggle("active", index === state.trackIndex);
    const durationEl = $("span", row);
    if (durationEl) durationEl.textContent = formatDuration(state.currentTracks[index]?.duration || 0);
  });
}

function startPlayback() {
  const track = currentTrack();
  if (!track) return;
  const audio = $("#audioElement");
  if (!isDirectHttpAudio(track)) {
    setPlayerStatus(unavailableAudioMessage(track), "warn");
    updatePlayer();
    return;
  }
  const urls = audioUrlsForTrack(track);
  const primaryUrl = urls[0] || track.urlAudio;
  if (!audio.src || audio.src !== primaryUrl) {
    audio.src = primaryUrl;
    audio.load();
  }
  audio.playbackRate = state.speed;
  if (state.position && Math.abs((audio.currentTime || 0) - state.position) > 2) {
    audio.currentTime = state.position;
  }
  state.playing = true;
  setPlayerStatus("Загружаю аудио...", "ok");
  persistPlayerState();
  scheduleAudioFallback();
  audio.play().catch((error) => {
    state.playing = false;
    clearTimeout(state.loadTimer);
    setPlayerStatus(`Не удалось запустить аудио: ${error.message}`, "bad");
    updatePlayer();
  });
  clearInterval(state.timer);
  state.timer = setInterval(() => {
    state.position = audio.currentTime || state.position;
    const duration = currentAudioDuration();
    if (duration && state.position >= duration) {
      if (state.trackIndex < state.currentTracks.length - 1) {
        loadTrack(state.trackIndex + 1, true);
      } else {
        state.position = duration;
        pausePlayback();
      }
    }
    updatePlayer();
  }, 1000);
}

function pausePlayback() {
  state.playing = false;
  clearInterval(state.timer);
  clearTimeout(state.loadTimer);
  $("#audioElement").pause();
  setPlayerStatus(currentTrack() ? "Пауза." : "Выберите главу для воспроизведения.");
  persistPlayerState();
  updatePlayer();
}

function speakPreview(track) {
  stopSpeech();
  if (!("speechSynthesis" in window)) return;
  const textValue = `${track.title}. ${state.currentDetails?.description || ""}`.slice(0, 220);
  const utterance = new SpeechSynthesisUtterance(textValue);
  utterance.lang = "ru-RU";
  utterance.rate = Math.min(1.4, Math.max(0.8, state.speed));
  window.speechSynthesis.speak(utterance);
}

function stopSpeech() {
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function exportJson() {
  const payload = {
    mode: state.mode,
    query: state.query,
    results: state.results,
    selected: state.currentDetails,
    tracks: state.currentTracks.map((track) => ({ ...track, urlAudio: track.urlAudio ? "[redacted]" : "" }))
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "audiobooks-source-test.json";
  link.click();
  URL.revokeObjectURL(url);
}

function bindEvents() {
  document.addEventListener("click", handleGlobalActionClick);
  $("#themeToggle")?.addEventListener("click", toggleTheme);
  $$("[data-view]").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });
  $("#backToResults").addEventListener("click", () => setView("home"));
  $("#runSearch").addEventListener("click", runSearch);
  $("#searchInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") runSearch();
  });
  $$("input[name='searchKind']").forEach((input) => {
    input.addEventListener("change", runSearch);
  });
  $("#sortSelect").addEventListener("change", (event) => {
    state.sort = event.target.value;
    applyResultView();
    render();
  });
  $("#typeSelect").addEventListener("change", (event) => {
    state.type = event.target.value;
    applyResultView();
    render();
  });
  $("#sourceFilters").addEventListener("change", runSearch);
  $("#exportJson").addEventListener("click", exportJson);

  $("#playPause").addEventListener("click", () => (state.playing ? pausePlayback() : startPlayback()));
  $("#prevTrack").addEventListener("click", () => {
    loadTrack(Math.max(0, state.trackIndex - 1), state.playing);
  });
  $("#nextTrack").addEventListener("click", () => {
    loadTrack(Math.min(state.currentTracks.length - 1, state.trackIndex + 1), state.playing);
  });
  $("#rewindTrack").addEventListener("click", () => {
    state.position = Math.max(0, state.position - 10);
    if (isDirectHttpAudio(currentTrack())) $("#audioElement").currentTime = state.position;
    persistPlayerState();
    updatePlayer();
  });
  $("#forwardTrack").addEventListener("click", () => {
    const duration = currentAudioDuration();
    state.position = duration ? Math.min(duration, state.position + 30) : state.position + 30;
    if (isDirectHttpAudio(currentTrack())) $("#audioElement").currentTime = state.position;
    persistPlayerState();
    updatePlayer();
  });
  $("#seekSlider").addEventListener("input", (event) => {
    state.position = Number(event.target.value);
    if (isDirectHttpAudio(currentTrack())) $("#audioElement").currentTime = state.position;
    persistPlayerState();
    updatePlayer();
  });
  $("#speedSelect").addEventListener("change", (event) => {
    state.speed = Number(event.target.value);
    $("#audioElement").playbackRate = state.speed;
    persistPlayerState();
  });
  $("#audioElement").addEventListener("loadedmetadata", (event) => {
    clearTimeout(state.loadTimer);
    if (state.position && Math.abs((event.target.currentTime || 0) - state.position) > 2) {
      try { event.target.currentTime = state.position; } catch { /* ignore seek errors */ }
    }
    const track = currentTrack();
    if (isDirectHttpAudio(track) && Number.isFinite(event.target.duration)) {
      track.duration = Math.floor(event.target.duration);
      updatePlayer();
    }
  });
  $("#audioElement").addEventListener("durationchange", (event) => {
    if (Number.isFinite(event.target.duration)) clearTimeout(state.loadTimer);
    const track = currentTrack();
    if (isDirectHttpAudio(track) && Number.isFinite(event.target.duration)) {
      track.duration = Math.floor(event.target.duration);
      updatePlayer();
    }
  });
  $("#audioElement").addEventListener("timeupdate", (event) => {
    if (isDirectHttpAudio(currentTrack())) {
      state.position = event.target.currentTime || 0;
      if (state.playing && state.position > 0) setPlayerStatus("Воспроизведение.", "ok");
      if (Math.floor(state.position) % 10 === 0) persistPlayerState();
      updatePlayer();
    }
  });
  $("#audioElement").addEventListener("canplay", () => {
    clearTimeout(state.loadTimer);
    if (!state.playing) setPlayerStatus("Глава готова к воспроизведению.", "ok");
  });
  $("#audioElement").addEventListener("playing", () => {
    clearTimeout(state.loadTimer);
    state.playing = true;
    setPlayerStatus("Воспроизведение.", "ok");
    updatePlayer();
  });
  $("#audioElement").addEventListener("ended", () => {
    if (state.trackIndex < state.currentTracks.length - 1) {
      loadTrack(state.trackIndex + 1, true);
    } else {
      pausePlayback();
    }
  });
  $("#audioElement").addEventListener("error", () => {
    if (tryAudioFallback("браузер не смог открыть первый URL")) return;
    clearTimeout(state.loadTimer);
    state.playing = false;
    const track = currentTrack();
    setPlayerStatus(track ? "Источник отдал ссылку, но браузер не смог воспроизвести этот поток." : "Ошибка аудио.", "bad");
    updatePlayer();
  });

  window.addEventListener("keydown", (event) => {
    const tag = (event.target?.tagName || "").toLowerCase();
    if (tag === "input" || tag === "select" || tag === "textarea") return;
    if (!currentTrack()) return;
    if (event.code === "Space") {
      event.preventDefault();
      state.playing ? pausePlayback() : startPlayback();
    }
    if (event.code === "ArrowLeft") {
      event.preventDefault();
      state.position = Math.max(0, state.position - 10);
      if (isDirectHttpAudio(currentTrack())) $("#audioElement").currentTime = state.position;
      updatePlayer();
    }
    if (event.code === "ArrowRight") {
      event.preventDefault();
      const duration = currentAudioDuration();
      state.position = duration ? Math.min(duration, state.position + 30) : state.position + 30;
      if (isDirectHttpAudio(currentTrack())) $("#audioElement").currentTime = state.position;
      updatePlayer();
    }
  });
}

async function init() {
  await loadSourceAdapters();
  state.selectedSources = new Set(SOURCES.map((source) => source.id));
  readInitialParams();
  renderSourceFilters();
  syncControls();
  bindEvents();
  restorePlayerState();
  runSearch();
}

init().catch((error) => {
  console.error(error);
  document.body.innerHTML = `
    <main class="site-main">
      <section class="empty-state">
        <h2>Не удалось загрузить адаптеры источников</h2>
        <p>${escapeHtml(error.message)}</p>
      </section>
    </main>`;
});
