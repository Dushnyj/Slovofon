from urllib import parse
import re


SOURCE = {
    "name": "Книгоблуд",
    "host": "https://www.knigoblud.club",
    "hosts": {"knigoblud.club", "www.knigoblud.club"},
    "search": "https://www.knigoblud.club/search?q={q}&page={page}",
    "color": "#315f8f",
    "parser": "KB.playerInit",
    "media_origin": "https://www.knigoblud.club",
}


def _normalize_host(host):
    return (host or "").split(":", 1)[0].lower()


def validate_media_url(url):
    parsed = parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https media URLs are allowed")
    host = _normalize_host(parsed.netloc)
    if host in {"litres.ru", "www.litres.ru"}:
        if parsed.path == "/audiotrial/" or re.fullmatch(r"/get_mp3_trial/\d+\.mp3", parsed.path or ""):
            return parsed.geturl()
        raise ValueError("only LitRes audio trial URLs are allowed")
    if host != "audioknigi.xyz" and not host.endswith(".audioknigi.xyz"):
        raise ValueError("media URL host is outside the Knigoblud media allowlist")
    if not re.search(r"\.(mp3|m4a|ogg|aac)(?:$|\?)", parsed.path, flags=re.I):
        raise ValueError("media URL is not an audio file")
    return parsed.geturl()
