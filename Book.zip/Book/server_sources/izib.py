import base64
import hashlib
import json
import re
import subprocess
from urllib import error, parse, request


API_URL = "https://api.izib.uk/graphql/"
PACKAGE_NAME = "com.izimobile"
IZIB_PACKAGE_KEY = base64.b64encode(hashlib.sha256(PACKAGE_NAME.encode("utf-8")).digest()).decode("ascii")
API_TIMEOUT_SECONDS = 8

BOOK_COMMON_FRAGMENT = """fragment BookCommon on Book {
  id
  name
  urlName
  defaultPoster
  defaultPosterMain
  totalDuration
  plays
  views
  comments
  likes
  dislikes
  posters
  publishTs
  aboutBb
  serieIndex
  genre { id name booksCount __typename }
  authors { id name surname booksCount __typename }
  readers { id name surname booksCount __typename }
  serie { id name booksCount __typename }
  __typename
}"""

FILE_FRAGMENT = """fragment File on BookFile {
  id
  index
  title
  fileName
  duration
  url
  size
  __typename
}"""

SEARCH_BOOKS_QUERY = f"""query booksSearch($q: String!, $offset: Int, $count: Int) {{
  booksSearch(q: $q, offset: $offset, count: $count) {{
    count
    items {{
      ...BookCommon
      __typename
    }}
    __typename
  }}
}}

{BOOK_COMMON_FRAGMENT}
"""

BOOK_QUERY = f"""query bookQuery($id: Int!) {{
  book(id: $id) {{
    ...BookCommon
    favored
    files {{
      full {{
        ...File
        __typename
      }}
      mobile {{
        ...File
        __typename
      }}
      __typename
    }}
    __typename
  }}
}}

{BOOK_COMMON_FRAGMENT}

{FILE_FRAGMENT}
"""

SERIE_QUERY = f"""query serieQuery($id: Int!) {{
  booksBySerie(id: $id) {{
    index
    book {{
      ...BookCommon
      __typename
    }}
    otherVoices {{
      ...BookCommon
      __typename
    }}
    __typename
  }}
}}

{BOOK_COMMON_FRAGMENT}
"""


SOURCE = {
    "name": "Изибук",
    "host": "https://izib.uk",
    "hosts": {"izib.uk", "www.izib.uk", "pda.izib.uk"},
    "search": "https://izib.uk/search?q={q}&p={page}",
    "color": "#7d5a9d",
    "parser": "XSPlayer",
}


class IzibApiError(RuntimeError):
    pass


def izib_sign(body):
    return base64.b64encode(hashlib.sha256(IZIB_PACKAGE_KEY.encode("utf-8") + body.encode("utf-8")).digest()).decode("ascii")


def graphql_body(operation_name, variables, query):
    return json.dumps(
        {"operationName": operation_name, "variables": variables, "query": query},
        ensure_ascii=False,
        separators=(",", ":"),
    )


def extract_api_book_id(url):
    match = re.search(r"/art(\d+)(?:\D|$)", url or "")
    if not match:
        raise IzibApiError("izib api book id not found in URL")
    return int(match.group(1))


def extract_api_serie_id(url):
    match = re.search(r"/serie/(\d+)(?:\D|$)", url or "")
    if not match:
        return None
    return int(match.group(1))


def api_book_url(book):
    book_id = str((book or {}).get("id") or "").strip()
    if not book_id.isdigit():
        return ""
    return f"{SOURCE['host']}/art{book_id}"


def api_serie_url(serie):
    serie_id = str((serie or {}).get("id") or "").strip()
    if not serie_id.isdigit():
        return ""
    return f"{SOURCE['host']}/serie/{serie_id}"


def api_book_serie_items(book):
    serie = (book or {}).get("serie") or {}
    serie_id = str(serie.get("id") or "").strip()
    if not serie_id.isdigit():
        return []
    try:
        data = graphql("serieQuery", {"id": int(serie_id)}, SERIE_QUERY)
        return data.get("booksBySerie") or []
    except Exception:
        return []


def graphql(operation_name, variables, query):
    body = graphql_body(operation_name, variables, query)
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "SIGN": izib_sign(body),
        "User-Agent": "com.izimobile/1.11 Android",
    }
    req = request.Request(API_URL, data=body.encode("utf-8"), headers=headers, method="POST")
    try:
        with request.urlopen(req, timeout=API_TIMEOUT_SECONDS) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
    except Exception as exc:
        payload = graphql_with_curl(body, headers, exc)

    if payload.get("errors"):
        message = "; ".join(error.get("message") or json.dumps(error, ensure_ascii=False) for error in payload["errors"])
        raise IzibApiError(message)
    data = payload.get("data")
    if not isinstance(data, dict):
        raise IzibApiError("izib api returned no data")
    return data


def graphql_with_curl(body, headers, original_error):
    command = [
        "curl.exe",
        "--silent",
        "--show-error",
        "--location",
        "--ssl-no-revoke",
        "--http1.1",
        "--max-time",
        str(API_TIMEOUT_SECONDS),
        "--request",
        "POST",
        "--header",
        f"Accept: {headers['Accept']}",
        "--header",
        f"Content-Type: {headers['Content-Type']}",
        "--header",
        f"SIGN: {headers['SIGN']}",
        "--user-agent",
        headers["User-Agent"],
        "--data-binary",
        body,
        API_URL,
    ]
    try:
        completed = subprocess.run(command, capture_output=True, timeout=API_TIMEOUT_SECONDS + 4, check=False)
    except Exception as exc:
        raise IzibApiError(str(original_error)) from exc

    if completed.returncode != 0:
        raise IzibApiError(completed.stderr.decode("utf-8", errors="replace") or str(original_error))
    try:
        return json.loads(completed.stdout.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise IzibApiError(f"izib api returned non-json response: {exc}") from exc


def search_api(query, page=1, count=20):
    try:
        page_num = max(1, int(page or 1))
    except ValueError:
        page_num = 1
    offset = (page_num - 1) * count
    data = graphql("booksSearch", {"q": query, "offset": offset, "count": count}, SEARCH_BOOKS_QUERY)
    collection = data.get("booksSearch") or {}
    return {
        "ok": True,
        "status": 200,
        "url": f"{API_URL}#booksSearch",
        "mode": "api-first",
        "api": {
            "provider": "izib",
            "kind": "search",
            "query": query,
            "page": page_num,
            "count": collection.get("count", 0),
            "items": collection.get("items") or [],
        },
    }


def book_api(url):
    serie_id = extract_api_serie_id(url)
    if serie_id:
        data = graphql("serieQuery", {"id": serie_id}, SERIE_QUERY)
        return {
            "ok": True,
            "status": 200,
            "url": f"{API_URL}#booksBySerie/{serie_id}",
            "mode": "api-first",
            "api": {
                "provider": "izib",
                "kind": "serie",
                "sourceUrl": url,
                "items": data.get("booksBySerie") or [],
            },
        }

    book_id = extract_api_book_id(url)
    data = graphql("bookQuery", {"id": book_id}, BOOK_QUERY)
    book = data.get("book")
    if not book:
        raise IzibApiError(f"izib book not found: {book_id}")
    return {
        "ok": True,
        "status": 200,
        "url": api_book_url(book) or url,
        "mode": "api-first",
        "api": {
            "provider": "izib",
            "kind": "book",
            "sourceUrl": url,
            "book": book,
            "serieItems": api_book_serie_items(book),
        },
    }
