import re
from urllib import parse


SOURCE = {
    "name": "КнигаВУхе",
    "host": "https://knigavuhe.org",
    "hosts": {"knigavuhe.org", "www.knigavuhe.org"},
    "search": "https://knigavuhe.org/search/?q={q}&page={page}",
    "color": "#176b87",
    "parser": "BookPlayer",
}


def _normalize_host(netloc):
    return (netloc or "").split(":", 1)[0].lower()


def validate_media_url(url):
    parsed = parse.urlparse(url or "")
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https media URLs are allowed")

    host = _normalize_host(parsed.netloc)
    if host in {"litres.ru", "www.litres.ru"}:
        if parsed.path == "/audiotrial/" or re_match_litres_trial_path(parsed.path):
            return parsed.geturl()
        raise ValueError("only LitRes audio trial URLs are allowed")

    if host != "knigavuhe.org" and not host.endswith(".knigavuhe.org"):
        raise ValueError("media URL host is outside KnigaVuhe allowlist")

    if not parsed.path.lower().endswith((".mp3", ".m4a", ".ogg", ".aac")):
        raise ValueError("media URL is not an audio file")

    return parsed.geturl()


def re_match_litres_trial_path(path):
    return bool(re.fullmatch(r"/get_mp3_trial/\d+\.mp3", path or ""))
