from importlib import import_module
from pathlib import Path
from pkgutil import iter_modules


SOURCE_ORDER = [
    "knigavuhe",
    "izib",
    "akniga",
    "baza_knig",
    "knigoblud",
    "yakniga",
]


def _sort_key(module_info):
    try:
        return (SOURCE_ORDER.index(module_info.name), module_info.name)
    except ValueError:
        return (len(SOURCE_ORDER), module_info.name)


def _load_sources():
    sources = {}
    package_dir = Path(__file__).resolve().parent
    for module_info in sorted(iter_modules([str(package_dir)]), key=_sort_key):
        if module_info.name.startswith("_"):
            continue
        module = import_module(f"{__name__}.{module_info.name}")
        source = dict(getattr(module, "SOURCE", {}))
        if not source:
            continue
        source.setdefault("id", module_info.name)
        source.setdefault("client_adapter", source["id"])
        source["hosts"] = set(source.get("hosts", set()))
        if hasattr(module, "validate_media_url"):
            source["validate_media_url"] = module.validate_media_url
        sources[source["id"]] = source
    return sources


SOURCES = _load_sources()
