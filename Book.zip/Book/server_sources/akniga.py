import base64
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
import re
import urllib3
from urllib import parse

import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


SOURCE = {
    "name": "Akniga",
    "host": "https://akniga.org",
    "hosts": {"akniga.org", "www.akniga.org"},
    "search": "https://akniga.org/search/books/page{page}/?q={q}",
    "color": "#247a4d",
    "parser": "ajax/bid contract",
}

SITE_URL = "https://akniga.org"
SECRET_PASSPHRASE = "EKxtcg46V"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/125.0 Safari/537.36"
)

MP3_DURATION_PROBE_LIMIT = 3

MEDIA_HOST_ALLOWLIST = {
    "akniga.org",
    "www.akniga.org",
    "h5.akniga.club",
    "h5.akniga.club",
}


def _normalize_host(netloc):
    return (netloc or "").split(":", 1)[0].lower()


def _is_allowed_media_host(host):
    host = _normalize_host(host)
    if host in MEDIA_HOST_ALLOWLIST:
        return True
    return (
        host.endswith(".akniga.club")
        or host.endswith(".audioknigi.xyz")
        or host.endswith(".akniga.org")
    )


def _headers(referer=None):
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    return headers


def _evp_bytes_to_key(password, salt, key_len=32, iv_len=16):
    """
    Совместимо с CryptoJS.AES.encrypt(message, passphrase).
    CryptoJS passphrase mode использует OpenSSL-compatible MD5 KDF.
    """
    data = b""
    previous = b""

    while len(data) < key_len + iv_len:
        previous = hashlib.md5(previous + password + salt).digest()
        data += previous

    return data[:key_len], data[key_len:key_len + iv_len]


def _cryptojs_aes_encrypt_to_json(message, passphrase):
    salt = os.urandom(8)
    key, iv = _evp_bytes_to_key(passphrase.encode("utf-8"), salt)

    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(message.encode("utf-8"), AES.block_size))

    return {
        "ct": base64.b64encode(ciphertext).decode("utf-8"),
        "iv": iv.hex(),
        "s": salt.hex(),
    }


def _make_security_params(book_id, security_ls_key):
    # В Swift-библиотеке шифруется строка с кавычками вокруг ключа.
    encrypted = _cryptojs_aes_encrypt_to_json(f'"{security_ls_key}"', SECRET_PASSPHRASE)
    hash_json = json.dumps(encrypted, separators=(",", ":"))
    hash_encoded = parse.quote(hash_json, safe="")
    return f"bid={book_id}&hash={hash_encoded}&security_ls_key={security_ls_key}"


def _extract_security_key(html):
    patterns = [
        r"LIVESTREET_SECURITY_KEY\s*=\s*'([^']+)'",
        r'LIVESTREET_SECURITY_KEY\s*=\s*"([^"]+)"',
    ]
    for pattern in patterns:
        match = re.search(pattern, html or "")
        if match:
            return match.group(1)
    raise RuntimeError("LIVESTREET_SECURITY_KEY not found")


def _session_with_security_key():
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    response = session.get(SITE_URL, headers=_headers(), timeout=12, verify=False)
    response.raise_for_status()

    return session, _extract_security_key(response.text)


def _duration_to_seconds(value):
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        return int(value)

    raw = str(value).strip()
    if not raw:
        return 0
    if raw.isdigit():
        return int(raw)
    if ":" in raw:
        nums = [int(part) for part in re.findall(r"\d+", raw)]
        if len(nums) >= 3:
            return nums[0] * 3600 + nums[1] * 60 + nums[2]
        if len(nums) == 2:
            return nums[0] * 60 + nums[1]
        if len(nums) == 1:
            return nums[0]
    nums = re.findall(r"\d+", raw)
    return int(nums[0]) if nums else 0


def _chapter_durations_from_items(items):
    times = [
        _duration_to_seconds(item.get("time")) if isinstance(item, dict) else 0
        for item in items
    ]
    has_cumulative_times = len(times) > 1 and all(
        current >= previous for previous, current in zip(times, times[1:])
    )

    durations = []
    previous_end = 0
    for index, item in enumerate(items):
        explicit_duration = _duration_to_seconds(item.get("duration")) if isinstance(item, dict) else 0
        if explicit_duration:
            duration = explicit_duration
        elif has_cumulative_times:
            duration = max(0, times[index] - previous_end)
        else:
            duration = times[index]

        durations.append(duration)
        if has_cumulative_times:
            previous_end = times[index]

    return durations


def _id3v2_size(data):
    if len(data) < 10 or data[:3] != b"ID3":
        return 0
    size = (
        ((data[6] & 0x7F) << 21)
        | ((data[7] & 0x7F) << 14)
        | ((data[8] & 0x7F) << 7)
        | (data[9] & 0x7F)
    )
    footer_size = 10 if data[5] & 0x10 else 0
    return 10 + size + footer_size


def _mp3_frame_bitrate(header):
    if len(header) < 4:
        return 0
    b1, b2, b3, _b4 = header[:4]
    if b1 != 0xFF or (b2 & 0xE0) != 0xE0:
        return 0

    version_id = (b2 >> 3) & 0x03
    layer_id = (b2 >> 1) & 0x03
    bitrate_index = (b3 >> 4) & 0x0F
    if version_id == 1 or layer_id == 0 or bitrate_index in {0, 15}:
        return 0

    layer_name = {3: "I", 2: "II", 1: "III"}[layer_id]
    if version_id == 3:
        tables = {
            "I": [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
            "II": [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
            "III": [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
        }
    else:
        tables = {
            "I": [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
            "II": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
            "III": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
        }
    return tables[layer_name][bitrate_index] * 1000


def _mp3_duration_from_probe(data, total_bytes):
    total = int(total_bytes or 0)
    if total <= 0:
        return 0

    start = _id3v2_size(data)
    for offset in range(start, max(start, len(data) - 3)):
        bitrate = _mp3_frame_bitrate(data[offset:offset + 4])
        if bitrate:
            audio_bytes = max(0, total - offset)
            return int((audio_bytes * 8) / bitrate)
    return 0


def _response_total_bytes(response):
    content_range = response.headers.get("Content-Range", "")
    match = re.search(r"/(\d+)\s*$", content_range)
    if match:
        return int(match.group(1))
    content_length = response.headers.get("Content-Length", "")
    return int(content_length) if content_length.isdigit() else 0


def _probe_remote_mp3_duration(media_url, referer):
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "audio/mpeg,audio/*,*/*;q=0.8",
        "Range": "bytes=0-8191",
    }
    if referer:
        headers["Referer"] = referer

    response = requests.get(media_url, headers=headers, timeout=8, verify=False, stream=True)
    try:
        response.raise_for_status()
        total_bytes = _response_total_bytes(response)
        probe = response.raw.read(8192, decode_content=True)
        return _mp3_duration_from_probe(probe, total_bytes)
    finally:
        response.close()


def _probe_mp3_durations(media_urls, referer):
    durations = [0] * len(media_urls)
    if not media_urls:
        return durations

    with ThreadPoolExecutor(max_workers=min(8, len(media_urls))) as executor:
        futures = {
            executor.submit(_probe_remote_mp3_duration, media_url, referer): index
            for index, media_url in enumerate(media_urls)
            if media_url
        }
        for future in as_completed(futures):
            index = futures[future]
            try:
                durations[index] = future.result()
            except Exception:
                durations[index] = 0

    return durations


def _mp3_duration_probe_limit(track_count):
    count = int(track_count or 0)
    if count <= 0:
        return 0
    return min(MP3_DURATION_PROBE_LIMIT, count)


def _probe_mp3_durations_for_playlist(media_urls, referer):
    probe_limit = _mp3_duration_probe_limit(len(media_urls))
    if not probe_limit:
        return [0] * len(media_urls)

    probed = _probe_mp3_durations(media_urls[:probe_limit], referer)
    return probed + ([0] * max(0, len(media_urls) - len(probed)))


def _media_url_from_item(item):
    if not isinstance(item, dict):
        return ""
    return item.get("mp3") or item.get("url") or item.get("file") or ""


def _safe_media_proxy_url(media_url, referer):
    parsed = parse.urlparse(media_url or "")
    if parsed.scheme not in {"http", "https"}:
        return ""
    if not _is_allowed_media_host(parsed.netloc):
        return ""

    return (
        "/api/media?"
        f"source=akniga&url={parse.quote(media_url, safe='')}"
        f"&referer={parse.quote(referer or SITE_URL, safe='')}"
    )


def validate_media_url(url):
    """
    Используется /api/media. Разрешаем только реальные media URL Akniga/зеркал.
    """
    parsed = parse.urlparse(url or "")
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https media URLs are allowed")
    if not _is_allowed_media_host(parsed.netloc):
        raise ValueError("media URL host is outside Akniga allowlist")
    return parsed.geturl()


def get_akniga_tracks(bid, referer=None):
    """
    Возвращает главы Akniga с воспроизводимыми URL через локальный /api/media.

    Контракт для клиента:
    [
      {
        "title": "...",
        "urlAudio": "http://127.0.0.1:5177/api/media?...",
        "duration": 123,
        "rawSource": "akniga-mp3"
      }
    ]
    """
    book_id = str(bid).strip()
    if not re.fullmatch(r"\d{1,20}", book_id):
        raise ValueError("invalid Akniga bid")

    referer = referer or f"{SITE_URL}/"
    session, security_ls_key = _session_with_security_key()

    body = _make_security_params(book_id, security_ls_key)
    ajax_url = f"{SITE_URL}/ajax/bid/{book_id}"

    response = session.post(
        ajax_url,
        data=body.encode("utf-8"),
        headers={
            "User-Agent": USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Referer": referer,
            "Origin": SITE_URL,
        },
        timeout=15,
        verify=False,
    )
    response.raise_for_status()

    payload = response.json()

    if payload.get("bStateError"):
        raise RuntimeError(f"Akniga returned error: {payload}")

    raw_items = payload.get("aItems")
    if not raw_items:
        raise RuntimeError(f"Akniga response does not contain aItems: {payload}")

    items = json.loads(raw_items) if isinstance(raw_items, str) else raw_items
    if not isinstance(items, list):
        raise RuntimeError(f"Akniga aItems has unexpected format: {type(items).__name__}")

    fallback_durations = _chapter_durations_from_items(items)
    media_urls = [_media_url_from_item(item) for item in items]
    probed_durations = _probe_mp3_durations_for_playlist(media_urls, referer)
    tracks = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue

        media_url = _media_url_from_item(item)
        proxied_url = _safe_media_proxy_url(media_url, referer)
        if not proxied_url:
            continue

        tracks.append({
            "title": item.get("title") or item.get("titleonly") or f"Глава {index}",
            "urlAudio": proxied_url,
            "duration": (
                probed_durations[index - 1]
                if index - 1 < len(probed_durations) and probed_durations[index - 1]
                else fallback_durations[index - 1] if index - 1 < len(fallback_durations) else 0
            ),
            "albumName": item.get("cat") or item.get("albumName") or "",
            "rawSource": "akniga-ajax-bid",
        })

    if not tracks:
        raise RuntimeError("Akniga returned aItems, but no playable media URLs were found")

    return tracks


# Унифицированное имя для server.py: для не-Akniga источников он ищет get_tracks.
def get_tracks(bid, referer=None):
    return get_akniga_tracks(bid, referer=referer)
