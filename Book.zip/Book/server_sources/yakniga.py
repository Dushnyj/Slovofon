import gzip
import json
import re
from urllib import parse, request


GRAPHQL_URL = "https://yakniga.org/graphql"


SOURCE = {
    "name": "Yakniga",
    "host": "https://yakniga.org",
    "hosts": {"yakniga.org", "www.yakniga.org"},
    "search": "https://yakniga.org/search?q={q}&page={page}",
    "color": "#168f85",
    "parser": "Yakniga GraphQL API",
    "media_origin": "https://yakniga.org",
}


BOOK_QUERY = """
query YaknigaBook($aliasName: String!, $authorAliasName: String!) {
  book(aliasName: $aliasName, authorAliasName: $authorAliasName) {
    id
    title
    aliasName
    authorAlias
    authorName
    cover
    cover40
    cover110
    cover180
    downloadedCover
    duration
    rating
    price
    plus16
    plus18
    description
    remoteBio
    remoteId
    source
    litresId
    copyrightBlock
    seriesNum
    lastModifiedHeader
    readers { id name }
    authors { id name aliasName }
    series { id name aliasName }
    genres { collection { id name aliasName } }
    categories { collection { id name aliasName } }
    ebooks { collection { id } }
    chapters { collection { id name duration fileUrl pos } }
  }
}
"""


SEARCH_QUERY = """
query YaknigaSearch($term: String!) {
  search(autocomplete: true, term: $term) {
    __typename
    ... on Book {
      id
      title
      aliasName
      authorAlias
      authorName
      cover40
      cover180
      duration
      rating
      seriesNum
      copyrightBlock
      readers { id name }
      authors { id name aliasName }
      series { id name aliasName }
      genres { collection { id name aliasName } }
    }
  }
}
"""


SERIES_QUERY = """
query YaknigaSeries($aliasName: String, $id: ID) {
  series(aliasName: $aliasName, id: $id) {
    id
    name
    aliasName
    books {
      collection {
        id
        title
        aliasName
        authorAlias
        authorName
        cover40
        cover180
        duration
        rating
        seriesNum
        copyrightBlock
        readers { id name }
        authors { id name aliasName }
        series { id name aliasName }
        genres { collection { id name aliasName } }
      }
    }
  }
}
"""


def _headers(referer="https://yakniga.org/"):
    return {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/125.0 Safari/537.36"
        ),
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
        "Content-Type": "application/json",
        "Origin": "https://yakniga.org",
        "Referer": referer,
        "Connection": "close",
    }


def _decode_body(data, headers):
    if "gzip" in (headers.get("Content-Encoding") or "").lower():
        data = gzip.decompress(data)
    return data.decode("utf-8", errors="replace")


def graphql(query, variables=None, operation_name=None):
    body = json.dumps(
        {
            "query": query,
            "variables": variables or {},
            "operationName": operation_name,
        },
        ensure_ascii=False,
    ).encode("utf-8")
    req = request.Request(GRAPHQL_URL, data=body, headers=_headers(), method="POST")
    with request.urlopen(req, timeout=12) as response:
        payload = json.loads(_decode_body(response.read(2_500_000), response.headers))
    if payload.get("errors"):
        raise RuntimeError(payload["errors"][0].get("message") or "Yakniga GraphQL error")
    return payload.get("data") or {}


def _series_index(value):
    if value is None or value == "":
        return ""
    text = str(value).replace(",", ".")
    if re.fullmatch(r"\d+\.0+", text):
        return text.split(".", 1)[0]
    return text


def _book_url(book):
    author = book.get("authorAlias") or ""
    alias = book.get("aliasName") or ""
    if not author or not alias:
        return ""
    return f"https://yakniga.org/{parse.quote(author)}/{parse.quote(alias)}"


def _series_url(series):
    alias = (series or {}).get("aliasName") or ""
    return f"https://yakniga.org/series/{parse.quote(alias)}" if alias else ""


def _series_rows(series_payload):
    series = (series_payload or {}).get("series") or {}
    rows = []
    for book in (((series.get("books") or {}).get("collection")) or []):
        book = dict(book or {})
        if not book.get("series"):
            book["series"] = {"id": series.get("id"), "name": series.get("name"), "aliasName": series.get("aliasName")}
        rows.append({"index": _series_index(book.get("seriesNum")), "book": book})
    return rows


def _book_from_url(url):
    parsed = parse.urlparse(url)
    parts = [parse.unquote(part) for part in parsed.path.split("/") if part]
    if len(parts) >= 2:
        return parts[0], parts[1]
    raise ValueError("Yakniga book URL must look like /author/book")


def search_api(query, page="1"):
    clean_query = re.sub(r"\s+", " ", query or "").strip()
    if not clean_query:
        raise ValueError("query is empty")
    data = graphql(SEARCH_QUERY, {"term": clean_query}, "YaknigaSearch")
    items = [item for item in data.get("search") or [] if item.get("__typename") == "Book"]
    return {
        "ok": True,
        "status": 200,
        "url": f"https://yakniga.org/search?q={parse.quote(clean_query)}&page={parse.quote(str(page or 1))}",
        "mode": "api-first",
        "api": {
            "kind": "search",
            "items": items,
        },
    }


def series_api(alias_name=None, series_id=None):
    variables = {"aliasName": alias_name, "id": series_id}
    data = graphql(SERIES_QUERY, variables, "YaknigaSeries")
    series = data.get("series") or {}
    return {
        "ok": True,
        "status": 200,
        "url": _series_url(series) or f"https://yakniga.org/series/{parse.quote(alias_name or series_id or '')}",
        "mode": "api-first",
        "api": {
            "kind": "serie",
            "series": series,
            "items": _series_rows(data),
        },
    }


def book_api(url):
    parsed = parse.urlparse(url)
    parts = [parse.unquote(part) for part in parsed.path.split("/") if part]
    if parts[:1] == ["series"] and len(parts) >= 2:
        return series_api(alias_name=parts[1])

    author_alias, book_alias = _book_from_url(url)
    data = graphql(
        BOOK_QUERY,
        {"aliasName": book_alias, "authorAliasName": author_alias},
        "YaknigaBook",
    )
    book = data.get("book") or {}
    if not book:
        raise RuntimeError("Yakniga book was not found")

    serie_items = []
    series = book.get("series") or {}
    if series.get("aliasName") or series.get("id"):
        try:
            serie_items = series_api(alias_name=series.get("aliasName"), series_id=series.get("id"))["api"]["items"]
        except Exception:
            serie_items = []

    return {
        "ok": True,
        "status": 200,
        "url": _book_url(book) or url,
        "mode": "api-first",
        "api": {
            "kind": "book",
            "book": book,
            "serieItems": serie_items,
        },
    }


def _normalize_host(host):
    return (host or "").split(":", 1)[0].lower()


def validate_media_url(url):
    parsed = parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https media URLs are allowed")
    host = _normalize_host(parsed.netloc)
    if host not in {"yakniga.org", "www.yakniga.org"}:
        raise ValueError("media URL host is outside the Yakniga media allowlist")
    if not parsed.path.startswith("/yafile/"):
        raise ValueError("Yakniga media URL must be under /yafile/")
    if not re.search(r"\.(mp3|m4a|ogg|aac)(?:$|\?)", parsed.path, flags=re.I):
        raise ValueError("media URL is not an audio file")
    return parsed.geturl()
