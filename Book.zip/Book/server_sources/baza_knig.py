from urllib import parse
import re


SOURCE = {
    "name": "Baza Knig",
    "host": "https://baza-knig.top",
    "hosts": {"baza-knig.top", "www.baza-knig.top"},
    "search": "https://baza-knig.top/index.php?do=search&subaction=search&story={q}&page={page}",
    "color": "#a35d00",
    "parser": "strDecode",
    "media_origin": "https://baza-knig.top",
}


def _normalize_host(host):
    return (host or "").split(":", 1)[0].lower()


def validate_media_url(url):
    parsed = parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https media URLs are allowed")
    host = _normalize_host(parsed.netloc)
    if host != "abooka.casa" and not host.endswith(".abooka.casa"):
        raise ValueError("media URL host is outside the Baza media allowlist")
    if not re.search(r"\.(mp3|m4a|ogg|aac)(?:$|\?)", parsed.path, flags=re.I):
        raise ValueError("media URL is not an audio file")
    return parsed.geturl()
