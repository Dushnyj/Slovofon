"use strict";

(function registerYaknigaAdapter(register) {
  register("yakniga", ({
    $$,
    text,
    attr,
    absUrl,
    absHref,
    normalizeText,
    durationToSeconds
  }) => {
    function fieldText(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }

    function stripHtml(value) {
      const element = document.createElement("div");
      element.innerHTML = String(value || "");
      return fieldText(element.textContent || "");
    }

    function collectionNames(container) {
      const list = container?.collection || [];
      return (Array.isArray(list) ? list : []).map((item) => fieldText(item?.name)).filter(Boolean).join(", ");
    }

    function peopleNames(people) {
      return (Array.isArray(people) ? people : []).map((item) => fieldText(item?.name)).filter(Boolean).join(", ");
    }

    function peopleUrls(people, kind, source) {
      return (Array.isArray(people) ? people : [])
        .map((item) => {
          if (kind === "author" && item?.aliasName) return absUrl(`/${item.aliasName}`, source);
          if (kind === "reader" && item?.id) return absUrl(`/reader/${item.id}`, source);
          return "";
        })
        .filter(Boolean)
        .join(", ");
    }

    function cycleIndexValue(value) {
      const raw = fieldText(value).replace(",", ".");
      if (/^\d+\.0+$/.test(raw)) return raw.split(".", 1)[0];
      return raw.match(/\d+(?:\.\d+)*/)?.[0] || "";
    }

    function apiBookUrl(book, source) {
      if (!book?.authorAlias || !book?.aliasName) return "";
      return absUrl(`/${book.authorAlias}/${book.aliasName}`, source);
    }

    function apiSeriesUrl(series, source) {
      return series?.aliasName ? absUrl(`/series/${series.aliasName}`, source) : "";
    }

    function apiCover(book, source) {
      return absUrl(book?.cover180 || book?.cover110 || book?.cover40 || book?.cover || "", source);
    }

    function formatRatingScore(value) {
      const rounded = Math.round(Number(value || 0) * 10) / 10;
      return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    function apiRatingValue(book) {
      const rating = Number(book?.rating || 0);
      if (!Number.isFinite(rating) || rating <= 0) return "";
      return `${formatRatingScore(Math.max(0, Math.min(5, rating)))} из 5`;
    }

    function proxyMediaUrl(url, referer) {
      if (!/^https?:\/\/(?:www\.)?yakniga\.org\/yafile\//i.test(url || "")) return url;
      const proxyUrl = new URL("/api/media", window.location.href);
      proxyUrl.searchParams.set("source", "yakniga");
      proxyUrl.searchParams.set("url", url);
      proxyUrl.searchParams.set("referer", referer || "https://yakniga.org/");
      return proxyUrl.toString();
    }

    function apiBookToItem(book, source, options = {}) {
      const series = book?.series || null;
      const chapters = book?.chapters?.collection || [];
      const hasAudio = chapters.some((chapter) => chapter?.fileUrl);
      const copyrightBlock = Boolean(book?.copyrightBlock);
      const item = {
        source: source.id,
        sourceName: source.name,
        title: fieldText(book?.title),
        urlBook: apiBookUrl(book, source),
        coverUrl: apiCover(book, source),
        author: peopleNames(book?.authors) || fieldText(book?.authorName),
        authorUrl: peopleUrls(book?.authors, "author", source) || (book?.authorAlias ? absUrl(`/${book.authorAlias}`, source) : ""),
        reader: peopleNames(book?.readers),
        readerUrl: peopleUrls(book?.readers, "reader", source),
        genre: collectionNames(book?.genres),
        categories: collectionNames(book?.categories) || collectionNames(book?.genres),
        series: fieldText(series?.name),
        seriesUrl: apiSeriesUrl(series, source),
        seriesNumber: cycleIndexValue(options.seriesNumber || book?.seriesNum),
        durationText: book?.duration ? String(book.duration) : "",
        rating: apiRatingValue(book),
        schemaRating: apiRatingValue(book),
        schemaBestRating: apiRatingValue(book) ? "5" : "",
        descriptionShort: stripHtml(book?.description) || fieldText(book?.title),
        ageRestriction: book?.plus18 ? "18+" : (book?.plus16 ? "16+" : ""),
        bookId: book?.id || "",
        sourceUrlName: fieldText(book?.aliasName),
        updatedAt: fieldText(book?.lastModifiedHeader),
        accessRestricted: copyrightBlock,
        accessRestrictionText: copyrightBlock ? "Доступ ограничен по просьбе правообладателя" : "",
        siteAccess: copyrightBlock ? "restricted" : "full",
        siteAccessText: copyrightBlock ? "доступ ограничен" : "полная на странице источника",
        playbackAccess: hasAudio && !copyrightBlock ? "full" : (copyrightBlock ? "restricted" : ""),
        playbackAccessText: hasAudio && !copyrightBlock ? "полная через Yakniga mp3" : (copyrightBlock ? "доступ ограничен" : ""),
        isFragment: false,
        isAccessibleForFree: hasAudio && !copyrightBlock,
        accessText: hasAudio && !copyrightBlock ? "да" : ""
      };
      return item;
    }

    function apiCycleItemsFromRows(rows, source, urlBook) {
      return (Array.isArray(rows) ? rows : []).map((row, index) => {
        const book = row?.book || {};
        const item = apiBookToItem(book, source, { seriesNumber: row?.index || book?.seriesNum });
        return {
          index: cycleIndexValue(row?.index || book?.seriesNum) || String(index + 1),
          title: item.title,
          url: item.urlBook,
          coverUrl: item.coverUrl,
          author: item.author,
          authorUrl: item.authorUrl,
          reader: item.reader,
          readerUrl: item.readerUrl,
          durationText: item.durationText,
          current: sameBookPath(item.urlBook, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    function sameBookPath(left, right, source) {
      try {
        const leftUrl = new URL(left || "", source.host);
        const rightUrl = new URL(right || "", source.host);
        return leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
      } catch {
        return false;
      }
    }

    function apiTracksFromBook(book, source, urlBook) {
      const chapters = (Array.isArray(book?.chapters?.collection) ? book.chapters.collection : [])
        .slice()
        .sort((left, right) => Number(left?.pos || 0) - Number(right?.pos || 0));
      return chapters.map((chapter, index) => {
        const remoteUrl = chapter?.fileUrl ? absUrl(chapter.fileUrl, source) : "";
        return {
          title: fieldText(chapter?.name) || `Глава ${index + 1}`,
          urlAudio: proxyMediaUrl(remoteUrl, urlBook),
          remoteUrlAudio: remoteUrl,
          duration: durationToSeconds(chapter?.duration || 0),
          chapterId: chapter?.id || "",
          rawSource: "yakniga-api-mp3",
          source: "yakniga",
          urlBook
        };
      }).filter((track) => track.title && track.urlAudio);
    }

    return {
      source: {
        id: "yakniga",
        name: "Yakniga",
        host: "https://yakniga.org",
        color: "#168f85",
        parser: "Yakniga GraphQL API",
        searchUrl: "https://yakniga.org/search?q=<qery>&page=<page>",
        selectors: ["api.search", "api.book", "chapters.collection.fileUrl", ".book__title"]
      },
      playableTrackSources: ["yakniga-api-mp3"],
      parser: {
        apiList(payload, source) {
          const items = payload?.api?.kind === "search" ? payload.api.items : [];
          return (Array.isArray(items) ? items : []).map((book) => apiBookToItem(book, source));
        },
        list(document, source) {
          return $$(".books-card-component, .book-flat", document).map((item, index) => ({
            id: `${source.id}-${index}`,
            source: source.id,
            title: text(item, ".books-card-component__title, .book-flat__title-text, a"),
            urlBook: absHref(item, "a[href]", source),
            coverUrl: absUrl(attr(item, "img", "src"), source),
            author: text(item, ".books-card-component__author, .book__author"),
            reader: text(item, ".book__reader"),
            durationText: text(item, ".books-card-component__duration, .duration")
          }));
        },
        apiDetails(payload, source, urlBook) {
          const book = payload?.api?.kind === "book" ? payload.api.book : null;
          if (!book) return { urlBook };
          const serieRows = Array.isArray(payload?.api?.serieItems) ? payload.api.serieItems : [];
          const currentRow = serieRows.find((row) => String(row?.book?.id || "") === String(book.id || ""));
          const item = apiBookToItem(book, source, { seriesNumber: currentRow?.index || book.seriesNum });
          return {
            ...item,
            urlBook: payload.url || item.urlBook || urlBook,
            description: stripHtml(book.description),
            cycleItems: apiCycleItemsFromRows(serieRows, source, payload.url || item.urlBook || urlBook),
            playbackMode: "Yakniga GraphQL API",
            sourceName: source.name
          };
        },
        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            title: details.title || item.title,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            authorUrl: details.authorUrl || item.authorUrl,
            reader: details.reader || item.reader,
            readerUrl: details.readerUrl || item.readerUrl,
            durationText: details.durationText || item.durationText,
            genre: details.genre || item.genre,
            categories: details.categories || item.categories,
            series: details.series || item.series,
            seriesUrl: details.seriesUrl || item.seriesUrl,
            seriesNumber: details.seriesNumber || item.seriesNumber,
            cycleItems: details.cycleItems || item.cycleItems,
            descriptionShort: details.description || item.descriptionShort,
            rating: details.rating || item.rating,
            schemaRating: details.schemaRating || item.schemaRating,
            schemaBestRating: details.schemaBestRating || item.schemaBestRating,
            ageRestriction: details.ageRestriction || item.ageRestriction,
            bookId: details.bookId || item.bookId,
            updatedAt: details.updatedAt || item.updatedAt,
            accessRestricted: details.accessRestricted,
            accessRestrictionText: details.accessRestrictionText || item.accessRestrictionText,
            siteAccess: details.siteAccess || item.siteAccess,
            siteAccessText: details.siteAccessText || item.siteAccessText,
            playbackAccess: details.playbackAccess || item.playbackAccess,
            playbackAccessText: details.playbackAccessText || item.playbackAccessText,
            isAccessibleForFree: details.isAccessibleForFree,
            accessText: details.accessText || item.accessText
          };
        },
        details(document, source, urlBook) {
          const title = text(document, ".book__title, h1").replace(/^[^-]+-\s*/, "");
          return {
            source: source.id,
            sourceName: source.name,
            title,
            urlBook,
            coverUrl: absUrl(attr(document, ".book__image-img, .book__image img, meta[property='og:image']", "src") || attr(document, "meta[property='og:image']", "content"), source),
            author: text(document, ".book__author"),
            reader: text(document, ".book__reader"),
            genre: text(document, ".book__genre, .book__text-info"),
            description: text(document, ".book__description, .book__annotation")
          };
        },
        apiAudio(payload, { urlBook } = {}) {
          const book = payload?.api?.kind === "book" ? payload.api.book : null;
          return apiTracksFromBook(book, { id: "yakniga", host: "https://yakniga.org" }, urlBook);
        },
        apiCycleItems(payload, { source, urlBook } = {}) {
          if (payload?.api?.kind === "serie") return apiCycleItemsFromRows(payload.api.items, source, urlBook);
          if (payload?.api?.kind === "book") return apiCycleItemsFromRows(payload.api.serieItems, source, urlBook);
          return [];
        },
        audio() {
          return [];
        }
      },
      trackSourceLabel(track, fallback = "Yakniga") {
        if (track?.rawSource === "yakniga-api-mp3") return "Yakniga mp3";
        return fallback;
      }
    };
  });
}(window.registerAudioSourceAdapter));
