"use strict";

(function registerKnigobludAdapter(register) {
  register("knigoblud", ({
    $$,
    text,
    attr,
    absUrl,
    absHref,
    extractBalanced,
    parseJsonLike,
    resolvePlayerAudioUrl,
    durationToSeconds
  }) => {
    function fieldText(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }

    function backgroundUrl(value) {
      const match = String(value || "").match(/url\((['"]?)(.*?)\1\)/i);
      return match?.[2] || "";
    }

    function coverValue(root, source) {
      return absUrl(
        attr(root, ".bookListItemCoverImg.js-parallax, .bookListItemCoverImg", "data-img") ||
        attr(root, "#BookCoverImage, .BookCoverImage", "src") ||
        backgroundUrl(attr(root, ".bookListItemCoverImg.js-parallax, .bookListItemCoverImg", "style")) ||
        attr(root, "meta[property='og:image']", "content"),
        source
      );
    }

    function metaBlockByIcon(root, icon) {
      return $$(".bookListItemMetaBlock, .BookMetaBlockLine", root)
        .find((block) => fieldText(block.textContent).includes(icon)) || null;
    }

    function linksValue(root, selector) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        for (const link of links) {
          const name = fieldText(link.textContent);
          const key = name.toLowerCase();
          if (!key || seen.has(key)) continue;
          seen.add(key);
          entries.push(name);
        }
      }
      return entries.join(", ");
    }

    function linksHrefValue(root, selector, source) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        for (const link of links) {
          const url = absUrl(link.getAttribute("href"), source);
          if (!url || seen.has(url)) continue;
          seen.add(url);
          entries.push(url);
        }
      }
      return entries.join(", ");
    }

    function metaLinksByIcon(root, icon, source) {
      const block = metaBlockByIcon(root, icon);
      if (!block) return { text: "", url: "" };
      const entries = [];
      const urls = [];
      let active = false;
      for (const child of Array.from(block.childNodes)) {
        const value = fieldText(child.textContent || "");
        if (value.includes(icon)) {
          active = true;
          continue;
        }
        if (active && /📕|✍|🎙|📚|🕒/.test(value) && !value.includes(icon)) break;
        if (active && child.nodeType === Node.ELEMENT_NODE && child.matches?.("a[href]")) {
          const name = fieldText(child.textContent);
          if (name) entries.push(name);
          const url = absUrl(child.getAttribute("href"), source);
          if (url) urls.push(url);
        }
      }
      if (!entries.length) {
        const links = $$("a[href]", block);
        if (icon.includes("✍")) {
          entries.push(fieldText(links[0]?.textContent || ""));
          if (links[0]) urls.push(absUrl(links[0].getAttribute("href"), source));
        } else if (icon.includes("🎙")) {
          entries.push(fieldText(links[1]?.textContent || links[0]?.textContent || ""));
          if (links[1] || links[0]) urls.push(absUrl((links[1] || links[0]).getAttribute("href"), source));
        }
      }
      return {
        text: entries.filter(Boolean).join(", "),
        url: urls.filter(Boolean).join(", ")
      };
    }

    function sameBookPath(left, right, source) {
      try {
        const leftUrl = new URL(left || "", source.host);
        const rightUrl = new URL(right || "", source.host);
        return leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
      } catch {
        return false;
      }
    }

    function cycleIndexValue(value) {
      const raw = fieldText(value).replace(",", ".");
      return raw.match(/\d+(?:\.\d+)*/)?.[0] || "";
    }

    function seriesInfoValue(document) {
      const label = text(document, ".BookDescription.BookSeries .BookDescriptionLabel");
      const match = label.match(/Цикл\s+[«"](.+?)[»"]/i);
      return fieldText(match?.[1] || label.replace(/^📚\s*Цикл\s*/i, ""));
    }

    function seriesItemsValue(document, source, urlBook) {
      return $$(".BookDescription.BookSeries .BookDescriptionSeriesItem", document).map((item, index) => {
        const link = item.querySelector("a[href]");
        const url = link ? absUrl(link.getAttribute("href"), source) : "";
        const number = cycleIndexValue(text(item, ".BookDescriptionSeriesItemIndex")) || String(index + 1);
        return {
          index: number,
          title: fieldText(link?.textContent || text(item)).replace(/^\d+(?:[.,]\d+)?\.\s*/, ""),
          url,
          reader: fieldText((link?.textContent || "").match(/\(в исполнении\s+(.+?)\)/i)?.[1] || ""),
          current: sameBookPath(url, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    function isKnigobludAudioUrl(url) {
      return /^https?:\/\/(?:[^/]+\.)?audioknigi\.xyz\/.+\.(?:mp3|m4a|ogg|aac)(?:\?|$)/i.test(url || "");
    }

    function isLitresTrialUrl(url) {
      try {
        const parsed = new URL(url, window.location.href);
        if (!/(^|\.)litres\.ru$/i.test(parsed.hostname)) return false;
        return parsed.pathname === "/audiotrial/" || /^\/get_mp3_trial\/\d+\.mp3$/i.test(parsed.pathname);
      } catch {
        return false;
      }
    }

    function normalizeLitresTrialUrl(url) {
      try {
        const parsed = new URL(url, window.location.href);
        if (!/(^|\.)litres\.ru$/i.test(parsed.hostname) || parsed.pathname !== "/audiotrial/") return url;
        const art = parsed.searchParams.get("art");
        return /^\d+$/.test(art || "") ? `https://www.litres.ru/get_mp3_trial/${art}.mp3` : url;
      } catch {
        return url;
      }
    }

    function proxyMediaUrl(url, referer) {
      if (!isKnigobludAudioUrl(url) && !isLitresTrialUrl(url)) return url;
      const proxyUrl = new URL("/api/media", window.location.href);
      proxyUrl.searchParams.set("source", "knigoblud");
      proxyUrl.searchParams.set("url", url);
      proxyUrl.searchParams.set("referer", referer || "https://www.knigoblud.club/");
      return proxyUrl.toString();
    }

    function playerConfigFromText(value) {
      const script = String(value || "");
      const callIndex = script.indexOf("KB.playerInit");
      if (callIndex < 0) return {};
      const objectStart = script.indexOf("{", callIndex);
      const objectText = objectStart >= 0 ? extractBalanced(script, objectStart, "{", "}") : "";
      return parseJsonLike(objectText.replace(/\\\//g, "/")) || {};
    }

    function playerConfigValue(document) {
      const script = $$("script", document).map((el) => el.textContent || "").find((value) => value.includes("KB.playerInit"));
      return playerConfigFromText(script);
    }

    function playerTracksFromConfig(config, urlBook) {
      const playlist = Array.isArray(config.playlist) ? config.playlist : [];
      return playlist.map((item, index) => {
        const remoteUrl = resolvePlayerAudioUrl(item.src || item.file || item.url, "", urlBook);
        const audioUrl = normalizeLitresTrialUrl(remoteUrl);
        const directAudio = isKnigobludAudioUrl(audioUrl);
        const litresTrial = isLitresTrialUrl(audioUrl);
        return {
          title: fieldText(item.title) || `Глава ${index + 1}`,
          urlAudio: directAudio || litresTrial ? proxyMediaUrl(audioUrl, urlBook) : "",
          remoteUrlAudio: directAudio || litresTrial ? audioUrl : "",
          externalUrl: directAudio || litresTrial ? "" : remoteUrl,
          duration: durationToSeconds(item.duration || item.time || 0),
          chapterId: item.fileId || "",
          rawSource: directAudio ? "knigoblud-api-mp3" : litresTrial ? "knigoblud-litres-trial" : "knigoblud-external",
          source: "knigoblud",
          urlBook
        };
      }).filter((track) => track.title && (track.urlAudio || track.externalUrl));
    }

    function playerTracksValue(document, urlBook) {
      return playerTracksFromConfig(playerConfigValue(document), urlBook);
    }

    function playerTracksFromText(html, urlBook) {
      return playerTracksFromConfig(playerConfigFromText(html), urlBook);
    }

    function totalDurationText(tracks) {
      const total = tracks.reduce((sum, track) => sum + durationToSeconds(track.duration), 0);
      return total > 0 ? String(total) : "";
    }

    return {
      source: {
        id: "knigoblud",
        name: "Книгоблуд",
        host: "https://www.knigoblud.club",
        color: "#315f8f",
        parser: "KB.playerInit",
        searchUrl: "https://www.knigoblud.club/search?q=<qery>&page=<page>",
        selectors: ["#BL > .bookListItem", ".bookListItemCoverNameText", "#BookCoverImage, .BookCoverImage", "KB.playerInit"]
      },
      playableTrackSources: ["knigoblud-api-mp3", "knigoblud-litres-trial"],
      parser: {
        list(document, source) {
          return $$("#BL > .bookListItem, .BookList > .bookListItem", document)
            .filter((item) => item.classList.contains("bookListItem"))
            .map((item, index) => {
              const author = metaLinksByIcon(item, "✍", source);
              const reader = metaLinksByIcon(item, "🎙", source);
              const seriesBlock = metaBlockByIcon(item, "📚");
              const seriesLink = seriesBlock?.querySelector("a[href]");
              return {
                id: `${source.id}-${index}`,
                source: source.id,
                coverUrl: coverValue(item, source),
                urlBook: absHref(item, ".bookListItemCover", source),
                title: text(item, ".bookListItemCoverNameText"),
                descriptionShort: text(item, ".bookListItemDescription"),
                durationText: text(item, ".bookListItemNameDur"),
                genre: linksValue(metaBlockByIcon(item, "📕") || item, "a[href]"),
                author: author.text,
                authorUrl: author.url,
                reader: reader.text,
                readerUrl: reader.url,
                series: fieldText(seriesLink?.textContent || ""),
                seriesUrl: seriesLink ? absUrl(seriesLink.getAttribute("href"), source) : ""
              };
            });
        },
        details(document, source, urlBook) {
          const author = metaLinksByIcon(document, "✍", source);
          const reader = metaLinksByIcon(document, "🎙", source);
          const tracks = playerTracksValue(document, urlBook);
          const hasLitresTrial = tracks.some((track) => track.rawSource === "knigoblud-litres-trial");
          const cycleItems = seriesItemsValue(document, source, urlBook);
          const series = seriesInfoValue(document);
          const currentCycleItem = cycleItems.find((item) => item.current);
          const alternateReadings = cycleItems
            .filter((item) => !item.current && item.index && item.index === currentCycleItem?.index)
            .map((item) => ({ ...item, source: source.id }));
          return {
            source: source.id,
            sourceName: source.name,
            title: text(document, "h1[itemprop='name'], h1"),
            urlBook,
            coverUrl: coverValue(document, source),
            description: text($$(".BookDescription:not(.BookSeries) .BookDescriptionContent", document)[0] || document, ""),
            genre: linksValue(metaBlockByIcon(document, "📕") || document, "a[href]"),
            author: author.text,
            authorUrl: author.url,
            reader: reader.text,
            readerUrl: reader.url,
            series,
            seriesNumber: currentCycleItem?.index || "",
            cycleItems,
            alternateReadings,
            durationText: text(document, ".bookListItemNameDur") || totalDurationText(tracks),
            bookId: attr(document, "[data-book-id], [data-id]", "data-book-id") || attr(document, "[data-book-id], [data-id]", "data-id"),
            siteAccess: hasLitresTrial ? "fragment" : "full",
            siteAccessText: hasLitresTrial ? "фрагмент / LitRes" : "полная на странице источника",
            playbackAccess: tracks.length ? (hasLitresTrial ? "fragment" : "full") : "",
            playbackAccessText: tracks.length ? (hasLitresTrial ? "фрагмент LitRes" : "полная через Книгоблуд mp3") : "",
            isFragment: hasLitresTrial,
            isAccessibleForFree: Boolean(tracks.length),
            accessText: tracks.length ? "да" : "",
            playbackMode: hasLitresTrial ? "LitRes фрагмент" : "KB.playerInit"
          };
        },
        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            title: details.title || item.title,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            authorUrl: details.authorUrl || item.authorUrl,
            reader: details.reader || item.reader,
            readerUrl: details.readerUrl || item.readerUrl,
            durationText: details.durationText || item.durationText,
            genre: details.genre || item.genre,
            series: details.series || item.series,
            seriesUrl: item.seriesUrl || details.seriesUrl,
            seriesNumber: details.seriesNumber || item.seriesNumber,
            cycleItems: details.cycleItems || item.cycleItems,
            alternateReadings: details.alternateReadings || item.alternateReadings,
            siteAccess: details.siteAccess || item.siteAccess,
            siteAccessText: details.siteAccessText || item.siteAccessText,
            playbackAccess: details.playbackAccess || item.playbackAccess,
            playbackAccessText: details.playbackAccessText || item.playbackAccessText,
            isAccessibleForFree: details.isAccessibleForFree,
            accessText: details.accessText,
            descriptionShort: details.description || item.descriptionShort
          };
        },
        cycleItems(document, { source, urlBook } = {}) {
          return seriesItemsValue(document, source, urlBook);
        },
        audio(document, { urlBook } = {}) {
          return playerTracksValue(document, urlBook);
        },
        enhancedAudio(_document, { html, urlBook } = {}) {
          return playerTracksFromText(html, urlBook);
        }
      },
      trackSourceLabel(track, fallback = "KB.playerInit") {
        if (track?.rawSource === "knigoblud-api-mp3") return "Книгоблуд mp3";
        if (track?.rawSource === "knigoblud-litres-trial") return "LitRes фрагмент";
        return fallback;
      }
    };
  });
}(window.registerAudioSourceAdapter));
