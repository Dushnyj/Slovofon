"use strict";

(function initAudioSourceAdapterRegistry(root) {
  root.AudioSourceAdapters = root.AudioSourceAdapters || {};

  root.registerAudioSourceAdapter = function registerAudioSourceAdapter(id, factory) {
    if (!id || typeof factory !== "function") {
      throw new Error("Invalid audio source adapter registration");
    }
    root.AudioSourceAdapters[id] = factory;
  };
}(window));
