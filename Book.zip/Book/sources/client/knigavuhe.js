"use strict";

(function registerKnigavuheAdapter(register) {
  register("knigavuhe", ({
    $,
    $$,
    text,
    attr,
    absUrl,
    absHref,
    cleanedText,
    normalizeText,
    parseJsonLike,
    resolvePlayerAudioUrl,
    durationToSeconds
  }) => {
    const RESTRICTED_ACCESS_TEXT = "Доступ к аудиокниге ограничен по просьбе правообладателя.";

    function fieldText(value) {
      return normalizeText(String(value || ""));
    }

    function sameLabel(value, label) {
      return fieldText(value).replace(/[:：]+$/g, "").toLowerCase() === fieldText(label).toLowerCase();
    }

    function textAfterRemoving(root, removeSelector) {
      if (!root) return "";
      const clone = root.cloneNode(true);
      if (removeSelector) $$(removeSelector, clone).forEach((node) => node.remove());
      return fieldText(clone.textContent);
    }

    function bookInfoBlockValue(document, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const block of $$(".book_info_block_year, .book_info_block", document)) {
        const label = text(block, ".book_info_block_title");
        if (!expected.some((value) => sameLabel(label, value))) continue;
        const tags = $$(".book_info_block_tag", block).map((tag) => fieldText(tag.textContent)).filter(Boolean);
        return tags.length ? tags.join(" | ") : textAfterRemoving(block, ".book_info_block_title");
      }
      return "";
    }

    function bookInfoValue(document, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const label of $$(".book_info_label", document)) {
        const matched = expected.find((value) => sameLabel(label.textContent, value));
        if (!matched) continue;
        return textAfterRemoving(label.parentElement, ".book_info_label");
      }
      return bookInfoBlockValue(document, labels);
    }

    function titleBlockValue(document, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const block of $$(".book_title_elem", document)) {
        const label = $(".page_title_gray", block);
        if (!label || !expected.some((value) => sameLabel(label.textContent, value))) continue;
        const links = $$("a", block).map((link) => fieldText(link.textContent)).filter(Boolean);
        return links.length ? links.join(", ") : textAfterRemoving(block, ".page_title_gray");
      }
      return "";
    }

    function linksValue(root, selector) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        const targets = links.length ? links : [node];
        for (const target of targets) {
          const name = fieldText(target.textContent);
          const key = name.toLowerCase();
          if (!key || seen.has(key)) continue;
          seen.add(key);
          entries.push(name);
        }
      }
      return entries.join(", ");
    }

    function linksHrefValue(root, selector, source) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        for (const link of links) {
          const href = link.getAttribute("href");
          const url = href ? absUrl(href, source) : "";
          if (!url || seen.has(url)) continue;
          seen.add(url);
          entries.push(url);
        }
      }
      return entries.join(", ");
    }

    function titleBlockHref(document, labels, source) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const block of $$(".book_title_elem", document)) {
        const label = $(".page_title_gray", block);
        if (!label || !expected.some((value) => sameLabel(label.textContent, value))) continue;
        return linksHrefValue(block, "a", source);
      }
      return "";
    }

    function fictionClassifierValue(document, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const block of $$(".book_fiction_block_cat", document)) {
        const label = text(block, ".book_fiction_block_cat_name");
        if (!expected.some((value) => sameLabel(label, value))) continue;
        const values = $$(".book_fiction_block_tag", block).map((tag) => fieldText(tag.textContent)).filter(Boolean);
        return values.join(" | ");
      }
      for (const block of $$(".book_info_block_fiction", document)) {
        const label = text(block, ".book_info_block_title");
        if (!expected.some((value) => sameLabel(label, value))) continue;
        const values = $$(".book_info_block_tag", block).map((tag) => fieldText(tag.textContent)).filter(Boolean);
        return values.join(" | ");
      }
      return "";
    }

    function infoLineValue(document, selector) {
      const element = $(selector, document);
      if (!element) return "";
      const links = $$("a", element).map((link) => fieldText(link.textContent)).filter(Boolean);
      return links.length ? links.join(", ") : textAfterRemoving(element, ".book_info_line_label");
    }

    function infoLineHref(document, selector, source) {
      return linksHrefValue(document, `${selector} a`, source);
    }

    function seriesValue(document) {
      return text(document, ".book_info_line.icon_serie a") ||
        text(document, ".book_serie_block_title a, .book_serie_title a") ||
        fieldText(text(document, ".book_serie_block_title, .book_serie_title").replace(/^Цикл\s*[«"]?/i, "").replace(/[»"]$/g, ""));
    }

    function seriesUrlValue(document, source) {
      return absHref(document, ".book_info_line.icon_serie a, .book_serie_block_title a, .book_serie_title a", source);
    }

    function cycleIndexValue(value) {
      const raw = fieldText(value);
      return raw.match(/\d+(?:[.,]\d+)*/)?.[0]?.replace(",", ".") || "";
    }

    function seriesNumberValue(document) {
      const newDesignNumber = cycleIndexValue(text(document, ".book_info_line_serie_index"));
      if (newDesignNumber) return newDesignNumber;
      const current = $(".book_serie_block_item strong", document);
      const item = current?.closest(".book_serie_block_item");
      const oldDesignNumber = cycleIndexValue(text(item, ".book_serie_block_item_index"));
      if (oldDesignNumber) return oldDesignNumber;
      const mobileCurrent = $(".book_serie_item strong", document);
      const mobileItem = mobileCurrent?.closest(".book_serie_item");
      return cycleIndexValue(text(mobileItem, ".book_serie_item_index"));
    }

    function sameBookPath(left, right, source) {
      try {
        const leftUrl = new URL(left || "", source.host);
        const rightUrl = new URL(right || "", source.host);
        return leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
      } catch {
        return false;
      }
    }

    function seriesItemsValue(document, source, urlBook) {
      const items = [];
      const addItem = (root, indexSelector, titleSelector, urlSelector, fallbackIndex) => {
        const index = cycleIndexValue(text(root, indexSelector)) || fallbackIndex;
        const url = absHref(root, urlSelector, source);
        const rawTitle = text(root, titleSelector) || text(root);
        const title = fieldText(rawTitle.replace(text(root, indexSelector), ""));
        if (!title && !url) return;
        items.push({
          index,
          title,
          url,
          current: Boolean($("strong", root)) || sameBookPath(url, urlBook, source)
        });
      };

      $$(".book_serie_block_item", document).forEach((item, index) => {
        addItem(item, ".book_serie_block_item_index", "a, strong", "a", String(index + 1));
      });
      $$(".book_serie_item", document).forEach((item, index) => {
        addItem(item, ".book_serie_item_index", "a, strong", "a", String(index + 1));
      });
      $$("#books_list .bookitem", document).forEach((item, index) => {
        addItem(item, ".bookitem_serie_index", ".bookitem_name a", ".bookitem_name a, .bookitem_cover", String(index + 1));
      });

      const seen = new Set();
      return items.filter((item) => {
        const key = item.url || `${item.index}|${item.title}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    function alternateReadingsValue(document, source, urlBook) {
      const items = [];
      for (const heading of $$("h3", document)) {
        if (!/Другие озвучки/i.test(heading.textContent || "")) continue;
        let node = heading.nextElementSibling;
        while (node && node.tagName?.toLowerCase() !== "h3") {
          if (node.matches?.(".book_info_line.icon_reader")) {
            const href = attr(node, "a", "href");
            const url = href && /\/book\//i.test(href) ? absUrl(href, source) : "";
            const externalUrl = href && !url ? absUrl(href, source) : "";
            items.push({
              title: text(node, "a") || textAfterRemoving(node, ".book_info_line_label"),
              url,
              externalUrl,
              reader: text(node, "a"),
              current: sameBookPath(url, urlBook, source)
            });
          }
          node = node.nextElementSibling;
        }
      }
      $$(".book_other_versions a, .other-voices a", document).forEach((link) => {
        const url = absUrl(link.getAttribute("href"), source);
        items.push({
          title: text(link),
          url: /\/book\//i.test(url) ? url : "",
          externalUrl: /\/book\//i.test(url) ? "" : url,
          reader: text(link),
          current: sameBookPath(url, urlBook, source)
        });
      });
      return items.filter((item) => item.title || item.url || item.externalUrl);
    }

    function metaContent(document, selector) {
      return attr(document, selector, "content");
    }

    function accessRestrictionText(document) {
      const blockedText = text(document, ".book_blocked");
      if (/Доступ к аудиокниге ограничен/i.test(blockedText)) return blockedText;
      const scripts = $$("script", document).map((script) => script.textContent || "").join("\n");
      return /"blocked"\s*:\s*true/.test(scripts) ? RESTRICTED_ACCESS_TEXT : "";
    }

    function bookIdValue(document) {
      const scripts = $$("script", document).map((script) => script.textContent || "").join("\n");
      return scripts.match(/cur\.book\s*=\s*\{\s*"id"\s*:\s*(\d+)/)?.[1] ||
        scripts.match(/new\s+BookPlayer\s*\(\s*(\d+)/)?.[1] ||
        "";
    }

    function isKnigavuheAudioUrl(url) {
      try {
        const parsed = new URL(url);
        return /\.knigavuhe\.org$/i.test(parsed.hostname) &&
          /\.(mp3|m4a|ogg|aac)(?:$|[?#])/i.test(parsed.pathname + parsed.search);
      } catch {
        return false;
      }
    }

    function isLitresTrialUrl(url) {
      try {
        const parsed = new URL(url);
        return /(^|\.)litres\.ru$/i.test(parsed.hostname) &&
          (parsed.pathname === "/audiotrial/" || /^\/get_mp3_trial\/\d+\.mp3$/i.test(parsed.pathname));
      } catch {
        return false;
      }
    }

    function normalizeLitresTrialUrl(url) {
      try {
        const parsed = new URL(url, window.location.href);
        if (!/(^|\.)litres\.ru$/i.test(parsed.hostname)) return url;
        if (parsed.pathname !== "/audiotrial/") return url;
        const art = parsed.searchParams.get("art");
        if (!/^\d+$/.test(art || "")) return url;
        return `https://www.litres.ru/get_mp3_trial/${art}.mp3`;
      } catch {
        return url;
      }
    }

    function proxyMediaUrl(url, referer) {
      if (!isKnigavuheAudioUrl(url) && !isLitresTrialUrl(url)) return url;
      const proxyUrl = new URL("/api/media", window.location.href);
      proxyUrl.searchParams.set("source", "knigavuhe");
      proxyUrl.searchParams.set("url", url);
      proxyUrl.searchParams.set("referer", referer || "https://knigavuhe.org/");
      return proxyUrl.toString();
    }

    function extractBalanced(textValue, startIndex, openChar, closeChar) {
      const sourceText = String(textValue || "");
      let depth = 0;
      let inString = "";
      let escaped = false;
      for (let index = startIndex; index < sourceText.length; index += 1) {
        const char = sourceText[index];
        if (inString) {
          if (escaped) {
            escaped = false;
          } else if (char === "\\") {
            escaped = true;
          } else if (char === inString) {
            inString = "";
          }
          continue;
        }
        if (char === "\"" || char === "'") {
          inString = char;
          continue;
        }
        if (char === openChar) depth += 1;
        if (char === closeChar) {
          depth -= 1;
          if (depth === 0) return sourceText.slice(startIndex, index + 1);
        }
      }
      return "";
    }

    function pushPlaylistTrack(tracks, item, urlBook) {
      const remoteUrl = resolvePlayerAudioUrl(item.url || item.file || item.src, "", urlBook);
      const playbackUrl = normalizeLitresTrialUrl(remoteUrl);
      const directAudio = isKnigavuheAudioUrl(playbackUrl);
      const litresTrial = /litres\.ru\/(?:audiotrial|get_mp3_trial)/i.test(playbackUrl);
      const playableTrial = isLitresTrialUrl(playbackUrl);
      tracks.push({
        title: fieldText(item.title || item.name || item.player_data?.title) || `Глава ${tracks.length + 1}`,
        urlAudio: directAudio || playableTrial ? proxyMediaUrl(playbackUrl, urlBook) : "",
        remoteUrlAudio: directAudio || playableTrial ? playbackUrl : "",
        externalUrl: directAudio || playableTrial ? "" : remoteUrl,
        duration: durationToSeconds(item.duration_float || item.duration || item.time || 0),
        audioFormat: directAudio || playableTrial ? "mp3" : "",
        rawSource: directAudio ? "knigavuhe-bookplayer" : litresTrial ? "knigavuhe-litres-trial" : "knigavuhe-external"
      });
    }

    function bookPlayerTracks(html, urlBook) {
      const sourceHtml = String(html || "");
      const tracks = [];
      let searchFrom = 0;
      while (searchFrom < sourceHtml.length) {
        const markerIndex = sourceHtml.indexOf("new BookPlayer", searchFrom);
        if (markerIndex < 0) break;
        const argsStart = sourceHtml.indexOf("(", markerIndex);
        const arrayStart = sourceHtml.indexOf("[", argsStart);
        const arrayText = arrayStart >= 0 ? extractBalanced(sourceHtml, arrayStart, "[", "]") : "";
        const items = parseJsonLike(arrayText.replace(/\\\//g, "/"));
        if (Array.isArray(items)) {
          for (const item of items) pushPlaylistTrack(tracks, item, urlBook);
        }
        searchFrom = markerIndex + 14;
      }

      searchFrom = 0;
      while (searchFrom < sourceHtml.length) {
        const markerIndex = sourceHtml.indexOf("BookController.enter", searchFrom);
        if (markerIndex < 0) break;
        const objectStart = sourceHtml.indexOf("{", markerIndex);
        const objectText = objectStart >= 0 ? extractBalanced(sourceHtml, objectStart, "{", "}") : "";
        const playerConfig = parseJsonLike(objectText.replace(/\\\//g, "/"));
        const items = Array.isArray(playerConfig?.playlist) ? playerConfig.playlist : [];
        for (const item of items) pushPlaylistTrack(tracks, item, urlBook);
        searchFrom = markerIndex + 20;
      }

      return tracks.filter((track) => track.title && (track.urlAudio || track.externalUrl));
    }

    function hasPartnerLink(document) {
      return Boolean($("a[href*='go-partner'], a[href*='litres.ru']", document));
    }

    function accessText(value) {
      if (value === true) return "да";
      if (value === false) return "нет";
      return "";
    }

    function voteCount(value) {
      const raw = fieldText(value).replace(/\s+/g, "");
      const match = raw.match(/(\d+(?:[.,]\d+)?)([kкmм])?/i);
      if (!match) return 0;
      let count = Number(match[1].replace(",", "."));
      if (!Number.isFinite(count)) return 0;
      if (/^[kк]$/i.test(match[2] || "")) count *= 1000;
      if (/^[mм]$/i.test(match[2] || "")) count *= 1000000;
      return Math.round(count);
    }

    function voteRatingScoreText(value) {
      const rounded = Math.round(value * 10) / 10;
      return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    function voteRatingValue(likes, dislikes) {
      const likesCount = voteCount(likes);
      const total = likesCount + voteCount(dislikes);
      if (total <= 0) return "";
      return `${voteRatingScoreText(Math.max(0, Math.min(5, likesCount / total * 5)))} из 5`;
    }

    function voteRatingCount(likes, dislikes) {
      const total = voteCount(likes) + voteCount(dislikes);
      return total ? String(total) : "";
    }

    function detailSnapshot(document, urlBook) {
      const restriction = accessRestrictionText(document);
      const tracks = bookPlayerTracks(document.documentElement?.outerHTML || "", urlBook);
      const hasPlayableAudio = tracks.some((track) => track.rawSource === "knigavuhe-bookplayer");
      const hasPartnerAudio = tracks.some((track) => track.rawSource === "knigavuhe-litres-trial") || hasPartnerLink(document);
      const partnerOnly = !hasPlayableAudio && hasPartnerAudio;
      const accessible = restriction ? false : partnerOnly ? false : true;
      const schemaRating = metaContent(document, "[itemprop='ratingValue']");
      const schemaBestRating = metaContent(document, "[itemprop='bestRating']");
      const schemaRatingCount = metaContent(document, "[itemprop='ratingCount']");
      const siteAccess = restriction ? "restricted" : partnerOnly ? "fragment" : "full";
      const playbackAccess = restriction ? "restricted" : partnerOnly ? "fragment" : "full";

      return {
        restriction,
        partnerOnly,
        accessible,
        siteAccess,
        siteAccessText: restriction || (partnerOnly ? "фрагмент / LitRes" : "полная на странице источника"),
        playbackAccess,
        playbackAccessText: restriction ? "доступ ограничен" : partnerOnly ? "фрагмент LitRes" : "полная через Книга в ухе mp3",
        schemaRating,
        schemaBestRating,
        ratingCount: schemaRatingCount,
        rating: schemaRating ? `${schemaRating} из ${schemaBestRating || 5}` : ""
      };
    }

    return ({
      source: {
        id: "knigavuhe",
        name: "Книга в ухе",
        host: "https://knigavuhe.org",
        color: "#176b87",
        parser: "BookPlayer",
        searchUrl: "https://knigavuhe.org/search/?q=<qery>&page=<page>",
        selectors: [
          "#books_updates_list > div.bookkitem, #books_list > div.bookkitem, #books_list > div.bookitem",
          ".bookkitem_name > a, .bookitem_name > a",
          ".book_cover img[src], .bookitem_cover_img[src]",
          "new BookPlayer",
          ".book_blocked"
        ]
      },

      playableTrackSources: ["knigavuhe-bookplayer", "knigavuhe-litres-trial"],

      parser: {
        list(document, source) {
          return $$("#books_updates_list > div.bookkitem, #books_list > div.bookkitem, #books_list > div.bookitem", document).map((item, index) => ({
            id: `${source.id}-${index}`,
            source: source.id,
            sourceName: source.name,
            isFragment: Boolean($(".bookkitem_litres_icon, .bookitem_litres_icon, a[href*='litres'], a[href*='go-partner']", item)),
            title: text(item, ".bookkitem_name > a, .bookitem_name > a"),
            urlBook: absHref(item, ".bookkitem_name > a, .bookitem_name > a", source) || absHref(item, ".bookkitem_cover, .bookitem_cover", source),
            coverUrl: absUrl(attr(item, ".bookkitem_cover_img, .bookitem_cover_img, img", "src"), source),
            genre: text(item, ".bookkitem_genre > a, .bookitem_cover_genre"),
            genreUrl: absHref(item, ".bookkitem_genre > a", source),
            views: text(item, ".bookkitem_icon.-views + span, .bookitem_meta_block.icon_views .bookitem_meta_block_content"),
            comments: text(item, ".bookkitem_icon.-comments + span, .bookitem_meta_block.icon_comments .bookitem_meta_block_content"),
            author: linksValue(item, ".bookkitem_author > a, .bookitem_meta_block.icon_author .bookitem_meta_link"),
            authorUrl: linksHrefValue(item, ".bookkitem_author > a, .bookitem_meta_block.icon_author .bookitem_meta_link", source),
            reader: text(item, ".bookkitem_icon.-reader ~ span > a, .bookkitem_icon.-reader ~ a, .bookitem_meta_block.icon_reader .bookitem_meta_link"),
            readerUrl: absHref(item, ".bookitem_meta_block.icon_reader .bookitem_meta_link", source),
            durationText: text(item, ".bookkitem_meta_time, .bookitem_meta_block.icon_time .bookitem_meta_block_content"),
            series: text(item, ".bookkitem_icon.-serie ~ span > a, .bookitem_meta_block.icon_serie .bookitem_meta_link"),
            seriesUrl: absHref(item, ".bookkitem_icon.-serie ~ span > a, .bookitem_meta_block.icon_serie .bookitem_meta_link", source),
            descriptionShort: text(item, ".bookkitem_about, .bookitem_about")
          }));
        },

        details(document, source, urlBook) {
          const snapshot = detailSnapshot(document, urlBook);
          const durationText = bookInfoValue(document, "Время звучания") || text(document, ".book_small_player_time__duration");
          const addedAt = bookInfoValue(document, "Добавлена") || textAfterRemoving($(".book_info_line.icon_calendar", document), ".book_info_line_label");
          const ageRestriction = text(document, ".age_rating") || fictionClassifierValue(document, "Возраст читателя");
          const categories = fictionClassifierValue(document, "Поджанры");
          const cycleItems = seriesItemsValue(document, source, urlBook);
          const alternateReadings = alternateReadingsValue(document, source, urlBook);
          const likes = text(document, "#book_likes_count, [id$='_likes_count']");
          const dislikes = text(document, "#book_dislikes_count, [id$='_dislikes_count']");

          return {
            source: source.id,
            sourceName: source.name,
            title: text(document, ".book_title, .book_title_elem.book_title_name") || text(document, "[itemprop='name']"),
            urlBook,
            coverUrl: absUrl(attr(document, ".book_cover img", "src") || attr(document, "meta[property='og:image']", "content"), source),
            author: titleBlockValue(document, "автор") || infoLineValue(document, ".book_info_line.icon_author") || linksValue(document, "[itemprop='author'] a, [itemprop='author']"),
            authorUrl: titleBlockHref(document, "автор", source) || infoLineHref(document, ".book_info_line.icon_author", source) || linksHrefValue(document, "[itemprop='author'] a, [itemprop='author']", source),
            reader: titleBlockValue(document, ["читает", "читают"]) || infoLineValue(document, ".book_info_line.icon_reader"),
            readerUrl: titleBlockHref(document, ["читает", "читают"], source) || infoLineHref(document, ".book_info_line.icon_reader", source),
            genre: text(document, ".book_genre_pretitle a") || text(document, ".book_genre_pretitle") || text(document, ".book_info_summary a"),
            genreUrl: absHref(document, ".book_genre_pretitle a, .book_info_summary a", source),
            categories,
            series: seriesValue(document),
            seriesUrl: seriesUrlValue(document, source),
            seriesNumber: seriesNumberValue(document),
            cycleItems,
            alternateReadings,
            durationText,
            description: cleanedText(document, ".book_description"),
            characteristics: fictionClassifierValue(document, "Общие характеристики"),
            settingPlace: fictionClassifierValue(document, "Место действия"),
            settingTime: fictionClassifierValue(document, "Время действия"),
            plotType: fictionClassifierValue(document, ["Сюжетные ходы", "Сюжет"]),
            ageRestriction,
            addedAt,
            publishedYear: bookInfoBlockValue(document, "Год издания") || bookInfoValue(document, "Год издания"),
            rating: snapshot.rating || voteRatingValue(likes, dislikes),
            schemaRating: snapshot.schemaRating,
            schemaBestRating: snapshot.schemaBestRating,
            ratingCount: snapshot.ratingCount || voteRatingCount(likes, dislikes),
            likes,
            dislikes,
            favoriteCount: text(document, "#book_fave_count, [id$='_fave_btn_count']"),
            views: (text(document, ".book_actions_plays") || text(document, ".book_info_inline.icon_views span")).replace(/[^\d.kкmм]+/gi, ""),
            comments: text(document, "#comments_count, #comments_count_wrap, .book_info_inline.icon_comments a"),
            bookId: bookIdValue(document),
            accessRestricted: Boolean(snapshot.restriction),
            accessRestrictionText: snapshot.restriction,
            isFragment: snapshot.partnerOnly && !snapshot.restriction,
            siteAccess: snapshot.siteAccess,
            siteAccessText: snapshot.siteAccessText,
            playbackAccess: snapshot.playbackAccess,
            playbackAccessText: snapshot.playbackAccessText,
            isAccessibleForFree: snapshot.accessible,
            isPaid: snapshot.partnerOnly || Boolean(snapshot.restriction),
            accessText: accessText(snapshot.accessible),
            playbackMode: snapshot.restriction ? "доступ ограничен" : snapshot.partnerOnly ? "LitRes фрагмент" : "BookPlayer mp3"
          };
        },

        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            authorUrl: details.authorUrl || item.authorUrl,
            reader: details.reader || item.reader,
            readerUrl: details.readerUrl || item.readerUrl,
            genre: details.genre || item.genre,
            genreUrl: details.genreUrl || item.genreUrl,
            categories: details.categories || item.categories,
            series: details.series || item.series,
            seriesUrl: details.seriesUrl || item.seriesUrl,
            seriesNumber: details.seriesNumber || item.seriesNumber,
            cycleItems: details.cycleItems || item.cycleItems,
            alternateReadings: details.alternateReadings || item.alternateReadings,
            descriptionShort: details.description || item.descriptionShort,
            durationText: details.durationText || item.durationText,
            rating: details.rating || item.rating,
            schemaRating: details.schemaRating || item.schemaRating,
            schemaBestRating: details.schemaBestRating || item.schemaBestRating,
            ratingCount: details.ratingCount || item.ratingCount,
            publishedYear: details.publishedYear || item.publishedYear,
            audioYear: details.audioYear || item.audioYear,
            likes: details.likes || item.likes,
            dislikes: details.dislikes || item.dislikes,
            views: details.views || item.views,
            comments: details.comments || item.comments,
            favoriteCount: details.favoriteCount || item.favoriteCount,
            bookId: details.bookId || item.bookId,
            isFragment: details.isFragment,
            siteAccess: details.siteAccess,
            siteAccessText: details.siteAccessText,
            playbackAccess: details.playbackAccess,
            playbackAccessText: details.playbackAccessText,
            accessRestricted: details.accessRestricted,
            accessRestrictionText: details.accessRestrictionText,
            isAccessibleForFree: details.isAccessibleForFree,
            isPaid: details.isPaid,
            accessText: details.accessText
          };
        },

        cycleItems(document, { source, urlBook }) {
          return seriesItemsValue(document, source, urlBook);
        },

        async enhancedAudio(_document, { html, urlBook }) {
          return bookPlayerTracks(html, urlBook);
        },

        audio(document, { html = "", urlBook = "" } = {}) {
          return bookPlayerTracks(html || document.documentElement?.outerHTML || "", urlBook);
        }
      },

      trackSourceLabel(track, fallback = "BookPlayer") {
        if (track?.rawSource === "knigavuhe-bookplayer") return "Книга в ухе mp3";
        if (track?.rawSource === "knigavuhe-litres-trial") return "LitRes фрагмент";
        if (track?.rawSource === "knigavuhe-external") return "внешний плеер";
        return fallback;
      }
    });
  });
}(window.registerAudioSourceAdapter));
