"use strict";

(function registerBazaKnigAdapter(register) {
  register("baza_knig", ({
    $$,
    $,
    text,
    attr,
    absUrl,
    absHref,
    cleanedText,
    parseLabelValue,
    parseTracksFromScript,
    extractPlayerArray,
    extractBalanced,
    parseJsonLike,
    resolvePlayerAudioUrl,
    durationToSeconds
  }) => {
    const BAZA_DECODE_SCRIPT_URL = "https://baza-knig.top/player/decode.js?27";
    let decoderPromise = null;

    function cleanText(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }

    function labelItem(root, labels) {
      const expected = (Array.isArray(labels) ? labels : [labels]).map((label) => cleanText(label).toLowerCase());
      return $$(".full-items li, .short-items li", root).find((item) => {
        const label = cleanText(item.textContent).split(":")[0].toLowerCase();
        return expected.includes(label);
      }) || null;
    }

    function labelValue(root, labels) {
      const item = labelItem(root, labels);
      if (!item) return parseLabelValue(root, labels);
      const clone = item.cloneNode(true);
      return cleanText(clone.textContent).replace(/^[^:]+:\s*/i, "");
    }

    function labelLinksValue(root, labels) {
      const item = labelItem(root, labels);
      if (!item) return "";
      return $$("a[href]", item).map((link) => cleanText(link.textContent)).filter(Boolean).join(", ");
    }

    function labelLinksHrefValue(root, labels, source) {
      const item = labelItem(root, labels);
      if (!item) return "";
      return $$("a[href]", item).map((link) => absUrl(link.getAttribute("href"), source)).filter(Boolean).join(", ");
    }

    function fileStatsValue(root) {
      const item = $$(".full-items li, .short-items li", root).find((line) => /\b(kb\/s|кбит|Мб|Mb)\b/i.test(line.textContent || ""));
      const value = cleanText(item?.textContent || "");
      return {
        fileSize: value.match(/\[[^\]]+\]/)?.[0]?.replace(/^\[|\]$/g, "") || "",
        bitrate: value.match(/\d+\s*(?:kb\/s|кбит\/с|kbps)/i)?.[0] || ""
      };
    }

    function loadDecoder() {
      if (typeof window.strDecode === "function") return Promise.resolve(window.strDecode);
      if (decoderPromise) return decoderPromise;
      decoderPromise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = BAZA_DECODE_SCRIPT_URL;
        script.async = true;
        script.referrerPolicy = "no-referrer";
        script.onload = () => {
          if (typeof window.strDecode === "function") {
            resolve(window.strDecode);
          } else {
            reject(new Error("decode.js загружен, но strDecode не найден"));
          }
        };
        script.onerror = () => reject(new Error("не удалось загрузить Baza decode.js"));
        document.head.appendChild(script);
      });
      return decoderPromise;
    }

    function parseDecodedItems(decoded) {
      const value = String(decoded || "").replace(/\s+/g, " ").trim();
      if (!value) return [];
      try {
        const json = JSON.parse(value);
        return Array.isArray(json) ? json : [json];
      } catch {
        const parsed = parseJsonLike(value);
        if (Array.isArray(parsed)) return parsed;
        return parsed ? [parsed] : [];
      }
    }

    function firstSourceUrl(sources) {
      if (!Array.isArray(sources)) return "";
      const source = sources.find((item) => item?.file || item?.src || item?.url) || sources[0];
      return source?.file || source?.src || source?.url || "";
    }

    function proxyMediaUrl(url, referer) {
      if (!/^https?:\/\/(?:[^/]+\.)?abooka\.casa\//i.test(url || "")) return url;
      const proxyUrl = new URL("/api/media", window.location.href);
      proxyUrl.searchParams.set("source", "baza_knig");
      proxyUrl.searchParams.set("url", url);
      proxyUrl.searchParams.set("referer", referer || "https://baza-knig.top/");
      return proxyUrl.toString();
    }

    function rateActionCount(root, voteValue) {
      for (const link of $$(".short-rate a", root)) {
        const action = link.getAttribute("onclick") || "";
        const matchesVote = action.includes(`doRate('${voteValue}'`) || action.includes(`doRate("${voteValue}"`);
        if (!matchesVote) continue;
        return cleanText(link.textContent).match(/\d+(?:[.,]\d+)?\s*[kкmм]?/i)?.[0] || "";
      }
      return "";
    }

    function numericVoteValue(value) {
      const raw = cleanText(value).replace(/\s+/g, "");
      const match = raw.match(/(\d+(?:[.,]\d+)?)([kкmм])?/i);
      if (!match) return 0;
      let count = Number(match[1].replace(",", "."));
      if (!Number.isFinite(count)) return 0;
      if (/^[kк]$/i.test(match[2] || "")) count *= 1000;
      if (/^[mм]$/i.test(match[2] || "")) count *= 1000000;
      return Math.round(count);
    }

    function voteRatingScoreText(value) {
      const rounded = Math.round(value * 10) / 10;
      return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    function voteRatingValue(likes, dislikes) {
      const likesCount = numericVoteValue(likes);
      const total = likesCount + numericVoteValue(dislikes);
      if (total <= 0) return "";
      return `${voteRatingScoreText(Math.max(0, Math.min(5, likesCount / total * 5)))} из 5`;
    }

    function voteRatingCount(likes, dislikes) {
      const total = numericVoteValue(likes) + numericVoteValue(dislikes);
      return total ? String(total) : "";
    }

    function sectionReaderValue(section) {
      const readerLink = $$("a[href*='/xfsearch/ispolnitel/']", section)[0];
      if (readerLink) return cleanText(readerLink.textContent);
      const match = cleanText(section.textContent).match(/Озвучивает:\s*([^.[\n\r]+?)(?:\s{2,}|var|$)/i);
      return cleanText(match?.[1] || "");
    }

    function sectionReadersValue(root) {
      const readers = [];
      const seen = new Set();
      for (const section of $$("section[id^='content-tab'], .content-tab1, .content-tab2, .content-tab3", root)) {
        const reader = sectionReaderValue(section);
        const key = reader.toLowerCase();
        if (!key || seen.has(key)) continue;
        seen.add(key);
        readers.push(reader);
      }
      return readers.join(", ");
    }

    function addTrack(tracks, track) {
      if (!track.urlAudio || tracks.some((item) => item.remoteUrlAudio === track.remoteUrlAudio || item.urlAudio === track.urlAudio)) return;
      tracks.push(track);
    }

    function trackTitle(item, reader, fallback) {
      const title = cleanText(item?.title || item?.name || fallback);
      return reader ? `${title} • ${reader}` : title;
    }

    function parsePlayerjsFileValue(fileValue, baseUrl, reader, detailDuration, rawSource = "baza-playerjs") {
      const items = Array.isArray(fileValue) ? fileValue : (typeof fileValue === "string" ? [{ file: fileValue }] : []);
      return items.map((item, index) => {
        const audioUrl = resolvePlayerAudioUrl(
          item.file || item.src || item.url || item.value || firstSourceUrl(item.sources),
          "",
          baseUrl
        );
        return {
          title: trackTitle(item, reader, `Глава ${index + 1}`),
          urlAudio: proxyMediaUrl(audioUrl, baseUrl),
          remoteUrlAudio: audioUrl,
          duration: durationToSeconds(item.duration || item.time || (items.length === 1 ? detailDuration : 0)),
          rawSource
        };
      }).filter((track) => track.title && track.urlAudio);
    }

    function sectionPlayerTracks(section, baseUrl, reader, detailDuration) {
      const tracks = [];
      const scripts = $$("script", section).map((el) => el.textContent || "");
      for (const script of scripts) {
        for (const match of script.matchAll(/new\s+Playerjs\s*\(/g)) {
          const objectStart = script.indexOf("{", match.index);
          const objectText = objectStart >= 0 ? extractBalanced(script, objectStart, "{", "}") : "";
          const config = parseJsonLike(objectText);
          if (!config || typeof config.file === "string" && config.file === "file") continue;
          for (const track of parsePlayerjsFileValue(config.file || config.sources, baseUrl, reader, detailDuration, "baza-playerjs")) {
            addTrack(tracks, track);
          }
        }
      }
      return tracks;
    }

    async function parseDecodedTracks(html, baseUrl = "", details = {}, reader = "") {
      const matches = Array.from(String(html || "").matchAll(/strDecode\s*\(\s*["']([\s\S]*?)["']\s*\)/gi));
      if (!matches.length) return [];
      let decoder;
      try {
        decoder = await loadDecoder();
      } catch {
        return [];
      }
      const tracks = [];
      for (const match of matches) {
        let decoded = "";
        try {
          decoded = decoder(match[1]);
        } catch {
          continue;
        }
        const items = parseDecodedItems(decoded);
        for (const track of parsePlayerjsFileValue(items, baseUrl, reader, details?.durationText, "baza-strDecode")) {
          addTrack(tracks, track);
        }
      }
      return tracks;
    }

    return {
      source: {
        id: "baza_knig",
        name: "База книг",
        host: "https://baza-knig.top",
        color: "#a35d00",
        parser: "strDecode",
        searchUrl: "https://baza-knig.top/index.php?do=search&subaction=search&story=<qery>&page=<page>",
        selectors: ["#dle-content .short", ".short-title a", ".full-items", "section[id^='content-tab']", "strDecode", "Playerjs"]
      },
      playableTrackSources: ["strDecode", "js-play8-playlist", "baza-strDecode", "baza-playerjs"],
      parser: {
        list(document, source) {
          if (document.body.textContent.includes("Just a moment")) return [];
          return $$("#dle-content .short", document).map((item, index) => ({
            id: `${source.id}-${index}`,
            source: source.id,
            urlBook: absHref(item, ".short-img a", source),
            coverUrl: absUrl(attr(item, ".short-img img", "src"), source),
            title: text(item, ".short-title a"),
            descriptionShort: text(item, ".short-text"),
            author: parseLabelValue(item, ["Автор"]),
            reader: parseLabelValue(item, ["Читает"]),
            durationText: parseLabelValue(item, ["Длительность"]),
            series: parseLabelValue(item, ["Цикл"]),
            genre: parseLabelValue(item, ["Жанр"]),
            rating: voteRatingValue(rateActionCount(item, "1"), rateActionCount(item, "-1")),
            ratingCount: voteRatingCount(rateActionCount(item, "1"), rateActionCount(item, "-1")),
            likes: rateActionCount(item, "1"),
            dislikes: rateActionCount(item, "-1"),
            comments: text(item, ".short-bottom .comments")
          }));
        },
        details(document, source, urlBook) {
          const description = cleanedText(document, ".short-text", ["script", "style", ".no-pwa-only", "center", "details", "section"])
            .split("Озвучка")[0]
            .replace(/^Прежде чем скачать[^:]+:\s*/i, "")
            .trim();
          const likes = rateActionCount(document, "1");
          const dislikes = rateActionCount(document, "-1");
          const stats = fileStatsValue(document);
          const readers = sectionReadersValue(document) || labelLinksValue(document, ["Читает", "Озвучивает"]) || labelValue(document, ["Читает", "Озвучивает"]);
          return {
            source: source.id,
            title: text(document, "h1").replace(/^Скачать аудиокнигу\s+/i, "").split(" - ")[0],
            urlBook,
            coverUrl: absUrl(attr(document, ".full-img img", "src"), source),
            author: labelLinksValue(document, ["Автор", "Авторы"]) || labelValue(document, ["Автор", "Авторы"]),
            authorUrl: labelLinksHrefValue(document, ["Автор", "Авторы"], source),
            reader: readers,
            readerUrl: labelLinksHrefValue(document, ["Читает", "Озвучивает"], source),
            durationText: labelValue(document, ["Длительность"]),
            publishedYear: labelValue(document, ["Год"]),
            series: labelValue(document, ["Цикл", "Серия"]),
            genre: labelLinksValue(document, ["Жанр"]) || labelValue(document, ["Жанр"]),
            categories: labelLinksValue(document, ["Жанр"]) || labelValue(document, ["Жанр"]),
            addedAt: labelValue(document, ["Добавлена"]),
            fileSize: stats.fileSize,
            bitrate: stats.bitrate,
            description,
            rating: voteRatingValue(likes, dislikes),
            ratingCount: voteRatingCount(likes, dislikes),
            likes,
            dislikes,
            comments: text(document, ".short-bottom .comments"),
            sourceVariant: new URL(urlBook, source.host).searchParams.get("sorce") || "",
            hasContentTab2: Boolean($("#content-tab2, .content-tab2", document)),
            hasContentTab3: Boolean($("#content-tab3, .content-tab3", document)),
            siteAccess: "full",
            siteAccessText: "полная на странице источника",
            playbackAccess: "full",
            playbackAccessText: "полная через База книг mp3",
            isAccessibleForFree: true,
            accessText: "да",
            playbackMode: "strDecode / Playerjs"
          };
        },
        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            title: details.title || item.title,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            reader: details.reader || item.reader,
            durationText: details.durationText || item.durationText,
            series: details.series || item.series,
            genre: details.genre || item.genre,
            descriptionShort: details.description || item.descriptionShort,
            rating: details.rating || item.rating,
            ratingCount: details.ratingCount || item.ratingCount,
            likes: details.likes || item.likes,
            dislikes: details.dislikes || item.dislikes,
            comments: details.comments || item.comments,
            publishedYear: details.publishedYear || item.publishedYear,
            categories: details.categories || item.categories,
            fileSize: details.fileSize || item.fileSize,
            bitrate: details.bitrate || item.bitrate,
            siteAccess: details.siteAccess || item.siteAccess,
            siteAccessText: details.siteAccessText || item.siteAccessText,
            playbackAccess: details.playbackAccess || item.playbackAccess,
            playbackAccessText: details.playbackAccessText || item.playbackAccessText,
            isAccessibleForFree: details.isAccessibleForFree,
            accessText: details.accessText
          };
        },
        audio(document) {
          const playlist = $(".js-play8-playlist", document);
          if (playlist?.value) {
            try {
              return JSON.parse(playlist.value).map((item) => ({
                title: item.title,
                urlAudio: item.src || item.file,
                duration: durationToSeconds(item.duration),
                rawSource: "js-play8-playlist"
              }));
            } catch {
              return [];
            }
          }
          return parseTracksFromScript(document, "strDecode", (script) =>
            extractPlayerArray(script).map((item) => ({
              title: item.title,
              urlAudio: item.file || item.src,
              duration: durationToSeconds(item.duration),
              rawSource: "strDecode"
            }))
          );
        },
        async enhancedAudio(_document, { html, urlBook }) {
          const details = arguments[1]?.details || {};
          const tracks = [];
          for (const section of $$("section[id^='content-tab'], .content-tab1, .content-tab2, .content-tab3", _document)) {
            const reader = sectionReaderValue(section);
            for (const track of await parseDecodedTracks(section.innerHTML, urlBook, details, reader)) addTrack(tracks, track);
            for (const track of sectionPlayerTracks(section, urlBook, reader, details.durationText)) addTrack(tracks, track);
          }
          if (!tracks.length) {
            for (const track of await parseDecodedTracks(html, urlBook, details)) addTrack(tracks, track);
          }
          return tracks;
        }
      },
      trackSourceLabel(track, fallback = "strDecode") {
        if (track?.rawSource === "baza-strDecode") return "База книг mp3";
        if (track?.rawSource === "baza-playerjs") return "База книг mp3";
        return fallback;
      }
    };
  });
}(window.registerAudioSourceAdapter));
