"use strict";

(function registerIzibAdapter(register) {
  register("izib", ({
    $$,
    text,
    attr,
    absUrl,
    absHref,
    parseLabelValue,
    parseJsonLike,
    resolvePlayerAudioUrl,
    durationToSeconds
  }) => {
    function fieldText(value) {
      return String(value || "").replace(/\s+/g, " ").trim();
    }

    function linksValue(root, selector) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        const targets = links.length ? links : [node];
        for (const target of targets) {
          const name = fieldText(target.textContent);
          const key = name.toLowerCase();
          if (!key || seen.has(key)) continue;
          seen.add(key);
          entries.push(name);
        }
      }
      return entries.join(", ");
    }

    function linksHrefValue(root, selector, source) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        for (const link of links) {
          const href = link.getAttribute("href");
          const url = href ? absUrl(href, source) : "";
          if (!url || seen.has(url)) continue;
          seen.add(url);
          entries.push(url);
        }
      }
      return entries.join(", ");
    }

    function sameLabel(value, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      const clean = fieldText(value).replace(/[:：]+$/g, "").toLowerCase();
      return expected.some((label) => clean === fieldText(label).toLowerCase());
    }

    function infoBlockValue(document, labels) {
      for (const block of $$("._b264b2 ._d1c7c4", document)) {
        const label = fieldText(block.querySelector("b")?.textContent || "");
        if (!sameLabel(label, labels)) continue;
        const clone = block.cloneNode(true);
        clone.querySelector("b")?.remove();
        return fieldText(clone.textContent).replace(/^[:：]\s*/g, "");
      }
      return "";
    }

    function infoBlockLinksValue(document, labels, selector) {
      for (const block of $$("._b264b2 ._d1c7c4", document)) {
        const label = fieldText(block.querySelector("b")?.textContent || "");
        if (!sameLabel(label, labels)) continue;
        return linksValue(block, selector);
      }
      return "";
    }

    function infoBlockLinksHrefValue(document, labels, selector, source) {
      for (const block of $$("._b264b2 ._d1c7c4", document)) {
        const label = fieldText(block.querySelector("b")?.textContent || "");
        if (!sameLabel(label, labels)) continue;
        return linksHrefValue(block, selector, source);
      }
      return "";
    }

    function sameBookPath(left, right, source) {
      try {
        const leftUrl = new URL(left || "", source.host);
        const rightUrl = new URL(right || "", source.host);
        return leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
      } catch {
        return false;
      }
    }

    function seriesInfoValue(document, source) {
      const link = $$("._c337c7 a[href^='/serie']", document)[0];
      return {
        name: fieldText(link?.textContent || ""),
        url: link ? absUrl(link.getAttribute("href"), source) : "",
        number: ""
      };
    }

    function cycleIndexValue(value) {
      const raw = fieldText(value);
      return raw.match(/\d+(?:[.,]\d+)*/)?.[0]?.replace(",", ".") || "";
    }

    function seriesItemsValue(document, source, urlBook) {
      return $$("._b264b2._49d1b4 ._f61db9, ._b264b2._49d1b4 div._f61db9", document).map((item, index) => {
        const number = cycleIndexValue(item.querySelector("._bb8bca")?.textContent || "") || String(index + 1);
        const bookLink = item.querySelector("a[href^='/art']");
        const titleNode = bookLink || item.querySelector("strong");
        const url = bookLink ? absUrl(bookLink.getAttribute("href"), source) : "";
        const readerLink = item.querySelector("a[href^='/reader']");
        return {
          index: number,
          title: fieldText(titleNode?.textContent || ""),
          url,
          reader: fieldText(readerLink?.textContent || ""),
          readerUrl: readerLink ? absUrl(readerLink.getAttribute("href"), source) : "",
          current: Boolean(item.querySelector("strong")) || sameBookPath(url, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    function playerConfigValue(document) {
      const script = $$("script", document).map((el) => el.textContent || "").find((value) => value.includes("new XSPlayer"));
      const objectText = script?.match(/new\s+XSPlayer\s*\((\{[\s\S]*?\})\)\s*;/)?.[1] || "";
      return parseJsonLike(objectText) || {};
    }

    function normalizedPlayerTracks(playerConfig) {
      return (Array.isArray(playerConfig?.tracks) ? playerConfig.tracks : []).map((track, index) => {
        if (Array.isArray(track)) {
          return {
            id: track[0],
            title: fieldText(track[1]) || `Глава ${index + 1}`,
            duration: track[2],
            src: fieldText(track[4])
          };
        }
        return {
          id: track.id,
          title: fieldText(track.title) || `Глава ${index + 1}`,
          duration: track.duration || track.time,
          src: fieldText(track.src || track.file || track.url)
        };
      });
    }

    function playerTrackKind(track) {
      if (/litres\.ru|audiotrial/i.test(track.src)) return "litres";
      if (/\.(mp3|m4a|ogg|aac)(?:\?|$)/i.test(track.src)) return "mp3";
      return "";
    }

    function playerTracksValue(document, urlBook) {
      const playerConfig = playerConfigValue(document);
      return normalizedPlayerTracks(playerConfig).map((track) => {
        const trackKind = playerTrackKind(track);
        const urlAudio = resolvePlayerAudioUrl(track.src, playerConfig.mp3_url_prefix || "", urlBook);
        return {
          title: track.title,
          urlAudio,
          duration: durationToSeconds(track.duration),
          rawSource: trackKind === "litres" ? "izib-litres-trial" : "izib-mp3"
        };
      }).filter((track) => track.title && track.urlAudio);
    }

    function playerAccessValue(playerConfig) {
      const tracks = normalizedPlayerTracks(playerConfig);
      if (tracks.some((track) => playerTrackKind(track) === "mp3")) return "full";
      if (tracks.some((track) => playerTrackKind(track) === "litres")) return "fragment";
      if (playerConfig?.blocked) return "restricted";
      return "";
    }

    function siteAccessValue(document, playerConfig) {
      const access = playerAccessValue(playerConfig);
      const hasFragmentLabel = /фрагмент/i.test(text(document, "._42f3bf"));
      const hasLitres = /litres\.ru|audiotrial/i.test(document.documentElement?.outerHTML || "");
      if (hasLitres) return "fragment-litres";
      if (hasFragmentLabel || access === "fragment") return "fragment";
      if (access === "full") return "full";
      if (access === "restricted") return "restricted";
      return "";
    }

    function accessTextValue(value) {
      if (value === "full") return "да";
      if (value === "fragment" || value === "restricted") return "нет";
      return "";
    }

    function siteAccessText(value) {
      if (value === "fragment-litres") return "фрагмент / LitRes";
      if (value === "fragment") return "фрагмент на странице источника";
      if (value === "restricted") return "доступ ограничен";
      if (value === "full") return "полная на странице источника";
      return "";
    }

    function playbackAccessText(value) {
      if (value === "full") return "полная через Izib mp3";
      if (value === "fragment") return "фрагмент LitRes";
      if (value === "restricted") return "доступ ограничен";
      return "";
    }

    function mergePeopleValues(...values) {
      const entries = [];
      const seen = new Set();
      for (const value of values) {
        for (const name of fieldText(value).split(/\s*,\s*/).map(fieldText).filter(Boolean)) {
          const key = name.toLowerCase();
          if (seen.has(key)) continue;
          seen.add(key);
          entries.push(name);
        }
      }
      return entries.join(", ");
    }

    function apiEntityName(entity) {
      return fieldText([entity?.name, entity?.surname].filter(Boolean).join(" "));
    }

    function apiPeopleValue(people) {
      return (Array.isArray(people) ? people : []).map(apiEntityName).filter(Boolean).join(", ");
    }

    function apiPeopleUrl(people, kind, source) {
      return (Array.isArray(people) ? people : [])
        .map((person) => person?.id ? absUrl(`/${kind}/${person.id}`, source) : "")
        .filter(Boolean)
        .join(", ");
    }

    function apiBookUrl(book, source) {
      return book?.id ? absUrl(`/art${book.id}`, source) : "";
    }

    function apiSerieUrl(serie, source) {
      return serie?.id ? absUrl(`/serie/${serie.id}`, source) : "";
    }

    function pluralRu(number, one, few, many) {
      const n = Math.abs(Number(number) || 0);
      const mod10 = n % 10;
      const mod100 = n % 100;
      if (mod10 === 1 && mod100 !== 11) return one;
      if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
      return many;
    }

    function apiDurationText(seconds) {
      const total = Number(seconds);
      if (!Number.isFinite(total) || total <= 0) return "";
      const hours = Math.floor(total / 3600);
      const minutes = Math.floor((total % 3600) / 60);
      if (hours > 0) {
        return `${hours} ${pluralRu(hours, "час", "часа", "часов")}${minutes ? ` ${minutes} ${pluralRu(minutes, "минута", "минуты", "минут")}` : ""}`;
      }
      return `${minutes} ${pluralRu(minutes, "минута", "минуты", "минут")}`;
    }

    function apiTrackDuration(seconds) {
      const total = Number(seconds);
      return Number.isFinite(total) && total > 0 ? total : 0;
    }

    function apiDateText(timestamp) {
      const value = Number(timestamp);
      if (!Number.isFinite(value) || value <= 0) return "";
      return new Date(value * 1000).toLocaleDateString("ru-RU", {
        year: "numeric",
        month: "long",
        day: "numeric"
      });
    }

    function stripApiText(value) {
      return fieldText(String(value || "")
        .replace(/\[\/?[^\]]+\]/g, " ")
        .replace(/<[^>]+>/g, " "));
    }

    function apiFiles(book) {
      const mobile = Array.isArray(book?.files?.mobile) ? book.files.mobile : [];
      const full = Array.isArray(book?.files?.full) ? book.files.full : [];
      return (mobile.length >= full.length ? mobile : full)
        .filter((file) => file?.url)
        .slice()
        .sort((left, right) => Number(left.index || 0) - Number(right.index || 0));
    }

    function apiPlaybackAccess(book) {
      return apiFiles(book).length ? "full" : "restricted";
    }

    function apiPlaybackAccessText(value) {
      if (value === "full") return "полная через Izib API mp3";
      if (value === "restricted") return "доступ ограничен";
      return "";
    }

    function apiPoster(book, source) {
      const posters = Array.isArray(book?.posters) ? book.posters : [];
      return absUrl(book?.defaultPosterMain || book?.defaultPoster || posters.find(Boolean) || "", source);
    }

    function apiSeriesNumber(book, exactNumber = "") {
      return cycleIndexValue(exactNumber) || cycleIndexValue(book?.serieIndex);
    }

    function apiVoteTotal(book) {
      const likes = Number(book?.likes || 0);
      const dislikes = Number(book?.dislikes || 0);
      const total = likes + dislikes;
      return Number.isFinite(total) && total > 0 ? total : 0;
    }

    function apiRatingScoreText(value) {
      const rounded = Math.round(value * 10) / 10;
      return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    function apiRatingValue(book) {
      const likes = Number(book?.likes || 0);
      const total = apiVoteTotal(book);
      if (!Number.isFinite(likes) || total <= 0) return "";
      const score = Math.max(0, Math.min(5, likes / total * 5));
      return `${apiRatingScoreText(score)} из 5`;
    }

    function apiRatingCount(book) {
      const total = apiVoteTotal(book);
      return total ? String(total) : "";
    }

    function apiBookToItem(book, source, options = {}) {
      const serie = book?.serie || null;
      const playbackAccess = book?.files ? apiPlaybackAccess(book) : "";
      const files = apiFiles(book);
      const posters = Array.isArray(book?.posters) ? book.posters.filter(Boolean) : [];
      const item = {
        source: source.id,
        sourceName: source.name,
        title: fieldText(book?.name),
        urlBook: apiBookUrl(book, source),
        coverUrl: apiPoster(book, source),
        author: apiPeopleValue(book?.authors),
        authorUrl: apiPeopleUrl(book?.authors, "author", source),
        reader: apiPeopleValue(book?.readers),
        readerUrl: apiPeopleUrl(book?.readers, "reader", source),
        genre: fieldText(book?.genre?.name),
        categories: fieldText(book?.genre?.name),
        series: fieldText(serie?.name),
        seriesUrl: apiSerieUrl(serie, source),
        seriesNumber: apiSeriesNumber(book, options.seriesNumber),
        durationText: apiDurationText(book?.totalDuration),
        durationSeconds: book?.totalDuration || "",
        plays: book?.plays || "",
        views: book?.views || "",
        comments: book?.comments || "",
        likes: book?.likes || "",
        dislikes: book?.dislikes || "",
        rating: apiRatingValue(book),
        ratingCount: apiRatingCount(book),
        schemaBestRating: apiRatingValue(book) ? "5" : "",
        posterCount: posters.length ? String(posters.length) : "",
        posters: posters.join(", "),
        apiFileCount: files.length ? String(files.length) : "",
        sourceUrlName: fieldText(book?.urlName),
        addedAt: apiDateText(book?.publishTs),
        bookId: book?.id || "",
        descriptionShort: stripApiText(book?.aboutBb) || "Описание в API не найдено."
      };
      if (playbackAccess) {
        item.siteAccess = playbackAccess;
        item.siteAccessText = playbackAccess === "full" ? "доступно через Izib API" : "доступ ограничен";
        item.playbackAccess = playbackAccess;
        item.playbackAccessText = apiPlaybackAccessText(playbackAccess);
        item.isFragment = playbackAccess !== "full";
        item.isAccessibleForFree = playbackAccess === "full";
        item.isPaid = playbackAccess !== "full";
        item.accessText = playbackAccess === "full" ? "да" : "нет";
      }
      return item;
    }

    function apiTracksFromBook(book) {
      return apiFiles(book).map((file, index) => ({
        title: stripApiText(file.title) || fieldText(String(file.fileName || "").replace(/\.[a-z0-9]+$/i, "")) || `Глава ${index + 1}`,
        urlAudio: fieldText(file.url),
        duration: apiTrackDuration(file.duration),
        fileSize: file.size || "",
        fileName: file.fileName || "",
        audioFormat: fieldText(file.fileName).match(/\.([a-z0-9]+)$/i)?.[1]?.toLowerCase() || "mp3",
        chapterId: file.id || "",
        rawSource: "izib-api-mp3"
      })).filter((track) => track.title && track.urlAudio);
    }

    function apiCycleItemsFromRows(rows, source, urlBook) {
      return (Array.isArray(rows) ? rows : []).map((row, index) => {
        const book = row?.book || {};
        const item = apiBookToItem(book, source, { seriesNumber: row?.index });
        return {
          index: cycleIndexValue(row?.index) || item.seriesNumber || String(index + 1),
          title: item.title,
          url: item.urlBook,
          coverUrl: item.coverUrl,
          author: item.author,
          authorUrl: item.authorUrl,
          reader: item.reader,
          readerUrl: item.readerUrl,
          durationText: item.durationText,
          current: sameBookPath(item.urlBook, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    return ({
      source: {
        id: "izib",
        name: "Izib",
        host: "https://izib.uk",
        color: "#7d5a9d",
        parser: "XSPlayer",
        searchUrl: "https://izib.uk/search?q=<qery>&p=<page>",
        selectors: [
          "#books_list ._ccb9b7, #books_updates_list ._ccb9b7",
          "._3dc935 a[href^='/art']",
          "[itemprop=name]",
          "var player = new XSPlayer"
        ]
      },
      playableTrackSources: ["izib-api-mp3", "izib-mp3", "izib-litres-trial"],
      parser: {
        apiList(payload, source) {
          const items = payload?.api?.kind === "search" ? payload.api.items : [];
          return (Array.isArray(items) ? items : []).map((book) => apiBookToItem(book, source));
        },
        list(document, source) {
          return $$("#books_list ._ccb9b7, #books_updates_list ._ccb9b7", document).map((item, index) => {
            const titleSelector = "._3dc935 a[href^='/art'], a._3dc935[href^='/art'], ._680f12 a[href^='/art']";
            const fragment = /фрагмент/i.test(text(item, "._09ddb7"));
            return {
              id: `${source.id}-${index}`,
              source: source.id,
              title: text(item, titleSelector) || text(item, "._680f12 a") || text(item, "h1"),
              urlBook: absHref(item, titleSelector, source) || absHref(item, "a[href^='/art']", source),
              coverUrl: absUrl(attr(item, "._bce453 img, img._76d12c, img", "src"), source),
              author: linksValue(item, "a[href^='/author'], [itemprop=author] a"),
              authorUrl: linksHrefValue(item, "a[href^='/author'], [itemprop=author] a", source),
              reader: text(item, "a[href^='/reader']"),
              readerUrl: absHref(item, "a[href^='/reader']", source),
              genre: text(item, "._680f12 a, ._802db0 span"),
              series: text(item, "a[href^='/serie'], ._7e215f a"),
              seriesUrl: absHref(item, "a[href^='/serie'], ._7e215f a", source),
              durationText: text(item, "._802db0 div"),
              siteAccess: fragment ? "fragment" : "",
              siteAccessText: fragment ? "фрагмент на странице источника" : "",
              playbackAccess: fragment ? "fragment" : "",
              playbackAccessText: fragment ? "фрагмент LitRes" : "",
              isFragment: fragment,
              descriptionShort: text(item, "._b1f6b9") || "Описание в выдаче не найдено."
            };
          });
        },
        apiDetails(payload, source, urlBook) {
          const book = payload?.api?.kind === "book" ? payload.api.book : null;
          if (!book) return { urlBook };
          const serieRows = Array.isArray(payload?.api?.serieItems) ? payload.api.serieItems : [];
          const currentRow = serieRows.find((row) => String(row?.book?.id || "") === String(book.id || ""));
          const item = apiBookToItem(book, source, { seriesNumber: currentRow?.index });
          const cycleItems = apiCycleItemsFromRows(serieRows, source, payload.url || item.urlBook || urlBook);
          return {
            ...item,
            urlBook: payload.url || item.urlBook || urlBook,
            coverUrl: item.coverUrl,
            cycleItems,
            description: stripApiText(book.aboutBb),
            favoriteCount: typeof book.favored === "boolean" ? (book.favored ? "да" : "нет") : "",
            playbackMode: "Izib GraphQL API",
            sourceName: source.name
          };
        },
        details(document, source, urlBook) {
          const playerConfig = playerConfigValue(document);
          const playbackAccess = playerAccessValue(playerConfig);
          const siteAccess = siteAccessValue(document, playerConfig);
          const seriesInfo = seriesInfoValue(document, source);
          const cycleItems = seriesItemsValue(document, source, urlBook);
          return {
            source: source.id,
            sourceName: source.name,
            title: text(document, "[itemprop=name]") || attr(document, "meta[property='og:title']", "content"),
            urlBook,
            coverUrl: absUrl(attr(document, "._5e0b77 img, ._b264b2 img, meta[property='og:image'], img", "src") || attr(document, "meta[property='og:image']", "content"), source),
            author: mergePeopleValues(infoBlockLinksValue(document, ["Автор", "Авторы"], "a[href^='/author'], [itemprop=author] a"), linksValue(document, "[itemprop=author] a, [itemprop=author]"), parseLabelValue(document, ["Автор", "Авторы"])),
            authorUrl: infoBlockLinksHrefValue(document, ["Автор", "Авторы"], "a[href^='/author'], [itemprop=author] a", source) || linksHrefValue(document, "[itemprop=author] a, [itemprop=author]", source),
            reader: infoBlockLinksValue(document, ["Читает", "Чтец"], "a[href^='/reader']") || text(document, "._b264b2 ._d1c7c4 a[href^='/reader'], ._0c981a ._d1c7c4 a[href^='/reader']") || parseLabelValue(document, ["Читает"]),
            readerUrl: infoBlockLinksHrefValue(document, ["Читает", "Чтец"], "a[href^='/reader']", source),
            durationText: infoBlockValue(document, "Время") || parseLabelValue(document, ["Время"]),
            series: seriesInfo.name,
            seriesUrl: seriesInfo.url,
            seriesNumber: seriesInfo.number || cycleItems.find((item) => item.current)?.index || "",
            cycleItems,
            genre: text(document, "._7e215f a"),
            categories: text(document, "._7e215f"),
            bookId: playerConfig.id,
            siteAccess: siteAccess,
            siteAccessText: siteAccessText(siteAccess),
            playbackAccess,
            playbackAccessText: playbackAccessText(playbackAccess),
            isFragment: siteAccess !== "full",
            isAccessibleForFree: playbackAccess === "full",
            isPaid: playbackAccess === "fragment" || playbackAccess === "restricted",
            accessText: accessTextValue(playbackAccess),
            description: text(document, "[itemprop=description]") || attr(document, "meta[property='og:description']", "content")
          };
        },
        apiAudio(payload, { urlBook } = {}) {
          const book = payload?.api?.kind === "book" ? payload.api.book : null;
          return apiTracksFromBook(book).map((track) => ({ ...track, source: "izib", urlBook }));
        },
        apiCycleItems(payload, { source, urlBook } = {}) {
          return payload?.api?.kind === "serie" ? apiCycleItemsFromRows(payload.api.items, source, urlBook) : [];
        },
        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            authorUrl: details.authorUrl || item.authorUrl,
            reader: details.reader || item.reader,
            readerUrl: details.readerUrl || item.readerUrl,
            durationText: details.durationText || item.durationText,
            series: details.series || item.series,
            seriesUrl: details.seriesUrl || item.seriesUrl,
            seriesNumber: details.seriesNumber || item.seriesNumber,
            cycleItems: details.cycleItems || item.cycleItems,
            genre: details.genre || item.genre,
            categories: details.categories || item.categories,
            bookId: details.bookId || item.bookId,
            sourceUrlName: details.sourceUrlName || item.sourceUrlName,
            plays: details.plays || item.plays,
            rating: details.rating || item.rating,
            ratingCount: details.ratingCount || item.ratingCount,
            schemaBestRating: details.schemaBestRating || item.schemaBestRating,
            posterCount: details.posterCount || item.posterCount,
            posters: details.posters || item.posters,
            apiFileCount: details.apiFileCount || item.apiFileCount,
            siteAccess: details.siteAccess || item.siteAccess,
            siteAccessText: details.siteAccessText || item.siteAccessText,
            playbackAccess: details.playbackAccess || item.playbackAccess,
            playbackAccessText: details.playbackAccessText || item.playbackAccessText,
            isFragment: details.isFragment,
            isAccessibleForFree: details.isAccessibleForFree,
            isPaid: details.isPaid,
            accessText: details.accessText,
            descriptionShort: details.description || item.descriptionShort
          };
        },
        enhancedAudio(document, { urlBook }) {
          return playerTracksValue(document, urlBook);
        },
        audio(document, { urlBook } = {}) {
          return playerTracksValue(document, urlBook);
        }
      },

      trackSourceLabel(track, fallback = "XSPlayer") {
        if (track?.rawSource === "izib-api-mp3") return "Izib API mp3";
        if (track?.rawSource === "izib-mp3") return "Izib mp3";
        if (track?.rawSource === "izib-litres-trial") return "LitRes фрагмент";
        return fallback;
      }
    });
  });
}(window.registerAudioSourceAdapter));
