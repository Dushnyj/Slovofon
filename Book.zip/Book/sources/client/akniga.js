"use strict";

(function registerAknigaAdapter(register) {
  register("akniga", ({
    $,
    $$,
    text,
    attr,
    absUrl,
    absHref,
    normalizeText,
    durationToSeconds
  }) => {
    const fieldText = (value) => normalizeText(String(value || ""));

    function sameLabel(value, label) {
      return fieldText(value).replace(/[:：]+$/g, "").toLowerCase() === fieldText(label).toLowerCase();
    }

    function stripLeadingLabel(value, label) {
      return fieldText(value).replace(new RegExp(`^${label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*[:：]?\\s*`, "i"), "").trim();
    }

    function textWithoutCaptions(element) {
      if (!element) return "";
      const clone = element.cloneNode(true);
      $$(".content__main__book--item--caption", clone).forEach((caption) => caption.remove());
      return fieldText(clone.textContent);
    }

    function readableClassifierText(value) {
      return fieldText(value)
        .replace(/\s*\(\s*/g, " (")
        .replace(/\s*\)\s*/g, ")")
        .replace(/\)\s*(?=\S)/g, ") ")
        .replace(/\s*\|\s*/g, " | ")
        .replace(/\s{2,}/g, " ")
        .trim();
    }

    function labelValue(document, labels) {
      const expected = Array.isArray(labels) ? labels : [labels];
      for (const caption of $$(".content__main__book--item--caption", document)) {
        const captionText = fieldText(caption.textContent);
        const matchedLabel = expected.find((label) => sameLabel(captionText, label) || captionText.toLowerCase().startsWith(`${fieldText(label).toLowerCase()} `));
        if (!matchedLabel) continue;

        const valueInCaption = stripLeadingLabel(captionText, matchedLabel);
        if (valueInCaption) return valueInCaption;

        const block = caption.closest(".caption__article--about-block, .caption__article--about-item, .description__article-main");
        const content = $(".content__article--about-content", block || caption.parentElement);
        const value = fieldText(content?.textContent) || textWithoutCaptions(block || caption.parentElement);
        if (value) return stripLeadingLabel(value, matchedLabel);
      }
      return "";
    }

    function classifierValue(document, label) {
      for (const block of $$(".classifiers__article-main_block", document)) {
        const spans = Array.from(block.children).filter((child) => child.tagName?.toLowerCase() === "span");
        const labelNode = spans[0];
        const valueNode = spans[1];
        if (labelNode && valueNode && sameLabel(labelNode.textContent, label)) {
          return readableClassifierText(valueNode.textContent);
        }
      }
      return "";
    }

    function descriptionValue(document) {
      for (const block of $$(".description__article-main", document)) {
        const caption = $(".content__main__book--item--caption", block);
        if (caption && sameLabel(caption.textContent, "Описание")) {
          return textWithoutCaptions(block);
        }
      }
      return "";
    }

    function jsonLdAudiobook(document) {
      for (const script of $$("script[type='application/ld+json']", document)) {
        try {
          const payload = JSON.parse(script.textContent || "{}");
          const graph = Array.isArray(payload?.["@graph"]) ? payload["@graph"] : [payload];
          const audiobook = graph.find((item) => {
            const type = item?.["@type"];
            return type === "Audiobook" || (Array.isArray(type) && type.includes("Audiobook"));
          });
          if (audiobook) return audiobook;
        } catch {
          // Akniga has more than one JSON-LD block; ignore malformed blocks.
        }
      }
      return {};
    }

    function personName(value) {
      if (!value) return "";
      if (typeof value === "string") return fieldText(value);
      if (Array.isArray(value)) return value.map(personName).filter(Boolean).join(", ");
      return fieldText(value.name);
    }

    function normalizePersonName(value) {
      return fieldText(value)
        .replace(/ё/g, "е")
        .toLowerCase()
        .replace(/[^\wа-я]+/gi, " ")
        .replace(/\s+/g, " ")
        .trim();
    }

    function samePersonName(left, right) {
      const leftName = normalizePersonName(left);
      const rightName = normalizePersonName(right);
      return Boolean(leftName && rightName && leftName === rightName);
    }

    function splitPeople(value) {
      if (Array.isArray(value)) return value.map(fieldText).filter(Boolean);
      return fieldText(value).split(/\s*,\s*/).map(fieldText).filter(Boolean);
    }

    function peopleLinksValue(root, selector, source) {
      const entries = [];
      const seen = new Set();
      for (const node of $$(selector, root)) {
        const links = node.matches?.("a[href]") ? [node] : $$("a[href]", node);
        const targets = links.length ? links : [node];
        for (const target of targets) {
          const name = fieldText(target.textContent);
          const href = target.getAttribute?.("href") || "";
          const url = href ? absUrl(href, source) : "";
          const key = normalizePersonName(name) || url;
          if (!key || seen.has(key)) continue;
          seen.add(key);
          entries.push({ name, url });
        }
      }
      return {
        names: entries.map((entry) => entry.name).filter(Boolean).join(", "),
        urls: entries.map((entry) => entry.url).filter(Boolean).join(", ")
      };
    }

    function stripAuthorPrefixFromTitle(rawTitle, authors) {
      const title = fieldText(rawTitle);
      const authorList = splitPeople(authors);
      if (!title || !authorList.length) return title;
      const match = title.match(/^(.{2,180}?)\s*[–—-]\s*(.+)$/);
      if (!match) return title;
      const prefixPeople = splitPeople(match[1]);
      if (!prefixPeople.length) return title;
      const allPrefixPeopleAreAuthors = prefixPeople.every((prefixName) =>
        authorList.some((authorName) => samePersonName(prefixName, authorName))
      );
      return allPrefixPeopleAreAuthors ? fieldText(match[2]) : title;
    }

    function authorPrefixFromTitle(rawTitle) {
      const match = fieldText(rawTitle).match(/^(.{2,180}?)\s*[–—-]\s*(.+)$/);
      if (!match) return "";
      const prefix = fieldText(match[1]);
      if (!/[а-яё]/i.test(prefix)) return "";
      return prefix;
    }

    function authorNamesFromTitlePrefix(rawTitle, authors) {
      const prefix = authorPrefixFromTitle(rawTitle);
      const authorList = splitPeople(authors);
      if (!prefix) return fieldText(authors);
      if (!authorList.length) return prefix;

      const prefixPeople = splitPeople(prefix);
      const knownAuthorsAreInPrefix = authorList.every((authorName) =>
        prefixPeople.some((prefixName) => samePersonName(prefixName, authorName))
      );
      return knownAuthorsAreInPrefix ? prefix : fieldText(authors);
    }

    function titleValue(rawTitle, authors) {
      return stripAuthorPrefixFromTitle(rawTitle, authors);
    }

    function audioExtension(urlValue) {
      try {
        let mediaUrl = String(urlValue || "");
        const parsed = new URL(mediaUrl, window.location.origin);
        if (parsed.pathname === "/api/media") mediaUrl = parsed.searchParams.get("url") || mediaUrl;
        const mediaPath = new URL(mediaUrl, window.location.origin).pathname;
        return mediaPath.match(/\.([a-z0-9]{2,5})$/i)?.[1]?.toLowerCase() || "";
      } catch {
        return "";
      }
    }

    function siteAccessValue(document) {
      const chapterText = text(document, ".bookpage--chapters") || "";
      const pageText = text(document.body || document);
      const hasPartnerPrompt = /Слушать полностью|Купить аудиокнигу|ЛитРес/i.test(pageText);
      if (/фрагмент/i.test(chapterText)) return hasPartnerPrompt ? "fragment-litres" : "fragment";
      if (hasPartnerPrompt) return "fragment-litres";
      return "full";
    }

    function siteAccessText(value) {
      if (value === "fragment-litres") return "фрагмент / LitRes";
      if (value === "fragment") return "фрагмент на странице источника";
      if (value === "full") return "полная на странице источника";
      return "";
    }

    function playbackAccessValue(bookId, siteAccess) {
      if (bookId) return "full";
      if (siteAccess === "fragment" || siteAccess === "fragment-litres") return "fragment";
      return "";
    }

    function playbackAccessText(playbackAccess, siteAccess) {
      if (playbackAccess === "full") return "полная через Akniga mp3";
      if (playbackAccess === "fragment" && siteAccess === "fragment-litres") return "фрагмент / LitRes";
      if (playbackAccess === "fragment") return "фрагмент";
      return "";
    }

    function fragmentFlag(document) {
      return siteAccessValue(document) !== "full";
    }

    function accessText(value) {
      if (value === true) return "да";
      if (value === false) return "нет";
      return "";
    }

    function ratingCountFrom(value) {
      const number = Number(value);
      return Number.isFinite(number) && number > 0 ? String(number) : "";
    }

    function voteCount(document, voteValue) {
      return text(document, `.ls-vote-item[data-vote-value="${voteValue}"] .counter-number`);
    }

    function numericVoteValue(value) {
      const raw = fieldText(value).replace(/\s+/g, "");
      const match = raw.match(/(\d+(?:[.,]\d+)?)([kкmм])?/i);
      if (!match) return 0;
      let count = Number(match[1].replace(",", "."));
      if (!Number.isFinite(count)) return 0;
      if (/^[kк]$/i.test(match[2] || "")) count *= 1000;
      if (/^[mм]$/i.test(match[2] || "")) count *= 1000000;
      return Math.round(count);
    }

    function voteRatingScoreText(value) {
      const rounded = Math.round(value * 10) / 10;
      return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    }

    function voteRatingValue(likes, dislikes) {
      const likesCount = numericVoteValue(likes);
      const total = likesCount + numericVoteValue(dislikes);
      if (total <= 0) return "";
      return `${voteRatingScoreText(Math.max(0, Math.min(5, likesCount / total * 5)))} из 5`;
    }

    function voteRatingCount(likes, dislikes) {
      const total = numericVoteValue(likes) + numericVoteValue(dislikes);
      return total ? String(total) : "";
    }

    function actionLinkValue(root, iconClass, source) {
      for (const block of $$(".link__action", root)) {
        if (!$(`.${iconClass}`, block)) continue;
        return {
          name: text(block, "a"),
          url: absHref(block, "a", source)
        };
      }
      return { name: "", url: "" };
    }

    function actionLinksValue(root, iconClass, source) {
      const entries = [];
      const seen = new Set();
      for (const block of $$(".link__action", root)) {
        if (!$(`.${iconClass}`, block)) continue;
        for (const link of $$("a[href]", block)) {
          const name = fieldText(link.textContent);
          const url = absUrl(link.getAttribute("href"), source);
          const key = normalizePersonName(name) || url;
          if (!key || seen.has(key)) continue;
          seen.add(key);
          entries.push({ name, url });
        }
      }
      return {
        names: entries.map((entry) => entry.name).filter(Boolean).join(", "),
        urls: entries.map((entry) => entry.url).filter(Boolean).join(", ")
      };
    }

    function sameBookPath(left, right, source) {
      try {
        const leftUrl = new URL(left || "", source.host);
        const rightUrl = new URL(right || "", source.host);
        return leftUrl.pathname.replace(/\/+$/g, "") === rightUrl.pathname.replace(/\/+$/g, "");
      } catch {
        return false;
      }
    }

    function cycleIndexValue(value) {
      const raw = fieldText(value);
      return raw.match(/\d+(?:[.,]\d+)*/)?.[0]?.replace(",", ".") || "";
    }

    function seriesLinkValue(document, source) {
      const link = $(".link__series[href]", document);
      const rawValue = fieldText(text(link) || labelValue(document, "Серия"));
      const number = cycleIndexValue(rawValue.match(/\(([^)]+)\)\s*$/)?.[1] || "");
      return {
        name: fieldText(rawValue.replace(/\(\d+(?:[.,]\d+)*\)\s*$/g, "")),
        url: link ? absUrl(link.getAttribute("href"), source) : "",
        number
      };
    }

    function seriesItemsValue(document, source, urlBook) {
      return $$(".content__main__book--item--series-list a[href]", document).map((link, index) => {
        const number = cycleIndexValue(text(link, "b")) || String(index + 1);
        const title = text(link, ".caption") || fieldText(text(link).replace(text(link, "b"), ""));
        const url = absUrl(link.getAttribute("href"), source);
        return {
          index: number,
          title,
          url,
          current: link.classList.contains("current") || sameBookPath(url, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    function seriesPageItemsValue(document, source, urlBook) {
      return $$(".content__main__articles--series-item", document).map((item, index) => {
        const authorInfo = actionLinksValue(item, "icon--author", source);
        const reader = actionLinkValue(item, "icon--performer", source);
        const seriesText = text(item, ".book-series a");
        const number = cycleIndexValue(text(item, ".number")) ||
          cycleIndexValue(seriesText.match(/\(([^)]+)\)\s*$/)?.[1] || "") ||
          String(index + 1);
        const url = absHref(item, ".content__article-main-link, .article--cover a", source);
        const rawTitle = text(item, ".caption__article-main") || text(item, ".caption__article-preview");
        const authorNames = authorNamesFromTitlePrefix(rawTitle, authorInfo.names);
        return {
          index: number,
          title: titleValue(rawTitle, authorNames),
          url,
          coverUrl: absUrl(attr(item, ".container__remaining-width.article--cover.pull-left, img", "data-src") || attr(item, "img", "src"), source),
          author: authorNames,
          authorUrl: authorInfo.urls,
          reader: reader.name,
          readerUrl: reader.url,
          durationText: text(item, ".link__action--label--time"),
          current: sameBookPath(url, urlBook, source)
        };
      }).filter((item) => item.title || item.url);
    }

    function cleanCommentBookUrl(value, source) {
      try {
        const url = new URL(value || "", source.host);
        if (!/\/search\//i.test(url.pathname) && !/\/(profile|comments|tag|genre|performer|author)\//i.test(url.pathname)) {
          url.search = "";
          url.hash = "";
          return url.toString();
        }
      } catch {
        return "";
      }
      return "";
    }

    function meaningfulSearchTerms(query) {
      return fieldText(query)
        .toLowerCase()
        .split(/\s+/)
        .map((term) => term.replace(/[^\wа-яё-]+/gi, ""))
        .filter((term) => term.length > 2 && !/^(аудиокнига|аудиокнигу|слушать|онлайн|audio)$/i.test(term));
    }

    function commentSearchMatches(title, query) {
      const terms = meaningfulSearchTerms(query);
      if (!terms.length) return true;
      const haystack = fieldText(title).toLowerCase();
      return terms.every((term) => haystack.includes(term));
    }

    function commentSearchItems(document, source, query) {
      const seen = new Set();
      return $$(".ls-comment-path-target[href]", document).map((link, index) => {
        const urlBook = cleanCommentBookUrl(link.getAttribute("href"), source);
        const title = text(link);
        if (!urlBook || seen.has(urlBook)) return null;
        if (!commentSearchMatches(title, query)) return null;
        seen.add(urlBook);
        return {
          id: `${source.id}-comment-${index}`,
          source: source.id,
          sourceName: source.name,
          title,
          urlBook,
          searchUrl: document.location?.href || "",
          rawSource: "akniga-comment-search"
        };
      }).filter(Boolean);
    }

    function extraSearchQueries(query) {
      const clean = fieldText(query);
      if (!clean || clean.split(/\s+/).length < 2 || /аудиокнига|слушать|audio/i.test(clean)) return [];
      return [`${clean} аудиокнига`];
    }

    return ({
      source: {
        id: "akniga",
        name: "Akniga",
        host: "https://akniga.org",
        color: "#247a4d",
        parser: "ajax/bid contract",
        searchUrl: "https://akniga.org/search/books/page<page>/?q=<qery>",
        selectors: [
          ".content__main__articles--item",
          ".caption__article-main",
          "article[data-bid]",
          "LIVESTREET_SECURITY_KEY",
          "https://akniga.org/ajax/bid/"
        ]
      },

      playableTrackSources: ["akniga-ajax-bid"],

      parser: {
        extraSearchQueries,

        list(document, source, context = {}) {
          const bookItems = $$(".content__main__articles--item", document).map((item, index) => {
            const authorInfo = actionLinksValue(item, "icon--author", source);
            const rawTitle = text(item, ".caption__article-main") || text(item, ".caption__article-preview");
            const authorNames = authorNamesFromTitlePrefix(rawTitle, authorInfo.names);
            return {
              id: `${source.id}-${index}`,
              source: source.id,
              sourceName: source.name,
              isFragment: Boolean($("[href='https://akniga.org/paid/']", item)) || text(item, ".caption__article-preview").includes("Фрагмент"),
              title: titleValue(rawTitle, authorNames),
              urlBook: absHref(item, ".content__article-main-link", source) || absHref(item, "a", source),
              coverUrl: absUrl(attr(item, ".container__remaining-width.article--cover.pull-left, img", "data-src") || attr(item, "img", "src"), source),
              author: authorNames,
              authorUrl: authorInfo.urls,
              reader: text(item, "a[href*='/performer/']"),
              readerUrl: absHref(item, "a[href*='/performer/']", source),
              descriptionShort: text(item, ".description__article-main"),
              durationText: text(item, ".link__action.link__action--label.link__action--label--time"),
              comments: text(item, ".link__action.link__action--comment"),
              views: text(item, ".link__action--label--views"),
              genre: text(item, ".section__title")
            };
          }).filter((item) => !context.fallback || commentSearchMatches(item.title, context.query));
          return bookItems.concat(commentSearchItems(document, source, context.query));
        },

        details(document, source, urlBook) {
          const ld = jsonLdAudiobook(document);
          const isAccessibleForFree = typeof ld.isAccessibleForFree === "boolean" ? ld.isAccessibleForFree : undefined;
          const categories = classifierValue(document, "Жанры");
          const seriesInfo = seriesLinkValue(document, source);
          const cycleItems = seriesItemsValue(document, source, urlBook);
          const authorInfo = peopleLinksValue(document, ".about-author a", source);
          const rawTitle = text(document, ".caption__article-main") || fieldText(ld.name);
          const authorNames = authorNamesFromTitlePrefix(rawTitle, authorInfo.names || personName(ld.author));
          const bookId = attr(document, "article[data-bid]", "data-bid") || attr(document, ".bookpage--chapters[data-bid]", "data-bid");
          const siteAccess = siteAccessValue(document);
          const playbackAccess = playbackAccessValue(bookId, siteAccess);
          const likes = voteCount(document, "1");
          const dislikes = voteCount(document, "-1");

          return {
            source: source.id,
            sourceName: source.name,
            title: titleValue(rawTitle, authorNames),
            urlBook,
            author: authorNames,
            authorUrl: authorInfo.urls,
            coverUrl: absUrl(attr(document, ".cover__wrapper--image img", "src") || fieldText(ld.image), source),
            durationText: `${text(document, ".hours")} ${text(document, ".minutes")}`.trim(),
            durationIso: fieldText(ld.duration),
            reader: text(document, ".link__reader") || personName(ld.readBy),
            readerUrl: absHref(document, ".link__reader", source),
            series: seriesInfo.name,
            seriesUrl: seriesInfo.url,
            seriesNumber: seriesInfo.number || cycleItems.find((item) => item.current)?.index || "",
            cycleItems,
            description: descriptionValue(document) || fieldText(ld.description),
            genre: text(document, ".section__title") || categories || fieldText(ld.genre),
            categories,
            characteristics: classifierValue(document, "Характеристики"),
            settingPlace: classifierValue(document, "Место действия"),
            settingTime: classifierValue(document, "Время действия"),
            ageRestriction: classifierValue(document, "Возраст читателя") || text(document, ".age-limit, .content__main__book--item--age"),
            plotType: classifierValue(document, "Cюжет") || classifierValue(document, "Сюжет"),
            language: fieldText(ld.inLanguage),
            translator: labelValue(document, "Переводчик"),
            originalTitle: labelValue(document, "Другое название"),
            audioYear: labelValue(document, "Год озвучки"),
            publishedYear: labelValue(document, ["Год издания", "Год публикации"]),
            publisher: labelValue(document, "Издательство"),
            addedAt: labelValue(document, "Добавлено") || fieldText(ld.datePublished),
            updatedAt: labelValue(document, ["Обновлено", "Дата обновления"]),
            rating: voteRatingValue(likes, dislikes),
            schemaRating: "",
            schemaBestRating: "5",
            ratingCount: voteRatingCount(likes, dislikes),
            views: text(document, ".link__action--label.link__action--label--views.pull-right"),
            favoriteCount: text(document, ".ls-favourite-count"),
            likes,
            dislikes,
            comments: text(document, ".js-comments .comments-count, .comments-count") || "",
            isbn: labelValue(document, "ISBN"),
            copyrightHolder: labelValue(document, "Правообладатель"),
            recordingStudio: labelValue(document, ["Студия озвучки", "Студия"]),
            bookId,
            siteAccess: siteAccess,
            siteAccessText: siteAccessText(siteAccess),
            playbackAccess: playbackAccess,
            playbackAccessText: playbackAccessText(playbackAccess, siteAccess),
            isFragment: siteAccess !== "full",
            isAccessibleForFree,
            isPaid: isAccessibleForFree === false ? true : isAccessibleForFree === true ? false : undefined,
            accessText: accessText(isAccessibleForFree),
            playbackMode: "Akniga ajax/bid"
          };
        },

        enrichListItem(_document, { item, details }) {
          return {
            ...item,
            title: details.title || item.title,
            coverUrl: details.coverUrl || item.coverUrl,
            author: details.author || item.author,
            authorUrl: details.authorUrl || item.authorUrl,
            genre: details.genre || item.genre,
            categories: details.categories || item.categories,
            series: details.series || item.series,
            seriesUrl: details.seriesUrl || item.seriesUrl,
            seriesNumber: details.seriesNumber || item.seriesNumber,
            cycleItems: details.cycleItems || item.cycleItems,
            alternateReadings: details.alternateReadings || item.alternateReadings,
            descriptionShort: details.description || item.descriptionShort,
            durationText: details.durationText || item.durationText,
            reader: details.reader || item.reader,
            readerUrl: details.readerUrl || item.readerUrl,
            rating: details.rating || item.rating,
            schemaRating: details.schemaRating || item.schemaRating,
            schemaBestRating: details.schemaBestRating || item.schemaBestRating,
            ratingCount: details.ratingCount || item.ratingCount,
            publishedYear: details.publishedYear || item.publishedYear,
            audioYear: details.audioYear || item.audioYear,
            likes: details.likes || item.likes,
            dislikes: details.dislikes || item.dislikes,
            isFragment: details.isFragment,
            siteAccess: details.siteAccess,
            siteAccessText: details.siteAccessText,
            playbackAccess: details.playbackAccess,
            playbackAccessText: details.playbackAccessText,
            isAccessibleForFree: details.isAccessibleForFree,
            accessText: details.accessText,
            bookId: details.bookId || item.bookId
          };
        },

        cycleItems(document, { source, urlBook }) {
          const pageItems = seriesPageItemsValue(document, source, urlBook);
          return pageItems.length ? pageItems : seriesItemsValue(document, source, urlBook);
        },

        async enhancedAudio(document, { urlBook, details }) {
          const bid =
            details.bookId ||
            attr(document, "article[data-bid]", "data-bid") ||
            attr(document, ".bookpage--chapters[data-bid]", "data-bid");

          if (!bid) return [];

          const url = new URL("/api/source-tracks", window.location.origin);
          url.searchParams.set("source", "akniga");
          url.searchParams.set("bid", bid);
          url.searchParams.set("referer", urlBook || "");

          const response = await fetch(url.toString(), {
            headers: { Accept: "application/json" }
          });

          const payload = await response.json().catch(() => ({}));

          if (!response.ok || !payload.ok) {
            throw new Error(payload.error || `Akniga tracks HTTP ${response.status}`);
          }

          return (payload.tracks || []).map((track, index) => {
            const rawUrl = track.urlAudio || track.url || "";
            const format = track.audioFormat || audioExtension(rawUrl);

            return {
              title: track.title || `Глава ${index + 1}`,
              urlAudio: rawUrl ? new URL(rawUrl, window.location.origin).toString() : "",
              duration: durationToSeconds(track.duration || track.time || 0),
              audioFormat: format,
              rawSource: "akniga-ajax-bid"
            };
          }).filter((track) => track.title && track.urlAudio);
        },

        visibleChapters(bookDocument, { urlBook }) {
          const bid =
            attr(bookDocument, ".bookpage--chapters[data-bid]", "data-bid") ||
            attr(bookDocument, "article[data-bid]", "data-bid");

          const rows = $$(".bookpage--chapters.player--chapters[data-bid] .chapter__default[data-id]", bookDocument);

          return rows.map((element, index) => {
            const timeValue = text(element, ".chapter__default--time");
            const duration = durationToSeconds(timeValue);
            const position = Number(element.getAttribute("data-pos") || 0);
            const chapterId = element.getAttribute("data-id") || String(index);

            return {
              title: text(element, ".chapter__default--title") || `Глава ${index + 1}`,
              urlAudio: "",
              duration,
              timeStart: Number.isFinite(position) ? position : 0,
              timeEnd: Number.isFinite(position) ? position + duration : duration,
              externalUrl: urlBook,
              externalBid: bid,
              externalChapterId: chapterId,
              rawSource: "akniga-external-player"
            };
          }).filter((track) => track.title && track.title !== "--:--");
        }
      },

      trackSourceLabel(track, fallback = "видимые главы") {
        if (track?.rawSource === "akniga-ajax-bid") {
          return track.audioFormat ? `Akniga ${track.audioFormat}` : "Akniga ajax/bid";
        }

        if (track?.rawSource === "akniga-external-player") {
          return "плеер Akniga";
        }

        return fallback;
      }
    });
  });
}(window.registerAudioSourceAdapter));
