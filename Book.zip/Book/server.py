#!/usr/bin/env python3
import argparse
import gzip
import importlib
import json
import mimetypes
import os
import re
import subprocess
import socketserver
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib import parse, request, error

from server_sources import SOURCES


ROOT = Path(__file__).resolve().parent
MAX_HTML_BYTES = 2_500_000
FETCH_TIMEOUT_SECONDS = 8
ARCHIVE_CACHE_SECONDS = 5 * 60
ARCHIVE_CACHE = {}
MEDIA_TIMEOUT_SECONDS = 20
BAZA_ABOOKA_FALLBACK_HOSTS = ("1s.abooka.casa", "3s.abooka.casa", "2s.abooka.casa", "4s.abooka.casa", "5s.abooka.casa")

def json_response(handler, payload, status=HTTPStatus.OK):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


def normalize_host(host):
    if not host:
        return ""
    return host.split(":", 1)[0].lower()


def source_for_id(source_id):
    source = SOURCES.get(source_id)
    if source is None:
        raise ValueError(f"unknown source: {source_id}")
    return source


def validate_url_for_source(source_id, url):
    source = source_for_id(source_id)
    parsed = parse.urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https URLs are allowed")
    if normalize_host(parsed.netloc) not in source["hosts"]:
        raise ValueError("URL host is outside the selected source allowlist")
    return parsed.geturl()


def validate_media_url_for_source(source_id, url):
    source = source_for_id(source_id)
    validator = source.get("validate_media_url")
    if not callable(validator):
        raise ValueError(f"media proxy is not enabled for {source_id}")
    return validator(url)

def normalize_media_url_for_curl(url):
    """
    curl.exe плохо переваривает URL с пробелами и unicode-символами в path.
    Поэтому перед проксированием кодируем path/query безопасно.
    """
    parsed = parse.urlsplit(url)

    if parsed.scheme not in {"http", "https"}:
        return url

    safe_path = parse.quote(parse.unquote(parsed.path), safe="/:@")
    safe_query = parse.quote(parse.unquote(parsed.query), safe="=&?/:;+,%@")

    return parse.urlunsplit((
        parsed.scheme,
        parsed.netloc,
        safe_path,
        safe_query,
        parsed.fragment,
    ))


def resolve_baza_abooka_media_url(media_url, headers):
    parsed = parse.urlsplit(media_url)
    if normalize_host(parsed.netloc) != "abooka.casa":
        return media_url

    for host in BAZA_ABOOKA_FALLBACK_HOSTS:
        candidate = parse.urlunsplit((parsed.scheme, host, parsed.path, parsed.query, parsed.fragment))
        command = [
            "curl.exe",
            "--silent",
            "--show-error",
            "--ssl-no-revoke",
            "--http1.1",
            "--head",
            "--connect-timeout",
            "2",
            "--max-time",
            "4",
            "--output",
            os.devnull,
            "--write-out",
            "%{http_code}\n%{content_type}",
            "--user-agent",
            headers["User-Agent"],
            "--referer",
            headers["Referer"],
            "--header",
            f"Accept: {headers['Accept']}",
            "--header",
            f"Origin: {headers['Origin']}",
            candidate,
        ]
        try:
            completed = subprocess.run(command, capture_output=True, timeout=6, check=False)
        except Exception:
            continue
        status_text, _, content_type = completed.stdout.decode("utf-8", errors="replace").partition("\n")
        try:
            status = int(status_text.strip() or "0")
        except ValueError:
            status = 0
        if 200 <= status < 400 and "audio" in content_type.lower():
            return candidate

    return media_url

def build_search_url(source_id, query, page):
    source = source_for_id(source_id)
    clean_query = re.sub(r"\s+", " ", query or "").strip()
    if not clean_query:
        raise ValueError("query is empty")
    try:
        page_num = max(1, min(int(page or "1"), 10))
    except ValueError:
        page_num = 1
    return source["search"].format(q=parse.quote(clean_query), page=page_num)


def decode_body(data, content_type, content_encoding):
    encoding = (content_encoding or "").lower()
    if "gzip" in encoding:
        data = gzip.decompress(data)
    charset = "utf-8"
    match = re.search(r"charset=([\w.-]+)", content_type or "", flags=re.I)
    if match:
        charset = match.group(1)
    return data.decode(charset, errors="replace")


def fetch_html(source_id, url, referer=None):
    validate_url_for_source(source_id, url)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/125.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Encoding": "gzip",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    if source_id == "knigavuhe":
        headers.update({"Cookie": "new_design=1; settings=AAAAAAAAAAAAAAAA"})

    req = request.Request(url, headers=headers)
    try:
        with request.urlopen(req, timeout=FETCH_TIMEOUT_SECONDS) as response:
            final_url = response.geturl()
            validate_url_for_source(source_id, final_url)
            raw = response.read(MAX_HTML_BYTES + 1)
            truncated = len(raw) > MAX_HTML_BYTES
            raw = raw[:MAX_HTML_BYTES]
            html = decode_body(
                raw,
                response.headers.get("Content-Type", ""),
                response.headers.get("Content-Encoding", ""),
            )
            return {
                "ok": True,
                "status": response.status,
                "url": final_url,
                "html": html,
                "truncated": truncated,
            }
    except error.HTTPError as exc:
        body = exc.read(64_000)
        return {
            "ok": False,
            "status": exc.code,
            "url": url,
            "html": decode_body(
                body,
                exc.headers.get("Content-Type", ""),
                exc.headers.get("Content-Encoding", ""),
            ),
            "error": f"HTTP {exc.code}",
        }
    except Exception as exc:
        curl_result = fetch_html_with_curl(source_id, url, headers, str(exc))
        if curl_result is not None:
            return curl_result
        return {"ok": False, "status": 0, "url": url, "html": "", "error": str(exc)}


def fetch_html_with_curl(source_id, url, headers, original_error):
    marker = b"\n__AUDIOTESTER_STATUS__"
    command = [
        "curl.exe",
        "--silent",
        "--show-error",
        "--location",
        "--compressed",
        "--ssl-no-revoke",
        "--http1.1",
        "--max-time",
        str(FETCH_TIMEOUT_SECONDS),
        "--output",
        "-",
        "--write-out",
        "\n__AUDIOTESTER_STATUS__%{http_code}__URL__%{url_effective}",
        "--user-agent",
        headers["User-Agent"],
        "--header",
        f"Accept: {headers['Accept']}",
        "--header",
        f"Accept-Language: {headers['Accept-Language']}",
    ]
    if "Referer" in headers:
        command.extend(["--referer", headers["Referer"]])
    if "Cookie" in headers:
        command.extend(["--header", f"Cookie: {headers['Cookie']}"])
    command.append(url)

    try:
        completed = subprocess.run(command, capture_output=True, timeout=FETCH_TIMEOUT_SECONDS + 4, check=False)
    except Exception:
        return None

    stdout = completed.stdout
    marker_index = stdout.rfind(marker)
    if marker_index < 0:
        return {
            "ok": False,
            "status": 0,
            "url": url,
            "html": "",
            "error": original_error,
        }

    body = stdout[:marker_index]
    meta = stdout[marker_index + len(marker):].decode("utf-8", errors="replace")
    status_text, _, final_url = meta.partition("__URL__")
    try:
        status = int(status_text.strip())
    except ValueError:
        status = 0

    try:
        validate_url_for_source(source_id, final_url)
    except Exception as exc:
        return {"ok": False, "status": status, "url": final_url or url, "html": "", "error": str(exc)}

    html = body[:MAX_HTML_BYTES].decode("utf-8", errors="replace")
    return {
        "ok": 200 <= status < 400,
        "status": status,
        "url": final_url or url,
        "html": html,
        "truncated": len(body) > MAX_HTML_BYTES,
        "error": "" if 200 <= status < 400 else (completed.stderr.decode("utf-8", errors="replace") or f"HTTP {status}"),
    }


def search_payload(source_id, query, page):
    url = build_search_url(source_id, query, page)
    api_error = ""
    if source_id in {"izib", "yakniga"}:
        try:
            module = importlib.import_module(f"server_sources.{source_id}")
            result = module.search_api(query, page)
            result.update({"source": source_id})
            return result
        except Exception as api_exc:
            api_error = f"{type(api_exc).__name__}: {api_exc}"

    result = fetch_html(source_id, url)
    result.update({"source": source_id, "mode": "live-metadata"})
    if source_id in {"izib", "yakniga"} and api_error:
        result["apiError"] = api_error
    return result


def book_payload(source_id, url):
    checked_url = validate_url_for_source(source_id, url)
    api_error = ""
    if source_id in {"izib", "yakniga"}:
        try:
            module = importlib.import_module(f"server_sources.{source_id}")
            result = module.book_api(checked_url)
            result.update({"source": source_id})
            return result
        except Exception as api_exc:
            api_error = f"{type(api_exc).__name__}: {api_exc}"

    result = fetch_html(source_id, checked_url, referer=checked_url)
    result.update({"source": source_id, "mode": "live-metadata"})
    if source_id in {"izib", "yakniga"} and api_error:
        result["apiError"] = api_error
    return result


class Handler(BaseHTTPRequestHandler):
    server_version = "AudiobooksTester/1.0"

    def do_GET(self):
        parsed = parse.urlparse(self.path)
        if parsed.path == "/api/sources":
            self.handle_sources()
            return
        if parsed.path == "/api/search":
            self.handle_search(parsed)
            return
        if parsed.path == "/api/book":
            self.handle_book(parsed)
            return
        if parsed.path == "/api/source-tracks":
            params = parse.parse_qs(parsed.query)
            source_id = params.get("source", [""])[0]
            self.handle_source_tracks(source_id, parsed)
            return
        if parsed.path == "/api/archive":
            self.handle_archive(parsed)
            return
        if parsed.path == "/api/media":
            self.handle_media(parsed)
            return
        self.handle_static(parsed.path)

    def do_POST(self):
        parsed = parse.urlparse(self.path)
        if parsed.path == "/api/books":
            self.handle_books()
            return
        json_response(self, {"ok": False, "error": "unknown endpoint"}, HTTPStatus.NOT_FOUND)

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))

    def handle_sources(self):
        json_response(
            self,
            {
                "ok": True,
                "sources": [
                    {
                        "id": key,
                        "name": value["name"],
                        "host": value.get("host", ""),
                        "color": value.get("color", "#64748b"),
                        "parser": value.get("parser", "empty"),
                        "clientAdapter": value.get("client_adapter", key),
                        "searchUrl": value.get("search", "").replace("{q}", "<qery>").replace("{page}", "<page>"),
                        "hosts": sorted(value["hosts"]),
                    }
                    for key, value in SOURCES.items()
                ],
            },
        )

    def handle_search(self, parsed):
        params = parse.parse_qs(parsed.query)
        source_id = params.get("source", [""])[0]
        query = params.get("q", [""])[0]
        page = params.get("page", ["1"])[0]
        try:
            json_response(self, search_payload(source_id, query, page))
        except Exception as exc:
            json_response(self, {"ok": False, "status": 0, "html": "", "error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def handle_book(self, parsed):
        params = parse.parse_qs(parsed.query)
        source_id = params.get("source", [""])[0]
        url = params.get("url", [""])[0]
        try:
            json_response(self, book_payload(source_id, url))
        except Exception as exc:
            json_response(self, {"ok": False, "status": 0, "html": "", "error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def read_json_body(self, max_bytes=300_000):
        try:
            content_length = int(self.headers.get("Content-Length", "0") or "0")
        except ValueError:
            content_length = 0
        if content_length <= 0:
            return {}
        if content_length > max_bytes:
            raise ValueError("request body is too large")
        raw = self.rfile.read(content_length)
        return json.loads(raw.decode("utf-8"))

    def handle_books(self):
        try:
            payload = self.read_json_body()
            books = payload.get("books") or []
            if not isinstance(books, list):
                raise ValueError("books must be a list")
            if len(books) > 80:
                raise ValueError("too many book requests")

            def load_one(index, entry):
                source_id = str((entry or {}).get("source") or "").strip()
                url = str((entry or {}).get("url") or "").strip()
                try:
                    return {
                        "index": index,
                        "source": source_id,
                        "url": url,
                        "payload": book_payload(source_id, url),
                    }
                except Exception as exc:
                    return {
                        "index": index,
                        "source": source_id,
                        "url": url,
                        "payload": {
                            "ok": False,
                            "status": 0,
                            "html": "",
                            "error": str(exc),
                        },
                    }

            results = []
            max_workers = max(1, min(12, len(books)))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(load_one, index, entry) for index, entry in enumerate(books)]
                for future in as_completed(futures):
                    results.append(future.result())

            results.sort(key=lambda item: item["index"])
            json_response(self, {"ok": True, "items": results})
        except Exception as exc:
            json_response(self, {"ok": False, "error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def handle_source_tracks(self, source_id, parsed):
        params = parse.parse_qs(parsed.query)
        bid = params.get("bid", [""])[0].strip()
        referer = params.get("referer", [""])[0].strip()
        if not bid:
            json_response(self, {"ok": False, "error": "bid required"}, HTTPStatus.BAD_REQUEST)
            return
        if not re.fullmatch(r"[\w.-]{1,180}", bid):
            json_response(self, {"ok": False, "error": "invalid bid"}, HTTPStatus.BAD_REQUEST)
            return
        try:
            source_for_id(source_id)
            module = importlib.import_module(f"server_sources.{source_id}")
            get_tracks = getattr(module, "get_akniga_tracks" if source_id == "akniga" else "get_tracks", None)
            if not callable(get_tracks):
                raise RuntimeError(f"tracks hook is not implemented for {source_id}")
            try:
                tracks = get_tracks(bid, referer=referer)
            except TypeError:
                tracks = get_tracks(bid)
            json_response(self, {"ok": True, "tracks": tracks})
        except Exception as exc:
            import traceback
            print(f"[ERROR] get_akniga_tracks failed for bid {bid}: {exc}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            # Возвращаем клиенту подробную информацию об ошибке
            json_response(self, {"ok": False, "error": f"{type(exc).__name__}: {exc}", "details": traceback.format_exc()}, HTTPStatus.BAD_GATEWAY)

    def handle_archive(self, parsed):
        params = parse.parse_qs(parsed.query)
        identifier = params.get("identifier", [""])[0].strip()
        if not re.fullmatch(r"[\w.-]{1,180}", identifier):
            json_response(self, {"ok": False, "status": 0, "error": "invalid archive identifier"}, HTTPStatus.BAD_REQUEST)
            return
        cached = ARCHIVE_CACHE.get(identifier)
        if cached and time.time() - cached["time"] < ARCHIVE_CACHE_SECONDS:
            payload = dict(cached["payload"])
            payload["cache"] = True
            json_response(self, payload)
            return
        url = f"https://archive.org/metadata/{parse.quote(identifier)}"
        headers = {
            "User-Agent": "AudiobooksTester/1.0",
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "Connection": "close",
        }
        try:
            req = request.Request(url, headers=headers)
            with request.urlopen(req, timeout=18) as response:
                raw = response.read(MAX_HTML_BYTES + 1)[:MAX_HTML_BYTES]
                body = decode_body(
                    raw,
                    response.headers.get("Content-Type", ""),
                    response.headers.get("Content-Encoding", ""),
                )
                payload = json.loads(body)
                response_payload = {"ok": True, "status": response.status, "url": response.geturl(), "metadata": payload}
                ARCHIVE_CACHE[identifier] = {"time": time.time(), "payload": response_payload}
                json_response(self, response_payload)
        except Exception as exc:
            fallback = fetch_json_with_curl(url, headers)
            if fallback.get("ok"):
                ARCHIVE_CACHE[identifier] = {"time": time.time(), "payload": fallback}
                json_response(self, fallback)
            else:
                fallback["error"] = fallback.get("error") or str(exc)
                json_response(self, fallback, HTTPStatus.BAD_GATEWAY)

    def handle_media(self, parsed):
        params = parse.parse_qs(parsed.query)
        source_id = params.get("source", [""])[0]
        url = params.get("url", [""])[0]
        referer = params.get("referer", [""])[0]
        try:
            source = source_for_id(source_id)
            media_url = normalize_media_url_for_curl(
                validate_media_url_for_source(source_id, url)
            )
            referer_url = validate_url_for_source(source_id, referer)
        except Exception as exc:
            json_response(self, {"ok": False, "status": 0, "error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0 Safari/537.36"
            ),
            "Accept": "audio/mpeg,audio/*,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "close",
            "Referer": referer_url,
            "Origin": source.get("media_origin") or source.get("host") or "https://example.local",
        }
        range_header = self.headers.get("Range")
        if range_header:
            headers["Range"] = range_header

        if source_id == "baza_knig":
            media_url = resolve_baza_abooka_media_url(media_url, headers)

        media_host = normalize_host(parse.urlparse(media_url).netloc)
        self.stream_media_with_curl(media_url, headers, follow_redirects=media_host in {"litres.ru", "www.litres.ru"})

    def stream_media_with_curl(self, media_url, headers, follow_redirects=False):
        # Если media_url — локальный файл (возвращён validate_media_url), отдаём его напрямую
        if os.path.exists(media_url) and os.path.isfile(media_url):
            self.send_response(200)
            self.send_header('Content-Type', 'audio/mpeg')
            self.send_header('Content-Length', str(os.path.getsize(media_url)))
            self.end_headers()
            with open(media_url, 'rb') as f:
                while chunk := f.read(64 * 1024):
                    self.wfile.write(chunk)
            return

        command = [
            "curl.exe",
            "--silent",
            "--show-error",
            "--ssl-no-revoke",
            "--http1.1",
        ]
        if follow_redirects:
            command.append("--location")
        command.extend([
            "--no-buffer",
            "--max-time",
            str(MEDIA_TIMEOUT_SECONDS),
            "--dump-header",
            "-",
            "--output",
            "-",
            "--user-agent",
            headers["User-Agent"],
            "--referer",
            headers["Referer"],
            "--header",
            f"Accept: {headers['Accept']}",
            "--header",
            "Accept-Encoding: identity",
            "--header",
            f"Origin: {headers['Origin']}",
        ])
        if headers.get("Range"):
            command.extend(["--header", f"Range: {headers['Range']}"])
        command.append(media_url)

        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        header_buffer = b""
        try:
            while len(header_buffer) < 128_000:
                while b"\r\n\r\n" not in header_buffer and len(header_buffer) < 128_000:
                    chunk = proc.stdout.read(4096)
                    if not chunk:
                        break
                    header_buffer += chunk

                marker = header_buffer.find(b"\r\n\r\n")
                if marker < 0:
                    stderr = proc.stderr.read(4096).decode("utf-8", errors="replace")
                    raise RuntimeError(stderr or "curl did not return response headers")

                raw_headers = header_buffer[:marker].decode("iso-8859-1", errors="replace")
                body_prefix = header_buffer[marker + 4:]
                lines = raw_headers.splitlines()
                status_match = re.match(r"HTTP/\S+\s+(\d+)", lines[0] if lines else "")
                status = int(status_match.group(1)) if status_match else 502
                if follow_redirects and (100 <= status < 200 or 300 <= status < 400):
                    header_buffer = body_prefix
                    continue
                break
            else:
                raise RuntimeError("curl response headers are too large")

            self.send_response(status)
            for line in lines[1:]:
                name, sep, value = line.partition(":")
                if sep and name.lower() in {"content-type", "content-length", "content-range", "accept-ranges", "last-modified", "etag"}:
                    self.send_header(name, value.strip())
            self.send_header("Cache-Control", "no-store")
            self.end_headers()

            if body_prefix:
                self.wfile.write(body_prefix)
            while True:
                chunk = proc.stdout.read(64 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            pass
        except Exception as exc:
            try:
                if not self.wfile.closed:
                    json_response(self, {"ok": False, "status": 0, "error": str(exc)}, HTTPStatus.BAD_GATEWAY)
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                pass
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.stderr.close()
            proc.stdout.close()

    def handle_static(self, raw_path):
        path = parse.unquote(raw_path.split("?", 1)[0])
        if path == "/":
            path = "/index.html"
        candidate = (ROOT / path.lstrip("/")).resolve()
        try:
            candidate.relative_to(ROOT)
        except ValueError:
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if not candidate.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content_type, _ = mimetypes.guess_type(candidate.name)
        body = candidate.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


class ThreadingHTTPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def fetch_json_with_curl(url, headers):
    marker = b"\n__AUDIOTESTER_STATUS__"
    command = [
        "curl.exe",
        "--silent",
        "--show-error",
        "--location",
        "--compressed",
        "--ssl-no-revoke",
        "--http1.1",
        "--max-time",
        "20",
        "--output",
        "-",
        "--write-out",
        "\n__AUDIOTESTER_STATUS__%{http_code}__URL__%{url_effective}",
        "--user-agent",
        headers.get("User-Agent", "AudiobooksTester/1.0"),
        "--header",
        f"Accept: {headers.get('Accept', 'application/json')}",
        url,
    ]
    try:
        completed = subprocess.run(command, capture_output=True, timeout=24, check=False)
    except Exception as exc:
        return {"ok": False, "status": 0, "error": str(exc)}
    marker_index = completed.stdout.rfind(marker)
    if marker_index < 0:
        return {"ok": False, "status": 0, "error": completed.stderr.decode("utf-8", errors="replace")}
    body = completed.stdout[:marker_index]
    meta = completed.stdout[marker_index + len(marker):].decode("utf-8", errors="replace")
    status_text, _, final_url = meta.partition("__URL__")
    try:
        status = int(status_text.strip())
    except ValueError:
        status = 0
    try:
        payload = json.loads(body.decode("utf-8", errors="replace"))
    except Exception as exc:
        return {"ok": False, "status": status, "url": final_url or url, "error": str(exc)}
    return {"ok": 200 <= status < 400, "status": status, "url": final_url or url, "metadata": payload}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "5177")))
    args = parser.parse_args()
    with ThreadingHTTPServer((args.host, args.port), Handler) as httpd:
        print(f"Serving audiobooks tester at http://{args.host}:{args.port}/", flush=True)
        httpd.serve_forever()


if __name__ == "__main__":
    main()
